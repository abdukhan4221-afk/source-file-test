import { describe, expect, it } from 'vitest';
import { isSafeFileName, isSafeRelativePath, resolveInside } from '../apps/launcher/electron/core/fsSafe';

describe('path safety', () => {
  it('blocks traversal out of the root', () => {
    expect(() => resolveInside('/data/inst', '..', 'other')).toThrow();
    expect(() => resolveInside('/data/inst', 'a/../../x')).toThrow();
    expect(resolveInside('/data/inst', 'mods', 'a.jar')).toBe('/data/inst/mods/a.jar');
  });
  it('accepts names that merely start with two dots', () => {
    expect(resolveInside('/data/inst', '..cache')).toBe('/data/inst/..cache');
  });
  it('validates archive entry paths', () => {
    expect(isSafeRelativePath('mods/a.jar')).toBe(true);
    expect(isSafeRelativePath('../evil')).toBe(false);
    expect(isSafeRelativePath('a/../../evil')).toBe(false);
    expect(isSafeRelativePath('/etc/passwd')).toBe(false);
    expect(isSafeRelativePath('C:\\windows\\x')).toBe(false);
    expect(isSafeFileName('a.jar')).toBe(true);
    expect(isSafeFileName('../a.jar')).toBe(false);
  });
});
