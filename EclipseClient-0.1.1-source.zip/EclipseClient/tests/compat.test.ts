import { describe, expect, it } from 'vitest';
import { loadersFor, requiredJava } from '../apps/launcher/electron/core/compat';
import { chooseJava, parseJavaVersionOutput } from '../apps/launcher/electron/core/java';

describe('compatibility', () => {
  it('maps Minecraft versions to the correct Java', () => {
    expect(requiredJava('1.8.9')).toBe(8);
    expect(requiredJava('1.16.5')).toBe(8);
    expect(requiredJava('1.17.1')).toBe(16);
    expect(requiredJava('1.20.4')).toBe(17);
    expect(requiredJava('1.20.5')).toBe(21);
    expect(requiredJava('1.21.1')).toBe(21);
    expect(requiredJava('1.21.1', 21)).toBe(21);
  });
  it('never advertises an unimplemented loader as installable', () => {
    const l = loadersFor('1.21.1');
    expect(l.find((x) => x.loader === 'vanilla')?.installable).toBe(true);
    expect(l.filter((x) => x.loader !== 'vanilla').every((x) => !x.installable && x.reason)).toBe(true);
  });
  it('explains version-range mismatches', () => {
    const fabric = loadersFor('1.8.9').find((x) => x.loader === 'fabric');
    expect(fabric?.reason).toMatch(/does not support/);
    expect(loadersFor('1.8.9').find((x) => x.loader === 'legacy-fabric')?.reason).toMatch(/not implemented/);
  });
  it('parses java -version banners', () => {
    expect(parseJavaVersionOutput('openjdk version "21.0.13" 2026-10-24')?.major).toBe(21);
    expect(parseJavaVersionOutput('java version "1.8.0_392"')?.major).toBe(8);
    expect(parseJavaVersionOutput('garbage')).toBeNull();
  });
  it('does not run Java 8-era games on newer Java', () => {
    const installs = [{ path: 'j21', major: 21 }, { path: 'j17', major: 17 }];
    expect(chooseJava(installs, 8)).toBeUndefined();
    expect(chooseJava(installs, 17)?.path).toBe('j17');
    expect(chooseJava([{ path: 'j21', major: 21 }], 17)?.path).toBe('j21');
  });
});
