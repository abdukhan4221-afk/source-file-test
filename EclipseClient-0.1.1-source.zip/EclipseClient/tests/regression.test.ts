import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const fabric = path.resolve(__dirname, '../clients/fabric-1.21.1/src/main/java/gg/eclipse/client');
const read = (rel: string) => fs.readFileSync(path.join(fabric, rel), 'utf8');
const code = (s: string) => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/gm, ''); // ignore comments

/**
 * Source-level guards for failure modes from the spec that cannot be exercised without a running game.
 * They do not prove the game works; they stop known-bad patterns from being reintroduced.
 */
describe('known failure prevention (source guards)', () => {
  const loading = code(read('mixin/LoadingOverlayMixin.java'));

  it('#2 never cancels or replaces the vanilla loading overlay lifecycle', () => {
    expect(loading).not.toMatch(/cancellable\s*=\s*true/);
    expect(loading).not.toMatch(/\.cancel\(\)/);
    expect(loading).not.toMatch(/setOverlay\s*\(/);
    expect(loading).toMatch(/at\s*=\s*@At\("TAIL"\)/); // only ever adds drawing after vanilla finished its own render
  });

  it('#1/#10 loading progress is the reload\'s actual progress, never a timer or random number', () => {
    expect(loading).toMatch(/reload\.getActualProgress\(\)/);
    expect(loading).not.toMatch(/Math\.random|new Random|System\.(currentTimeMillis|nanoTime)\s*\(\)\s*[%/]/);
  });

  it('#3/#4 title screen disables vanilla blur and uses no vanilla widgets', () => {
    const title = code(read('screen/EclipseTitleScreen.java'));
    expect(title).toMatch(/void renderBackground\([^)]*\)\s*\{\s*\}/);
    expect(title).not.toMatch(/addRenderableWidget|Button\.builder|PanoramaRenderer/);
  });

  it('#5 no textures or atlas coordinates in any screen (procedural drawing only)', () => {
    for (const f of ['screen/EclipseTitleScreen.java', 'screen/ModuleWorkspaceScreen.java', 'screen/HudEditorScreen.java', 'mc/Gfx.java']) {
      expect(code(read(f))).not.toMatch(/\.blit\(|ResourceLocation|TextureAtlas|DynamicTexture/);
    }
  });

  it('#6/#7/#8 workspace layout, cards and scrolling come from the unit-tested core', () => {
    const ws = code(read('screen/ModuleWorkspaceScreen.java'));
    expect(ws).toMatch(/new WorkspaceLayout\(/);
    expect(ws).toMatch(/new CardGrid\(/);
    expect(ws).toMatch(/ScrollModel/);
    expect(ws).toMatch(/enableScissor/); // content is clipped to its panel
    expect(ws).toMatch(/mouseScrolled/);
  });

  it('#15 mod initialisation cannot crash the game on a bad config', () => {
    const entry = code(read('EclipseClient.java'));
    expect(entry).toMatch(/catch \(Exception e\)/);
    expect(entry).toMatch(/continuing with defaults/);
  });

  it('#11/#12 only modules with real behaviour are registered (no placeholder modules)', () => {
    const mods = read('mc/Modules.java');
    const registered = (mods.match(/r\.register\(new /g) ?? []).length;
    expect(registered).toBe(15);
    expect(code(mods)).not.toMatch(/TODO|placeholder|not implemented/i);
  });
});

describe('Forge 1.8.9 stays separate from the modern client', () => {
  it('shares no modern Fabric/Mojang API usage with the legacy source', () => {
    const legacy = fs.readFileSync(path.resolve(__dirname, '../clients/forge-1.8.9/src/main/java/gg/eclipse/legacy/EclipseLegacy.java'), 'utf8');
    expect(legacy).not.toMatch(/net\.fabricmc|GuiGraphics|net\.minecraft\.client\.gui\.screens/);
  });
});
