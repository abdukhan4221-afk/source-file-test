import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { AccountService, offlineUuid, validateMinecraftUsername } from '../apps/launcher/electron/core/accounts';
import { tmpDir } from './helpers';

const memSecrets = () => {
  const m = new Map<string, string>();
  return { map: m, set: (k: string, v: string) => void m.set(k, v), get: (k: string) => m.get(k) ?? null, delete: (k: string) => void m.delete(k) };
};

describe('accounts', () => {
  it('matches Java\'s offline UUID algorithm', () => {
    expect(offlineUuid('Notch')).toBe('b50ad385-829d-3141-a216-7e7d7539ba7f');
  });
  it('validates usernames', () => {
    expect(validateMinecraftUsername('ab')).toBeTruthy();
    expect(validateMinecraftUsername('has space')).toBeTruthy();
    expect(validateMinecraftUsername('Steve_01')).toBeNull();
  });
  it('keeps tokens out of accounts.json and in the secret store', () => {
    const root = tmpDir();
    const secrets = memSecrets();
    const svc = new AccountService(root, secrets);
    const acc = svc.upsertMicrosoft({ username: 'Alex', uuid: 'u-1', expiresAt: new Date().toISOString() }, { refreshToken: 'REFRESH-SECRET', minecraftToken: 'MC-SECRET' });
    const onDisk = fs.readFileSync(path.join(root, 'accounts.json'), 'utf8');
    expect(onDisk).not.toContain('SECRET');
    expect(svc.tokensFor(acc.id)?.refreshToken).toBe('REFRESH-SECRET');
    svc.remove(acc.id);
    expect(secrets.map.size).toBe(0);
  });
  it('does not persist guest sessions and blocks guest defaults', () => {
    const root = tmpDir();
    const svc = new AccountService(root, memSecrets());
    const guest = svc.addLocal('', true);
    expect(guest.username).toMatch(/^Guest_/);
    expect(JSON.parse(fs.readFileSync(path.join(root, 'accounts.json'), 'utf8')).accounts).toHaveLength(0);
    expect(() => svc.setDefault(guest.id)).toThrow();
    expect(new AccountService(root, memSecrets()).state().accounts).toHaveLength(0);
  });
  it('rejects duplicate local names and renaming Microsoft accounts', () => {
    const svc = new AccountService(tmpDir(), memSecrets());
    svc.addLocal('Steve');
    expect(() => svc.addLocal('steve')).toThrow(/already exists/);
    const ms = svc.upsertMicrosoft({ username: 'Alex', uuid: 'u', expiresAt: '' }, { refreshToken: 'r', minecraftToken: 't' });
    expect(() => svc.rename(ms.id, 'Other')).toThrow();
  });
});
