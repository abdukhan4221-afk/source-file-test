import { describe, expect, it } from 'vitest';
import { MicrosoftAuth, MicrosoftAuthError } from '../apps/launcher/electron/core/msAuth';

type Route = (url: string, init?: any) => { status?: number; body: any } | undefined;
function mockFetch(routes: Route[]) {
  const calls: string[] = [];
  const fn = async (url: string, init?: any) => {
    calls.push(url);
    for (const r of routes) {
      const out = r(url, init);
      if (out) return { ok: (out.status ?? 200) < 400, status: out.status ?? 200, json: async () => out.body, text: async () => '', arrayBuffer: async () => new ArrayBuffer(0) };
    }
    throw new Error('unrouted ' + url);
  };
  return { fn: fn as any, calls };
}
const happyChain: Route[] = [
  (u) => u.includes('user.auth.xboxlive') ? { body: { Token: 'XBL', DisplayClaims: { xui: [{ uhs: 'UHS' }] } } } : undefined,
  (u) => u.includes('xsts.auth') ? { body: { Token: 'XSTS', DisplayClaims: { xui: [{ uhs: 'UHS' }] } } } : undefined,
  (u, i) => u.includes('login_with_xbox') ? (JSON.parse(i.body).identityToken === 'XBL3.0 x=UHS;XSTS' ? { body: { access_token: 'MCTOKEN', expires_in: 86400 } } : { status: 400, body: {} }) : undefined,
  (u) => u.endsWith('/minecraft/profile') ? { body: { id: 'abc', name: 'Alex', skins: [{ state: 'ACTIVE', url: 'http://skin' }] } } : undefined,
];

describe('MicrosoftAuth', () => {
  it('refuses to run without a client id and never embeds a secret', () => {
    expect(() => new MicrosoftAuth('', (async () => {}) as any)).toThrow(MicrosoftAuthError);
  });

  it('polls through authorization_pending then completes the full chain', async () => {
    let polls = 0;
    const m = mockFetch([
      (u) => u.endsWith('/devicecode') ? { body: { device_code: 'DC', user_code: 'ABCD', verification_uri: 'https://microsoft.com/link', expires_in: 900, interval: 1 } } : undefined,
      (u, i) => u.endsWith('/token') ? (++polls < 3 ? { status: 400, body: { error: 'authorization_pending' } } : { body: { access_token: 'MSA', refresh_token: 'RT' } }) : undefined,
      ...happyChain,
    ]);
    const auth = new MicrosoftAuth('client-id', m.fn, async () => {});
    const info = await auth.beginDeviceCode();
    expect(info.userCode).toBe('ABCD');
    const s = await auth.completeDeviceCode(info);
    expect(s).toMatchObject({ username: 'Alex', uuid: 'abc', minecraftToken: 'MCTOKEN', refreshToken: 'RT', skinUrl: 'http://skin' });
    expect(polls).toBe(3);
  });

  it('maps XSTS errors to actionable messages', async () => {
    const m = mockFetch([
      (u) => u.includes('user.auth.xboxlive') ? { body: { Token: 'XBL' } } : undefined,
      (u) => u.includes('xsts.auth') ? { status: 401, body: { XErr: 2148916233 } } : undefined,
      (u) => u.endsWith('/token') ? { body: { access_token: 'MSA', refresh_token: 'RT' } } : undefined,
    ]);
    await expect(new MicrosoftAuth('c', m.fn, async () => {}).refresh('RT')).rejects.toThrow(/no Xbox profile/);
  });

  it('detects accounts that do not own Java Edition', async () => {
    const m = mockFetch([
      (u) => u.endsWith('/minecraft/profile') ? { status: 404, body: {} } : undefined,
      ...happyChain.slice(0, 3),
      (u) => u.endsWith('/token') ? { body: { access_token: 'MSA', refresh_token: 'RT' } } : undefined,
    ]);
    await expect(new MicrosoftAuth('c', m.fn, async () => {}).refresh('RT')).rejects.toThrow(/does not own/);
  });

  it('stops when the code is declined and when the refresh token is rejected', async () => {
    const declined = mockFetch([(u) => u.endsWith('/token') ? { status: 400, body: { error: 'authorization_declined' } } : undefined]);
    await expect(new MicrosoftAuth('c', declined.fn, async () => {}).completeDeviceCode({ deviceCode: 'x', expiresInSec: 60, intervalSec: 1 })).rejects.toThrow(/declined/);
    const bad = mockFetch([(u) => u.endsWith('/token') ? { status: 400, body: { error: 'invalid_grant' } } : undefined]);
    await expect(new MicrosoftAuth('c', bad.fn, async () => {}).refresh('old')).rejects.toThrow(/Sign in again/);
  });
});
