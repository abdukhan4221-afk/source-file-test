import { describe, expect, it } from 'vitest';
import { VersionService, filterVersions } from '../apps/launcher/electron/core/versions';
import { tmpDir } from './helpers';
import path from 'node:path';

const manifest = { versions: [
  { id: '1.21.1', type: 'release', url: 'u1', releaseTime: '2024-08-08' },
  { id: '24w40a', type: 'snapshot', url: 'u2', releaseTime: '2024-10-01' },
  { id: 'b1.7.3', type: 'old_beta', url: 'u3', releaseTime: '2011-07-01' },
] };
const ok = async () => ({ ok: true, status: 200, json: async () => manifest, text: async () => '', arrayBuffer: async () => new ArrayBuffer(0) });
const down = async () => { throw new Error('offline'); };

describe('VersionService', () => {
  it('fetches, caches, and serves the cache when offline', async () => {
    const file = path.join(tmpDir(), 'v.json');
    const online = await new VersionService(file, ok as any).list(true);
    expect(online.fromCache).toBe(false);
    const offline = await new VersionService(file, down as any).list(true);
    expect(offline.fromCache).toBe(true);
    expect(offline.versions).toHaveLength(3);
  });
  it('reports a clear error when offline with no cache', async () => {
    await expect(new VersionService(path.join(tmpDir(), 'x.json'), down as any).list()).rejects.toThrow(/offline copy/);
  });
  it('filters by type and search', () => {
    const v = manifest.versions as any;
    expect(filterVersions(v, { types: ['release'] })).toHaveLength(1);
    expect(filterVersions(v, { search: '24w' })[0]?.id).toBe('24w40a');
  });
});
