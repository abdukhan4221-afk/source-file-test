import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { ProfileService } from '../apps/launcher/electron/core/profiles';
import { tmpDir } from './helpers';

describe('ProfileService', () => {
  it('creates isolated instances with their own folders', () => {
    const svc = new ProfileService(tmpDir());
    const a = svc.create({ name: 'A', minecraftVersion: '1.21.1', loader: 'vanilla' });
    const b = svc.create({ name: 'B', minecraftVersion: '1.8.9', loader: 'vanilla' });
    expect(a.gameDir).not.toBe(b.gameDir);
    for (const sub of ['mods', 'resourcepacks', 'shaderpacks', 'config', 'saves']) {
      expect(fs.existsSync(path.join(a.gameDir, sub))).toBe(true);
    }
    fs.writeFileSync(path.join(a.gameDir, 'mods', 'only-in-a.jar'), 'x');
    expect(fs.existsSync(path.join(b.gameDir, 'mods', 'only-in-a.jar'))).toBe(false);
  });

  it('persists selection across restarts and never changes it unless asked', () => {
    const root = tmpDir();
    const svc = new ProfileService(root);
    const a = svc.create({ name: 'A', minecraftVersion: '1.21.1', loader: 'vanilla' });
    const b = svc.create({ name: 'B', minecraftVersion: '1.21.1', loader: 'vanilla' });
    svc.select(b.id);
    svc.create({ name: 'C', minecraftVersion: '1.20.1', loader: 'vanilla' }); // browsing/creating must not steal selection
    expect(new ProfileService(root).state().selectedId).toBe(b.id);
    expect(new ProfileService(root).state().defaultId).toBe(a.id);
  });

  it('moves removed profiles to trash instead of deleting worlds', () => {
    const root = tmpDir();
    const svc = new ProfileService(root);
    const a = svc.create({ name: 'A', minecraftVersion: '1.21.1', loader: 'vanilla' });
    fs.mkdirSync(path.join(a.gameDir, 'saves', 'MyWorld'));
    const trashed = svc.remove(a.id);
    expect(fs.existsSync(path.join(trashed, 'saves', 'MyWorld'))).toBe(true);
    expect(svc.state().profiles).toHaveLength(0);
  });

  it('clones data into a separate directory', () => {
    const svc = new ProfileService(tmpDir());
    const a = svc.create({ name: 'A', minecraftVersion: '1.21.1', loader: 'vanilla' });
    fs.writeFileSync(path.join(a.gameDir, 'options.txt'), 'fov:90');
    const c = svc.clone(a.id);
    expect(fs.readFileSync(path.join(c.gameDir, 'options.txt'), 'utf8')).toBe('fov:90');
    expect(c.id).not.toBe(a.id);
  });

  it('rejects bad names and partial reorders', () => {
    const svc = new ProfileService(tmpDir());
    const a = svc.create({ name: 'A', minecraftVersion: '1.21.1', loader: 'vanilla' });
    svc.create({ name: 'B', minecraftVersion: '1.21.1', loader: 'vanilla' });
    expect(() => svc.rename(a.id, '   ')).toThrow();
    expect(() => svc.reorder([a.id])).toThrow();
  });

  it('survives a corrupt profiles.json without crashing', () => {
    const root = tmpDir();
    fs.writeFileSync(path.join(root, 'profiles.json'), '{not json');
    expect(new ProfileService(root).state().profiles).toEqual([]);
  });
});
