import { describe, expect, it } from 'vitest';
import { EventEmitter } from 'node:events';
import { LaunchController, type LaunchSteps } from '../apps/launcher/electron/core/launcher';
import type { LaunchPhase } from '@eclipse/shared-types';

function fakeChild() {
  const c: any = new EventEmitter();
  c.pid = 4242;
  c.kill = (sig: string) => setImmediate(() => c.emit('exit', null, sig));
  return c;
}
const steps = (over: Partial<LaunchSteps> = {}, child = fakeChild()): { s: LaunchSteps; child: any; ended: any[] } => {
  const ended: any[] = [];
  return {
    child, ended,
    s: {
      prepareProfile: async () => {}, checkInstall: async () => {}, resolveLoader: async () => {}, prepareJava: async () => {},
      prepareLibraries: async (report) => { report(0.5, 'half'); report(1, 'done'); },
      spawn: () => { setImmediate(() => child.emit('spawn')); return child; },
      onSessionEnd: (ms, code) => ended.push({ ms, code }),
      ...over,
    },
  };
};

describe('LaunchController', () => {
  it('walks real stages in order and reports running only after spawn', async () => {
    const ctl = new LaunchController();
    const phases: LaunchPhase[] = [];
    ctl.onState((s) => phases.push(s.phase));
    const { s } = steps();
    await ctl.start('p1', s);
    expect(phases).toEqual(['preparing-profile', 'checking-install', 'preparing-libraries', 'preparing-libraries', 'preparing-libraries', 'resolving-loader', 'preparing-java', 'starting', 'running']);
    expect(ctl.getState()).toMatchObject({ phase: 'running', pid: 4242, profileId: 'p1' });
  });

  it('passes through measured progress and leaves it indeterminate otherwise', async () => {
    const ctl = new LaunchController();
    const seen: (number | undefined)[] = [];
    ctl.onState((s) => s.phase === 'preparing-libraries' && seen.push(s.progress));
    await ctl.start('p', steps().s);
    expect(seen).toEqual([undefined, 0.5, 1]);
  });

  it('ends as stopped on a clean exit and records the session', async () => {
    const ctl = new LaunchController();
    const { s, child, ended } = steps();
    await ctl.start('p', s);
    child.emit('exit', 0, null);
    expect(ctl.getState().phase).toBe('stopped');
    expect(ended).toHaveLength(1);
  });

  it('reports a crash as failed with the exit code', async () => {
    const ctl = new LaunchController();
    const { s, child } = steps();
    await ctl.start('p', s);
    child.emit('exit', 1, null);
    expect(ctl.getState()).toMatchObject({ phase: 'failed' });
    expect(ctl.getState().error).toMatch(/code 1/);
  });

  it('fails cleanly when a step throws and allows retrying', async () => {
    const ctl = new LaunchController();
    await ctl.start('p', steps({ prepareJava: async () => { throw new Error('No Java 21 found'); } }).s);
    expect(ctl.getState()).toMatchObject({ phase: 'failed', error: 'No Java 21 found' });
    expect(ctl.isBusy()).toBe(false);
    await ctl.start('p', steps().s);
    expect(ctl.getState().phase).toBe('running');
  });

  it('refuses a second launch while one is active', async () => {
    const ctl = new LaunchController();
    await ctl.start('p', steps().s);
    await expect(ctl.start('p', steps().s)).rejects.toThrow(/already/);
  });

  it('stop() terminates the real process and ends as stopped', async () => {
    const ctl = new LaunchController();
    const { s } = steps();
    await ctl.start('p', s);
    ctl.stop();
    await new Promise((r) => setTimeout(r, 10));
    expect(ctl.getState().phase).toBe('stopped');
  });

  it('records WHICH stage failed so the UI marks the right step', async () => {
    for (const [stage, expected] of [['checkInstall', 'checking-install'], ['prepareLibraries', 'preparing-libraries'], ['prepareJava', 'preparing-java']] as const) {
      const ctl = new LaunchController();
      await ctl.start('p', steps({ [stage]: async () => { throw new Error('boom'); } } as any).s);
      expect(ctl.getState()).toMatchObject({ phase: 'failed', failedPhase: expected, error: 'boom' });
    }
  });

  it('reports a crash after startup as failing at the running stage', async () => {
    const ctl = new LaunchController();
    const { s, child } = steps();
    await ctl.start('p', s);
    child.emit('exit', 137, null);
    expect(ctl.getState()).toMatchObject({ phase: 'failed', failedPhase: 'running' });
  });
});
