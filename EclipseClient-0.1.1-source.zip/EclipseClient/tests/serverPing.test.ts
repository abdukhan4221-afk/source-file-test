import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import net from 'node:net';
import { __test, parseAddress, pingServer } from '../apps/launcher/electron/core/serverPing';

const { varInt, readVarInt, packet } = __test;
let server: net.Server;
let port = 0;

beforeAll(async () => {
  server = net.createServer((sock) => {
    let buf = Buffer.alloc(0);
    let answered = false;
    sock.on('data', (d) => {
      buf = Buffer.concat([buf, d]);
      // handshake packet, then status request packet, then ping
      const parsed: { id: number; data: Buffer }[] = [];
      let b = buf;
      for (;;) {
        const l = readVarInt(b);
        if (!l || b.length < l.size + l.value) break;
        const body = b.subarray(l.size, l.size + l.value);
        const id = readVarInt(body)!;
        parsed.push({ id: id.value, data: body.subarray(id.size) });
        b = b.subarray(l.size + l.value);
      }
      buf = b;
      for (const p of parsed) {
        if (p.id === 0x00 && p.data.length === 0 && !answered) {
          answered = true;
          const json = Buffer.from(JSON.stringify({ version: { name: '1.21.1', protocol: 767 }, players: { online: 7, max: 100 }, description: { text: 'Hello ', extra: [{ text: 'World' }] } }));
          sock.write(packet(0x00, Buffer.concat([varInt(json.length), json])));
        } else if (p.id === 0x01) {
          sock.write(packet(0x01, p.data));
        }
      }
    });
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  port = (server.address() as net.AddressInfo).port;
});
afterAll(() => void server.close());

describe('server list ping', () => {
  it('reads real status data from a server', async () => {
    const s = await pingServer('127.0.0.1:' + port, 3000);
    expect(s).toMatchObject({ online: true, versionName: '1.21.1', protocol: 767, playersOnline: 7, playersMax: 100, motd: 'Hello World' });
    expect(s.latencyMs).toBeGreaterThanOrEqual(0);
  });
  it('reports offline honestly instead of inventing numbers', async () => {
    const s = await pingServer('127.0.0.1:1', 1500);
    expect(s.online).toBe(false);
    expect(s.playersOnline).toBeUndefined();
    expect(s.error).toBeTruthy();
  });
  it('parses addresses', () => {
    expect(parseAddress('play.example.com')).toEqual({ host: 'play.example.com', port: 25565 });
    expect(parseAddress('a.b:25570')).toEqual({ host: 'a.b', port: 25570 });
    expect(parseAddress('[::1]:25566')).toEqual({ host: '::1', port: 25566 });
  });
  it('encodes varints round-trip', () => {
    for (const n of [0, 1, 127, 128, 25565, 2097151]) expect(readVarInt(varInt(n))?.value).toBe(n);
  });
});
