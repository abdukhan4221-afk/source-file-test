import { describe, expect, it } from 'vitest';
import { buildCommand, evalRules, mergeVersions, resolveLibraries, splitArgs, type Env, type VersionJson } from '../apps/launcher/electron/core/launchPlan';

const linux: Env = { os: 'linux', arch: 'x64', features: {} };
const win: Env = { os: 'windows', arch: 'x64', features: {} };

describe('rules', () => {
  it('follows Mojang semantics', () => {
    expect(evalRules(undefined, linux)).toBe(true);
    expect(evalRules([{ action: 'allow' }, { action: 'disallow', os: { name: 'osx' } }], linux)).toBe(true);
    expect(evalRules([{ action: 'allow' }, { action: 'disallow', os: { name: 'linux' } }], linux)).toBe(false);
    expect(evalRules([{ action: 'allow', os: { name: 'windows' } }], linux)).toBe(false);
    expect(evalRules([{ action: 'allow', features: { is_demo_user: true } }], linux)).toBe(false);
  });
});

const art = (p: string) => ({ path: p, url: 'http://x/' + p, sha1: 'aa', size: 1 });
const base: VersionJson = {
  id: '1.21.1', type: 'release', mainClass: 'net.minecraft.client.main.Main',
  libraries: [
    { name: 'a', downloads: { artifact: art('a.jar') } },
    { name: 'win-only', rules: [{ action: 'allow', os: { name: 'windows' } }], downloads: { artifact: art('w.jar') } },
    { name: 'lwjgl-old', natives: { linux: 'natives-linux' }, downloads: { classifiers: { 'natives-linux': art('n.jar') } } },
  ],
  arguments: {
    jvm: ['-Djava.library.path=${natives_directory}', { rules: [{ action: 'allow', os: { name: 'windows' } }], value: '-XX:HeapDumpPath=x' }, '-cp', '${classpath}'],
    game: ['--username', '${auth_player_name}', { rules: [{ action: 'allow', features: { has_custom_resolution: true } }], value: ['--width', '${resolution_width}'] }, { rules: [{ action: 'allow', features: { is_demo_user: true } }], value: '--demo' }],
  },
};

describe('libraries and arguments', () => {
  it('filters libraries by OS and separates natives', () => {
    const libs = resolveLibraries(base, '/libs', linux);
    expect(libs.map((l) => l.artifact.path)).toEqual(['a.jar', 'n.jar']);
    expect(libs.find((l) => l.artifact.path === 'n.jar')?.native).toBe(true);
    expect(resolveLibraries(base, '/libs', win).map((l) => l.artifact.path)).toEqual(['a.jar', 'w.jar']);
  });
  it('builds a complete command with substitutions and conditional args', () => {
    const { args } = buildCommand(base, {
      versionName: '1.21.1', gameDir: '/g', assetsDir: '/a', assetsIndexName: '17', nativesDir: '/n', classpath: ['/c1.jar', '/c2.jar'],
      playerName: 'Steve', uuid: 'u', accessToken: '0', userType: 'legacy', width: 1280, height: 720, fullscreen: false,
      memoryMb: 2048, extraJvmArgs: '-Dfoo="a b"', launcherVersion: '0.1.0',
    }, linux);
    expect(args.slice(0, 3)).toEqual(['-Xmx2048M', '-Xms512M', '-Dfoo=a b']);
    expect(args).toContain('-Djava.library.path=/n');
    expect(args).not.toContain('-XX:HeapDumpPath=x');
    expect(args.join(' ')).toContain('--username Steve --width 1280');
    expect(args).not.toContain('--demo');
    expect(args[args.indexOf('net.minecraft.client.main.Main') - 1]).toMatch(/c1\.jar.*c2\.jar/);
  });
  it('supports legacy minecraftArguments', () => {
    const legacy: VersionJson = { id: '1.8.9', mainClass: 'net.minecraft.client.main.Main', libraries: [], minecraftArguments: '--username ${auth_player_name} --version ${version_name}' };
    const { args } = buildCommand(legacy, { versionName: '1.8.9', gameDir: '/g', assetsDir: '/a', assetsIndexName: '1.8', nativesDir: '/n', classpath: ['/x.jar'], playerName: 'S', uuid: 'u', accessToken: '0', userType: 'legacy', width: 1, height: 1, fullscreen: false, memoryMb: 1024, extraJvmArgs: '', launcherVersion: '1' }, linux);
    expect(args).toContain('-Djava.library.path=/n');
    expect(args.slice(-4)).toEqual(['--username', 'S', '--version', '1.8.9']);
  });
  it('merges loader profiles onto their parent', () => {
    const merged = mergeVersions({ id: 'fabric', mainClass: 'KnotClient', inheritsFrom: '1.21.1', libraries: [{ name: 'fabric-loader' }] }, base);
    expect(merged.mainClass).toBe('KnotClient');
    expect(merged.libraries[0]?.name).toBe('fabric-loader');
    expect(merged.assetIndex).toBeUndefined();
    expect(merged.arguments?.game?.length).toBe(4);
  });
  it('splits quoted arguments', () => {
    expect(splitArgs('-a "b c" -d')).toEqual(['-a', 'b c', '-d']);
  });
});

describe('splitArgs edge cases', () => {
  it('handles mid-token quotes, single quotes and empty quoted args', async () => {
    const { splitArgs } = await import('../apps/launcher/electron/core/launchPlan');
    expect(splitArgs('-Dfoo="a b" -Xss1M')).toEqual(['-Dfoo=a b', '-Xss1M']);
    expect(splitArgs("--x 'y z'")).toEqual(['--x', 'y z']);
    expect(splitArgs('--name ""')).toEqual(['--name', '']);
    expect(splitArgs('   ')).toEqual([]);
  });
});
