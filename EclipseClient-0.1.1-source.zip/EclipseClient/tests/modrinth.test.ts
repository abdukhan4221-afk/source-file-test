import { describe, expect, it } from 'vitest';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { zipSync, strToU8 } from 'fflate';
import { ContentInstaller, applyMrpack, parseMrpack, pickVersion, planInstall, type MrVersion } from '../apps/launcher/electron/core/modrinth';
import { tmpDir } from './helpers';

const sha512 = (b: Uint8Array | Buffer) => crypto.createHash('sha512').update(b).digest('hex');
const mkVersion = (over: Partial<MrVersion> & { id: string; project_id: string }): MrVersion => ({
  version_number: '1.0', version_type: 'release', date_published: '2024-01-01T00:00:00Z', game_versions: ['1.21.1'], loaders: ['fabric'],
  files: [{ url: 'https://cdn.modrinth.com/x.jar', filename: over.project_id + '.jar', primary: true, hashes: { sha1: '', sha512: '' }, size: 1 }],
  dependencies: [], ...over,
});

describe('version picking and dependency planning', () => {
  it('prefers newest release over newer beta', () => {
    const picked = pickVersion([
      mkVersion({ id: 'b', project_id: 'p', version_type: 'beta', date_published: '2024-06-01T00:00:00Z' }),
      mkVersion({ id: 'r1', project_id: 'p', date_published: '2024-01-01T00:00:00Z' }),
      mkVersion({ id: 'r2', project_id: 'p', date_published: '2024-03-01T00:00:00Z' }),
    ]);
    expect(picked?.id).toBe('r2');
  });

  it('resolves required deps once, skips optional/installed, and handles cycles', async () => {
    const versions: Record<string, MrVersion[]> = {
      A: [mkVersion({ id: 'a1', project_id: 'A', dependencies: [{ project_id: 'B', dependency_type: 'required' }, { project_id: 'OPT', dependency_type: 'optional' }, { project_id: 'INST', dependency_type: 'required' }] })],
      B: [mkVersion({ id: 'b1', project_id: 'B', dependencies: [{ project_id: 'A', dependency_type: 'required' }] })], // cycle back to A
    };
    const client = { versionsFor: async (id: string) => versions[id] ?? [], version: async () => { throw new Error('unused'); } };
    const plan = await planInstall(client as any, 'A', '1.21.1', 'fabric', new Set(['INST']));
    expect(plan.map((p) => p.projectId)).toEqual(['A', 'B']);
  });

  it('explains when no compatible version exists', async () => {
    const client = { versionsFor: async () => [], version: async () => { throw new Error('x'); } };
    await expect(planInstall(client as any, 'X', '1.21.1', 'fabric', new Set())).rejects.toThrow(/supports Minecraft 1.21.1 on fabric/);
  });

  it('installs verified files into the profile and prevents duplicates on re-install', async () => {
    const jar = Buffer.from('mod-bytes');
    const v = mkVersion({ id: 'v', project_id: 'A', files: [{ url: 'http://127.0.0.1:1/never', filename: 'a.jar', primary: true, hashes: { sha1: '', sha512: sha512(jar) }, size: 1 }] });
    const client = { versionsFor: async () => [v], version: async () => v } as any;
    const fetchFn = (async () => ({ ok: true, status: 200, arrayBuffer: async () => jar.buffer.slice(jar.byteOffset, jar.byteOffset + jar.length) })) as any;
    const gameDir = tmpDir();
    const inst = new ContentInstaller(client, fetchFn);
    const stages: string[] = [];
    const written = await inst.install('A', 'mod', { gameDir, mcVersion: '1.21.1', loader: 'fabric' }, (p) => stages.push(p.stage));
    expect(written).toEqual(['a.jar']);
    expect(fs.readFileSync(path.join(gameDir, 'mods', 'a.jar'))).toEqual(jar);
    expect(stages.at(-1)).toBe('done');
    expect(await inst.install('A', 'mod', { gameDir, mcVersion: '1.21.1', loader: 'fabric' }, () => {})).toEqual([]);
  });
});

function pack(index: object, extra: Record<string, Uint8Array> = {}) {
  return zipSync({ 'modrinth.index.json': strToU8(JSON.stringify(index)), ...extra });
}
const goodIndex = (files: any[] = []) => ({ formatVersion: 1, game: 'minecraft', name: 'My Pack', files, dependencies: { minecraft: '1.20.1', 'fabric-loader': '0.15.7' } });

describe('modrinth modpacks (.mrpack)', () => {
  it('parses the manifest, loader and overrides', () => {
    const p = parseMrpack(pack(goodIndex(), { 'overrides/config/a.toml': strToU8('x=1'), 'client-overrides/options.txt': strToU8('fov:70') }));
    expect(p).toMatchObject({ minecraft: '1.20.1', loader: 'fabric', loaderVersion: '0.15.7' });
    expect([...p.overrides.keys()].sort()).toEqual(['config/a.toml', 'options.txt']);
  });
  it('rejects archives that are not modpacks or have bad formats', () => {
    expect(() => parseMrpack(zipSync({ 'a.txt': strToU8('x') }))).toThrow(/modrinth.index.json/);
    expect(() => parseMrpack(pack({ ...goodIndex(), formatVersion: 2 }))).toThrow(/Unsupported/);
  });
  it('rejects path traversal in files and overrides', () => {
    const evil = { path: '../../evil.jar', hashes: { sha1: '', sha512: '' }, downloads: ['https://cdn.modrinth.com/a'], fileSize: 1 };
    expect(() => parseMrpack(pack(goodIndex([evil])))).toThrow(/unsafe path/);
    expect(() => parseMrpack(pack(goodIndex(), { 'overrides/../escape.txt': strToU8('x') }))).toThrow(/unsafe path/);
  });
  it('rejects downloads from hosts outside the allow-list or over http', () => {
    const f = (url: string) => ({ path: 'mods/a.jar', hashes: { sha1: '', sha512: '' }, downloads: [url], fileSize: 1 });
    expect(() => parseMrpack(pack(goodIndex([f('https://evil.example/a.jar')])))).toThrow(/not allowed/);
    expect(() => parseMrpack(pack(goodIndex([f('http://cdn.modrinth.com/a.jar')])))).toThrow(/not allowed/);
    expect(() => parseMrpack(pack(goodIndex([f('https://cdn.modrinth.com/a.jar')])))).not.toThrow();
  });
  it('cleans up partial imports when a download fails its hash check', async () => {
    const good = Buffer.from('ok-file');
    const files = [
      { path: 'mods/good.jar', hashes: { sha1: '', sha512: sha512(good) }, downloads: ['https://cdn.modrinth.com/good'], fileSize: 1 },
      { path: 'mods/bad.jar', hashes: { sha1: '', sha512: 'f'.repeat(128) }, downloads: ['https://cdn.modrinth.com/bad'], fileSize: 1 },
    ];
    const parsed = parseMrpack(pack(goodIndex(files), { 'overrides/config/x.toml': strToU8('k=v') }));
    const fetchFn = (async (url: string) => {
      const body = url.endsWith('good') ? good : Buffer.from('tampered');
      return { ok: true, status: 200, arrayBuffer: async () => body.buffer.slice(body.byteOffset, body.byteOffset + body.length) };
    }) as any;
    const dir = tmpDir();
    const stages: string[] = [];
    await expect(applyMrpack(parsed, dir, fetchFn, (p) => stages.push(p.stage), 'pk')).rejects.toThrow(/Checksum/);
    expect(fs.existsSync(path.join(dir, 'mods', 'good.jar'))).toBe(false);
    expect(stages.at(-1)).toBe('failed');
  });
});
