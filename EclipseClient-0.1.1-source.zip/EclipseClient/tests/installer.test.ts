import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { zipSync } from 'fflate';
import { downloadVerified, installVersion } from '../apps/launcher/electron/core/installer';
import type { Env, VersionJson } from '../apps/launcher/electron/core/launchPlan';
import { tmpDir } from './helpers';

const sha1 = (b: Buffer | Uint8Array) => crypto.createHash('sha1').update(b).digest('hex');
const files = new Map<string, Buffer>();
let server: http.Server;
let base = '';
const realFetch: any = (url: string, init?: any) => fetch(url, init);

beforeAll(async () => {
  server = http.createServer((req, res) => {
    const f = files.get(req.url ?? '');
    if (!f) { res.statusCode = 404; return res.end(); }
    res.end(f);
  });
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + (server.address() as any).port;
});
afterAll(() => void server.close());

describe('installer', () => {
  it('downloads with verification, reports real progress, and extracts natives safely', async () => {
    const client = Buffer.from('client-jar');
    const lib = Buffer.from('lib-jar');
    const native = Buffer.from(zipSync({ 'libfoo.so': new Uint8Array([1, 2, 3]), '../evil.so': new Uint8Array([9]), 'META-INF/x': new Uint8Array([0]) }));
    const asset = Buffer.from('asset-data');
    const index = Buffer.from(JSON.stringify({ objects: { 'a/b.ogg': { hash: sha1(asset), size: asset.length } } }));
    files.set('/client.jar', client); files.set('/lib.jar', lib); files.set('/native.jar', native);
    files.set('/idx.json', index); files.set('/assets/' + sha1(asset).slice(0, 2) + '/' + sha1(asset), asset);
    const v: VersionJson = {
      id: 't1', mainClass: 'M', downloads: { client: { url: base + '/client.jar', sha1: sha1(client), size: 1 } },
      assetIndex: { id: 'idx', url: base + '/idx.json', sha1: sha1(index) },
      libraries: [
        { name: 'l', downloads: { artifact: { path: 'l/lib.jar', url: base + '/lib.jar', sha1: sha1(lib), size: 1 } } },
        { name: 'n', natives: { linux: 'natives-linux' }, downloads: { classifiers: { 'natives-linux': { path: 'n/native.jar', url: base + '/native.jar', sha1: sha1(native), size: 1 } } } },
      ],
    };
    const root = tmpDir();
    const dirs = { versions: path.join(root, 'versions'), libraries: path.join(root, 'libraries'), assets: path.join(root, 'assets') };
    const env: Env = { os: 'linux', arch: 'x64', features: {} };
    const seen: number[] = [];
    const out = await installVersion(v, dirs, env, realFetch, (p) => seen.push(p.done / p.total), undefined, base + '/assets');
    expect(seen.at(-1)).toBe(1);
    expect(seen).toEqual([...seen].sort((a, b) => a - b));
    expect(fs.existsSync(path.join(out.nativesDir, 'libfoo.so'))).toBe(true);
    expect(fs.existsSync(path.join(out.nativesDir, 'evil.so'))).toBe(true); // traversal entry is flattened INSIDE natives
    expect(fs.existsSync(path.join(root, 'versions', 'evil.so'))).toBe(false);
    expect(fs.existsSync(path.join(out.nativesDir, 'x'))).toBe(false);
    expect(out.classpath.at(-1)).toMatch(/t1\.jar$/);
    // second run is a cache hit and downloads nothing
    files.clear(); // server now 404s everything: a fully cached reinstall must still succeed
    await expect(installVersion(v, dirs, env, realFetch, () => {}, undefined, base + '/assets')).resolves.toBeTruthy();
  });

  it('rejects corrupted downloads and leaves no file behind', async () => {
    files.set('/bad.jar', Buffer.from('tampered'));
    const dest = path.join(tmpDir(), 'bad.jar');
    await expect(downloadVerified(realFetch, base + '/bad.jar', dest, { algo: 'sha1', hash: 'deadbeef' })).rejects.toThrow(/Checksum mismatch/);
    expect(fs.existsSync(dest)).toBe(false);
    expect(fs.existsSync(dest + '.part')).toBe(false);
  });
});
