#!/usr/bin/env bash
# Compiles and runs the pure-Java core tests with the JDK compiler module; needs only a JDK 21, no Maven access.
set -euo pipefail
cd "$(dirname "$0")/../clients/fabric-1.21.1"
OUT="$(mktemp -d)"
export JAVA_TOOL_OPTIONS=""
java -m jdk.compiler/com.sun.tools.javac.Main -Xlint:all -d "$OUT" $(find src/main/java/gg/eclipse/client/core src/test -name '*.java')
java -cp "$OUT" gg.eclipse.client.core.CoreTests
