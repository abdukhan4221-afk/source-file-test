"""Renders every launcher page at the required resolutions using the QA (mock-bridge) build and flags layout defects."""
import http.server, os, socketserver, sys, threading, functools
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIST = os.path.join(ROOT, 'apps/launcher/dist-qa')
OUT = os.path.join(ROOT, 'docs/screenshots/qa')
os.makedirs(OUT, exist_ok=True)
handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=DIST)
handler.log_message = lambda *a, **k: None
srv = socketserver.TCPServer(('127.0.0.1', 0), handler); port = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

SIZES = [(1920, 1080), (1600, 900), (1366, 768), (1280, 720)]
PAGES = ['Home', 'Profiles', 'Servers', 'Discover', 'Locker', 'Store', 'Settings', 'About']
# Flags: horizontal page overflow, interactive controls cut off by the stage edge, text clipped inside buttons.
CHECK = """() => {
  const issues = [];
  const stage = document.querySelector('.stage').getBoundingClientRect();
  const page = document.querySelector('.page, .home');
  if (page && page.scrollWidth > page.clientWidth + 1) issues.push('horizontal overflow ' + page.scrollWidth + '>' + page.clientWidth);
  for (const el of document.querySelectorAll('.stage button, .stage input, .stage select')) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) continue;
    if (el.closest('[hidden]')) continue;
    const inScroll = el.closest('.page');
    if (r.left < stage.left - 1 || r.right > stage.right + 1) issues.push('outside horizontally: ' + (el.textContent || el.ariaLabel || el.tagName).trim().slice(0, 30));
    if (!inScroll && (r.bottom > stage.bottom + 1 || r.top < stage.top - 1)) issues.push('outside vertically: ' + (el.textContent || '').trim().slice(0, 30));
    if (el.tagName === 'BUTTON' && el.scrollWidth > el.clientWidth + 1 && getComputedStyle(el).overflow !== 'visible') issues.push('clipped text: ' + el.textContent.trim().slice(0, 30));
  }
  return issues;
}"""
bad = 0
with sync_playwright() as p:
    b = p.chromium.launch()
    for w, h in SIZES:
        pg = b.new_page(viewport={'width': w, 'height': h})
        pg.goto(f'http://127.0.0.1:{port}/index.html'); pg.wait_for_selector('.app', timeout=15000)
        for name in PAGES:
            pg.click(f'nav >> text={name}'); pg.wait_for_timeout(350)
            issues = pg.evaluate(CHECK)
            if name in ('Home', 'Discover', 'Settings') or w == 1280:
                pg.screenshot(path=f'{OUT}/{name.lower()}-{w}x{h}.png')
            print(f'{"FAIL" if issues else "ok  "} {w}x{h} {name}' + (f'  {issues[:3]}' if issues else ''))
            bad += bool(issues)
        pg.close()
    b.close()
print('\nlayout defects found:', bad); sys.exit(1 if bad else 0)
