"""Real-app smoke test: launches Electron, drives it over CDP, checks IPC, isolation and on-disk effects."""
import json, os, shutil, signal, subprocess, sys, time, urllib.request
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UD = '/tmp/eclipse-ud'
SHOTS = os.path.join(ROOT, 'docs', 'screenshots')
shutil.rmtree(UD, ignore_errors=True)
os.makedirs(os.path.join(UD, 'eclipse'))
# Seed an offline version cache (the sandbox cannot reach Mojang). Test data only.
vers = [{'id': i, 'type': t, 'url': 'https://piston-meta.mojang.com/' + i, 'releaseTime': '2024-01-01T00:00:00+00:00'}
        for i, t in [('1.21.1', 'release'), ('1.20.1', 'release'), ('1.8.9', 'release'), ('24w40a', 'snapshot'), ('b1.7.3', 'old_beta')]]
json.dump({'fetchedAt': int(time.time() * 1000), 'versions': vers}, open(os.path.join(UD, 'eclipse', 'version-cache.json'), 'w'))

# ECLIPSE_EXE=release/linux-unpacked/eclipse-client tests the PACKAGED app; otherwise the dev tree is run.
EXE = os.environ.get('ECLIPSE_EXE')
launch = [os.path.join(ROOT, EXE)] if EXE else [os.path.join(ROOT, 'node_modules/electron/dist/electron'), os.path.join(ROOT, 'apps/launcher')]
print('testing', 'PACKAGED app' if EXE else 'dev tree')
proc = subprocess.Popen(
    ['xvfb-run', '-a', '-s', '-screen 0 1600x900x24', *launch, '--no-sandbox', '--remote-debugging-port=9333', f'--user-data-dir={UD}'],
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, text=True, start_new_session=True)
results = []
def check(name, ok, extra=''):
    results.append((name, bool(ok)))
    print(('PASS ' if ok else 'FAIL ') + name + (f'  [{extra}]' if extra else ''))

try:
    for _ in range(60):
        try:
            urllib.request.urlopen('http://127.0.0.1:9333/json/version', timeout=1); break
        except Exception: time.sleep(0.5)
    with sync_playwright() as p:
        browser = p.chromium.connect_over_cdp('http://127.0.0.1:9333')
        page = browser.contexts[0].pages[0]
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.set_viewport_size({'width': 1440, 'height': 860})
        page.wait_for_selector('.app', timeout=20000)
        check('startup finishes and app shell renders', True)

        iso = page.evaluate("() => ({ req: typeof require, proc: typeof process, bridge: Object.keys(window.eclipse || {}).sort().join(',') })")
        check('renderer has no Node access (context isolation)', iso['req'] == 'undefined' and iso['proc'] == 'undefined', json.dumps(iso))
        check('bridge exposes only the typed surface', iso['bridge'] == 'accounts,java,launch,modrinth,profiles,servers,settings,system,versions', iso['bridge'])
        raw = page.evaluate("() => window.eclipse.system.appVersion().then(v => v)")
        check('IPC round trip works (appVersion)', raw == '0.1.0', raw)
        denied = page.evaluate("""() => window.eclipse.system.openExternal('http://insecure.example').then(() => 'allowed', e => String(e.message))""")
        check('openExternal rejects non-https', 'https' in denied, denied[-60:])
        page.screenshot(path=f'{SHOTS}/real-home-empty.png')

        page.click('text=Settings'); page.click('role=tab[name="Accounts"]')
        page.fill('input[aria-label="Local username"]', 'ab')
        page.click('text=Add local account'); page.wait_for_selector('.toast.error', timeout=5000)
        check('invalid username is rejected with a visible error', 'characters' in page.inner_text('.toast.error'))
        page.fill('input[aria-label="Local username"]', 'Steve_01'); page.click('text=Add local account')
        page.wait_for_selector('.list .item:has-text("Steve_01")', timeout=5000)
        acc = json.load(open(f'{UD}/eclipse/accounts.json'))
        check('local account persisted to disk', acc['accounts'][0]['username'] == 'Steve_01')

        page.click('text=Profiles'); page.wait_for_selector('text=Create profile')
        page.click('button:has-text("1.21.1")'); page.fill('#pn', 'Survival test'); page.click('button.primary:has-text("Create profile")')
        page.wait_for_selector('.list .item:has-text("Survival test")', timeout=5000)
        inst = os.listdir(f'{UD}/eclipse/instances')[0]
        subs = sorted(os.listdir(f'{UD}/eclipse/instances/{inst}'))
        check('profile creates an isolated instance folder', {'mods', 'saves', 'config', 'resourcepacks', 'shaderpacks'} <= set(subs), ','.join(subs))
        page.screenshot(path=f'{SHOTS}/real-profiles.png')

        page.click('nav >> text=Home'); page.wait_for_selector('.play')
        check('Home shows the selected profile', 'Survival test' in page.inner_text('.home-title'))
        page.screenshot(path=f'{SHOTS}/real-home.png')
        page.click('.play'); page.wait_for_selector('.overlay', timeout=5000)
        page.wait_for_selector('.error-box', timeout=30000)
        msg = page.inner_text('.error-box')
        check('Play fails honestly when Mojang is unreachable (no fake success)', 'Could not get the Minecraft 1.21.1' in msg, msg.replace('\n', ' ')[:110])
        failed_stage = page.inner_text('.stages li[data-state="failed"]').strip()
        check('overlay marks the stage that actually failed', failed_stage == 'Checking game installation', failed_stage)
        page.screenshot(path=f'{SHOTS}/real-launch-failed.png')
        page.click('button:has-text("Close")'); page.wait_for_selector('.play:not([disabled])')
        check('Play button recovers after a failed launch', True)
        check('no uncaught renderer exceptions', not errors, '; '.join(errors)[:120])
        browser.close()
finally:
    try: os.killpg(proc.pid, signal.SIGTERM)
    except ProcessLookupError: pass
    try: proc.wait(8)
    except Exception: os.killpg(proc.pid, signal.SIGKILL)

failed = [n for n, ok in results if not ok]
print(f'\n{len(results) - len(failed)}/{len(results)} checks passed')
sys.exit(1 if failed else 0)
