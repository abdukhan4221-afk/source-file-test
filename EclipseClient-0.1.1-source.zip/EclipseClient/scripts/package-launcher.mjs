#!/usr/bin/env node
// Packages the launcher from an ISOLATED staging directory.
// Why: electron-builder runs `npm install --omit=dev` in the app folder, which in an npm workspace prunes the shared,
// hoisted root node_modules (it deletes vitest, electron and electron-builder's own binaries mid-build).
// Usage: node scripts/package-launcher.mjs [--linux|--win|--mac] [dir|installer]
import { cpSync, mkdirSync, rmSync, writeFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = path.join(root, 'apps/launcher');
const stage = path.join(root, '.stage/launcher');
const platform = process.argv.includes('--win') ? '--win' : process.argv.includes('--mac') ? '--mac' : '--linux';
const dirOnly = process.argv.includes('dir');

rmSync(stage, { recursive: true, force: true });
mkdirSync(path.join(stage, 'vendor/shared-types'), { recursive: true });
cpSync(path.join(app, 'dist'), path.join(stage, 'dist'), { recursive: true });
cpSync(path.join(app, 'dist-electron'), path.join(stage, 'dist-electron'), { recursive: true });
cpSync(path.join(root, 'packages/shared-types/dist'), path.join(stage, 'vendor/shared-types/dist'), { recursive: true });
cpSync(path.join(root, 'packages/shared-types/package.json'), path.join(stage, 'vendor/shared-types/package.json'));

const pkg = JSON.parse(readFileSync(path.join(app, 'package.json'), 'utf8'));
const staged = {
  name: 'eclipse-client', version: pkg.version, description: pkg.description, main: pkg.main, author: pkg.author, homepage: pkg.homepage, license: pkg.license,
  dependencies: { fflate: pkg.dependencies.fflate, '@eclipse/shared-types': 'file:vendor/shared-types' },
  build: { ...pkg.build, directories: { output: path.join(root, 'release') } },
};
writeFileSync(path.join(stage, 'package.json'), JSON.stringify(staged, null, 2));

execFileSync('npm', ['install', '--omit=dev', '--no-audit', '--no-fund', '--install-links'], { cwd: stage, stdio: 'inherit' });
const builder = path.join(root, 'node_modules/electron-builder/cli.js');
execFileSync(process.execPath, [builder, platform, ...(dirOnly ? ['dir'] : []), '--publish', 'never', '--projectDir', stage], { cwd: stage, stdio: 'inherit' });
console.log('\nPackaged into', path.join(root, 'release'));
