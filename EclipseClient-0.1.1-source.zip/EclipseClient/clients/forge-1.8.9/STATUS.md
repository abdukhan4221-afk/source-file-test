# Forge 1.8.9 status: skeleton only

- Implemented: mod entry point and a single FPS HUD element.
- Not implemented: title screen, loading screen, Right Shift workspace, the other modules, configuration.
- Not built: the authoring environment could not reach the Forge Maven repository or run Gradle 2.x/3.x.
- To build: use JDK 8 and a ForgeGradle 2.1 compatible Gradle (e.g. 2.14.1), then `gradle build`.
