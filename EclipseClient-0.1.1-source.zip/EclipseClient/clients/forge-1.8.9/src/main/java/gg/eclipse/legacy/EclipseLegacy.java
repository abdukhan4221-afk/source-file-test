package gg.eclipse.legacy;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * Legacy (1.8.9, Java 8) entry point. Deliberately shares no code with the Fabric 1.21.1 client: the Forge 1.8.9 API,
 * mappings and Java level are different. STATUS: skeleton. One HUD element (FPS) so the pipeline has something real;
 * the workspace, title screen, loading screen and remaining modules are not implemented for 1.8.9.
 * Uncompiled: written against the 1.8.9 Forge API from memory and must be built before any claim of working.
 */
@Mod(modid = "eclipselegacy", name = "Eclipse Client (1.8.9)", version = "0.1.0", clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class EclipseLegacy {
    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.TEXT) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.showDebugInfo) return;
        mc.fontRendererObj.drawStringWithShadow(Minecraft.getDebugFPS() + " FPS", 4, 4, 0xF2F0EA);
    }
}
