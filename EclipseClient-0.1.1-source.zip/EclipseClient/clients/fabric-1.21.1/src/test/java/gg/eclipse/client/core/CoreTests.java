package gg.eclipse.client.core;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZoneId;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/** Dependency-free test runner so the core can be verified with plain javac (no Maven access needed). */
public final class CoreTests {
    static int passed, failed;

    static void check(String name, boolean ok) {
        if (ok) passed++; else { failed++; System.out.println("FAIL " + name); }
    }
    static void eq(String name, Object a, Object b) {
        boolean ok = a == null ? b == null : a.equals(b);
        if (!ok) System.out.println("   expected " + b + " but got " + a);
        check(name, ok);
    }

    static final class Probe extends Module {
        final Setting.Bool flag = add(new Setting.Bool("flag", "Flag", true));
        final Setting.IntRange size = add(new Setting.IntRange("size", "Size", 10, 0, 100, 5));
        final Setting.Choice mode = add(new Setting.Choice("mode", "Mode", "a", List.of("a", "b", "c")));
        final AtomicInteger ticks = new AtomicInteger(), enables = new AtomicInteger(), disables = new AtomicInteger();
        Probe(String id, Category c) { super(id, id.toUpperCase(), c, "Probe module " + id); }
        @Override protected void onEnable() { enables.incrementAndGet(); }
        @Override protected void onDisable() { disables.incrementAndGet(); }
        @Override public void onTick() { ticks.incrementAndGet(); }
    }

    public static void main(String[] args) throws Exception {
        settings(); registry(); hud(); cps(); frames(); formats(); scroll(); grid(); layouts(); profiles();
        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }

    static void settings() {
        Setting.IntRange r = new Setting.IntRange("x", "X", 10, 0, 100, 5);
        r.set(500); eq("int clamps high", r.get(), 100);
        r.set(-3); eq("int clamps low", r.get(), 0);
        r.setFromFraction(0.5); eq("fraction maps to range", r.get(), 50);
        r.setFromFraction(0.52); eq("fraction honours step", r.get(), 50);
        r.deserialize("garbage"); eq("bad serialised int falls back to default", r.get(), 10);
        Setting.Choice c = new Setting.Choice("m", "M", "zzz", List.of("a", "b"));
        eq("unknown default falls back to first option", c.get(), "a");
        c.cycle(); c.cycle(); eq("choice cycles and wraps", c.get(), "a");
        c.deserialize("nope"); eq("unknown choice rejected", c.get(), "a");
    }

    static void registry() {
        ModuleRegistry reg = new ModuleRegistry();
        Probe a = new Probe("fps", Category.HUD), b = new Probe("zoom", Category.MECHANICS);
        reg.register(a); reg.register(b);
        try { reg.register(new Probe("fps", Category.HUD)); check("duplicate id rejected", false); } catch (IllegalArgumentException e) { check("duplicate id rejected", true); }
        reg.tick(); eq("disabled modules are not ticked", a.ticks.get(), 0);
        a.setEnabled(true); a.setEnabled(true); reg.tick(); reg.tick();
        eq("enable hook fires once", a.enables.get(), 1); eq("enabled module ticks", a.ticks.get(), 2);
        a.setEnabled(false); reg.tick(); eq("disable hook fires and ticking stops", a.disables.get() + a.ticks.get(), 3);
        eq("search by name", reg.search("zo", null, false).size(), 1);
        eq("search by description", reg.search("probe module fps", null, false).get(0).id, "fps");
        eq("category filter", reg.search("", Category.HUD, false).size(), 1);
        b.setFavorite(true); eq("favourites filter", reg.search("", null, true).get(0).id, "zoom");
        b.setKeybind(90); check("keybind toggles module", reg.handleKey(90) && b.enabled());
        check("unbound key ignored", !reg.handleKey(-1) && !reg.handleKey(12));
        reg.disableAll(); check("disableAll cleans up", !a.enabled() && !b.enabled() && b.disables.get() == 1);
    }

    static void hud() {
        HudElement e = new HudElement("fps");
        int[] r = e.resolve(960, 540, 60, 12);
        eq("default is top-left with offset", r[0] + "," + r[1], "4,4");
        e.anchor = HudElement.Anchor.BOTTOM_RIGHT; e.offsetX = -4; e.offsetY = -4;
        r = e.resolve(960, 540, 60, 12);
        eq("bottom-right keeps margin", r[0] + "," + r[1], (960 - 60 - 4) + "," + (540 - 12 - 4));
        e.offsetX = 9999; e.offsetY = 9999; r = e.resolve(960, 540, 60, 12);
        check("resolve always stays on screen", r[0] + r[2] <= 960 && r[1] + r[3] <= 540 && r[0] >= 0 && r[1] >= 0);
        e.reset(); e.moveTo(900, 500, 960, 540, 60, 12, 4);
        eq("dragging near corner picks nearest anchor", e.anchor, HudElement.Anchor.BOTTOM_RIGHT);
        int[] again = e.resolve(960, 540, 60, 12);
        check("drag then resolve round-trips (snapped to grid)", again[0] % 4 == 0 && again[0] + again[2] <= 960);
        int[] small = e.resolve(480, 270, 60, 12);
        check("layout survives a smaller GUI scale", small[0] + small[2] <= 480 && small[1] + small[3] <= 270);
        e.setScale(500); eq("scale clamped", e.scalePercent, 200);
        e.setOpacity(0); eq("opacity clamped", e.opacityPercent, 10);
        HudElement big = new HudElement("x"); big.setScale(200);
        int[] huge = big.resolve(100, 50, 300, 300);
        check("oversized element does not go negative", huge[0] == 0 && huge[1] == 0);
    }

    static void cps() {
        AtomicLong t = new AtomicLong(10_000);
        CpsCounter c = new CpsCounter(t::get);
        for (int i = 0; i < 5; i++) { c.update(true); t.addAndGet(50); c.update(false); t.addAndGet(50); }
        eq("counts five clicks", c.cps(), 5);
        t.addAndGet(1000); eq("old clicks expire after one second", c.cps(), 0);
        c.update(true); c.update(true); c.update(true); eq("holding the button is one click", c.cps(), 1);
    }

    static void frames() {
        FrameStats f = new FrameStats(8);
        long t = 0;
        for (int i = 0; i < 20; i++) { f.frame(t); t += 16_666_667L; }
        eq("60 fps from 16.67 ms frames", f.fps(), 60);
        f.frame(t + 50_000_000L);
        check("max frame time reflects a spike", f.maxMs() >= 66);
        eq("empty stats report zero", new FrameStats(4).fps(), 0);
    }

    static void formats() {
        eq("south", Format.direction(0), "S"); eq("west", Format.direction(90), "W");
        eq("north", Format.direction(180), "N"); eq("east", Format.direction(270), "E");
        eq("negative yaw wraps (-90 = east)", Format.direction(-90), "E");
        eq("north-east", Format.direction(225), "NE");
        eq("coords", Format.coords(1.234, 64, -5.5, 1), "1.2, 64.0, -5.5");
        eq("24h clock", Format.clock(0, ZoneId.of("UTC"), true), "00:00");
        eq("potion duration", Format.duration(20 * 65), "1:05");
        eq("infinite potion", Format.duration(-1), "inf");
        eq("memory", Format.memory(512L << 20, 4096L << 20), "512 / 4096 MB");
    }

    static void scroll() {
        ScrollModel s = new ScrollModel();
        s.layout(300, 1000);
        s.wheel(-1); eq("wheel down scrolls content up", s.offset(), ScrollModel.WHEEL_STEP);
        s.wheel(1); s.wheel(1); eq("wheel never goes above the top", s.offset(), 0);
        for (int i = 0; i < 500; i++) s.wheel(-1);
        eq("wheel never passes the bottom (nothing unreachable)", s.offset(), 700);
        s.layout(300, 200); eq("content shorter than viewport resets offset", s.offset(), 0);
        check("short content is not scrollable", !s.scrollable());
        s.layout(300, 1000); s.ensureVisible(900, 100); eq("ensureVisible reveals the last card", s.offset(), 700);
        s.layout(300, 1000); int[] th = s.thumb(300);
        check("thumb stays inside its track", th[0] >= 0 && th[0] + th[1] <= 300);
        s.layout(300, 1_000_000); check("thumb has a minimum size", s.thumb(300)[1] >= 12);
        s.layout(300, 1000); s.dragThumb(299, 300); eq("dragging to the track end reaches the bottom", s.offset(), 700);
    }

    static void grid() {
        for (int w : new int[] { 200, 320, 427, 480, 640, 853, 960 }) {
            CardGrid g = new CardGrid(w, 140, 56, 6, 23);
            int[] last = g.rect(22);
            boolean fits = true;
            for (int i = 0; i < 23; i++) { int[] r = g.rect(i); if (r[0] + r[2] > w || r[0] < 0) fits = false; }
            check("every card fits horizontally at width " + w, fits);
            check("content height covers the last card at width " + w, last[1] + last[3] == g.contentH);
        }
        CardGrid narrow = new CardGrid(100, 140, 56, 6, 3);
        eq("never fewer than one column", narrow.columns, 1);
        eq("empty grid has no height", new CardGrid(400, 140, 56, 6, 0).contentH, 0);
        CardGrid g = new CardGrid(640, 140, 56, 6, 100);
        int[] vis = g.visible(0, 300, 100);
        check("visible range is a small window, not everything", vis[1] - vis[0] < 40 && vis[0] == 0);
    }

    static boolean overlap(int[] a, int[] b) {
        return a[0] < b[0] + b[2] && b[0] < a[0] + a[2] && a[1] < b[1] + b[3] && b[1] < a[1] + a[3];
    }

    // GUI-scaled sizes: 1080p at scale 2/3/4, 720p at scale 3/4, and a very small window.
    static final int[][] SIZES = { { 960, 540 }, { 640, 360 }, { 480, 270 }, { 427, 240 }, { 320, 180 }, { 256, 144 } };

    static void layouts() {
        for (int[] sz : SIZES) {
            int w = sz[0], h = sz[1];
            String at = " at " + w + "x" + h;
            TitleLayout t = new TitleLayout(w, h);
            boolean inside = true, noOverlap = true;
            for (int i = 0; i < TitleLayout.CARDS; i++) {
                int[] c = t.card(i);
                if (c[0] < 0 || c[1] < 0 || c[0] + c[2] > w || c[1] + c[3] > h) inside = false;
                for (int j = i + 1; j < TitleLayout.CARDS; j++) if (overlap(c, t.card(j))) noOverlap = false;
            }
            check("title cards inside screen" + at, inside);
            check("title cards do not overlap" + at, noOverlap);
            check("wordmark and info sit above the first card" + at, t.infoY + 9 < t.card(0)[1]);
            check("eclipse is fully on screen" + at, t.eclipseX - t.eclipseR >= 0 && t.eclipseX + t.eclipseR <= w && t.eclipseY - t.eclipseR >= 0 && t.eclipseY + t.eclipseR <= h);
            check("eclipse does not cover the cards" + at, t.eclipseX - t.eclipseR > t.cardX + t.cardW);

            WorkspaceLayout ws = new WorkspaceLayout(w, h);
            check("workspace regions do not overlap" + at, ws.navX + ws.navW <= ws.libX && ws.libX + ws.libW <= ws.detX + (ws.showDetails ? 0 : w - ws.detX));
            check("workspace library keeps a usable width" + at, ws.libW >= 100);
            check("workspace fits the window" + at, ws.detX + ws.detW <= w && ws.bodyY + ws.bodyH + ws.bottomH <= h);
        }
        check("details panel folds away on tiny windows", !new WorkspaceLayout(256, 144).showDetails && new WorkspaceLayout(640, 360).showDetails);
    }

    static void profiles() throws Exception {
        Path dir = Files.createTempDirectory("eclipse-profiles");
        ModuleRegistry reg = new ModuleRegistry();
        Probe p = new Probe("fps", Category.HUD); reg.register(p);
        HudLayout layout = new HudLayout();
        ProfileManager pm = new ProfileManager(dir);

        p.setEnabled(true); p.size.set(35); p.mode.cycle(); p.setKeybind(70); p.setFavorite(true);
        layout.of("fps").anchor = HudElement.Anchor.TOP_RIGHT; layout.of("fps").offsetX = -10; layout.of("fps").setScale(150);
        pm.save("Pvp", reg, layout);

        ProfileManager.restoreDefaults(reg, layout);
        check("restore defaults resets everything", !p.enabled() && p.size.get() == 10 && p.keybind() == -1 && !p.favorite() && layout.of("fps").scalePercent == 100);
        pm.load("Pvp", reg, layout);
        check("profile restores enabled state", p.enabled());
        eq("profile restores settings", p.size.get(), 35); eq("profile restores choice", p.mode.get(), "b");
        eq("profile restores keybind", p.keybind(), 70);
        check("profile restores HUD layout", layout.of("fps").anchor == HudElement.Anchor.TOP_RIGHT && layout.of("fps").offsetX == -10 && layout.of("fps").scalePercent == 150);

        pm.duplicate("Pvp", "Pvp copy"); pm.rename("Pvp copy", "Builder");
        eq("profiles list", pm.list(), List.of("Builder", "Pvp"));
        pm.delete("Builder"); eq("delete removes profile", pm.list(), List.of("Pvp"));

        String text = pm.export("Pvp"); pm.importText("Imported", text);
        check("import round-trips", pm.list().contains("Imported"));
        try { pm.importText("Bad", "hello world"); check("garbage import rejected", false); } catch (java.io.IOException e) { check("garbage import rejected", true); }
        check("failed import wrote nothing", !pm.list().contains("Bad"));
        for (String evil : new String[] { "../escape", "a/b", "", "x".repeat(40), "bad.name" }) {
            try { pm.save(evil, reg, layout); check("path-traversal name rejected: " + evil, false); } catch (IllegalArgumentException e) { check("path-traversal name rejected: " + evil, true); }
        }
        pm.select("Pvp", reg, layout); eq("current profile persists", pm.current(), "Pvp");
        eq("unknown current falls back to Default", new ProfileManager(Files.createTempDirectory("e2")).current(), "Default");
        Files.writeString(dir.resolve("profiles/Corrupt.properties"), "module.fps.s.size=notanumber\nmodule.fps.key=zzz\n");
        pm.load("Corrupt", reg, layout);
        check("corrupt values fall back instead of crashing", p.size.get() == 10 && p.keybind() == -1);
    }
}
