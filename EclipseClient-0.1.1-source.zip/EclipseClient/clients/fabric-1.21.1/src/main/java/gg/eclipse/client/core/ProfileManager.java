package gg.eclipse.client.core;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * In-game configuration profiles: enabled modules, every setting, keybinds, HUD layout. Entirely separate from
 * launcher game instances. One file per profile under {@code <config>/eclipse/profiles/}.
 */
public final class ProfileManager {
    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9 _-]{1,32}");
    private final Path dir;
    private final Path currentFile;

    public ProfileManager(Path configDir) throws IOException {
        this.dir = configDir.resolve("profiles");
        this.currentFile = configDir.resolve("current-profile.txt");
        Files.createDirectories(dir);
    }

    public static boolean validName(String name) { return name != null && NAME.matcher(name).matches() && !name.isBlank(); }

    private Path file(String name) {
        if (!validName(name)) throw new IllegalArgumentException("Profile names use letters, numbers, spaces, - and _ (1 to 32 characters).");
        return dir.resolve(name + ".properties");
    }

    public List<String> list() throws IOException {
        List<String> names = new ArrayList<>();
        try (Stream<Path> s = Files.list(dir)) {
            s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".properties"))
                    .forEach(n -> names.add(n.substring(0, n.length() - ".properties".length())));
        }
        Collections.sort(names);
        return names;
    }

    public String current() {
        try {
            String n = Files.readString(currentFile, StandardCharsets.UTF_8).trim();
            return validName(n) && Files.exists(file(n)) ? n : "Default";
        } catch (IOException e) { return "Default"; }
    }

    public void select(String name, ModuleRegistry reg, HudLayout layout) throws IOException {
        load(name, reg, layout);
        Files.writeString(currentFile, name, StandardCharsets.UTF_8);
    }

    public void save(String name, ModuleRegistry reg, HudLayout layout) throws IOException {
        Files.writeString(file(name), toText(reg, layout), StandardCharsets.UTF_8);
    }

    public void load(String name, ModuleRegistry reg, HudLayout layout) throws IOException {
        Path f = file(name);
        if (!Files.exists(f)) throw new IOException("No profile named " + name);
        apply(Files.readString(f, StandardCharsets.UTF_8), reg, layout);
    }

    public void duplicate(String from, String to) throws IOException {
        if (Files.exists(file(to))) throw new IOException("A profile named " + to + " already exists.");
        Files.copy(file(from), file(to));
    }

    public void rename(String from, String to) throws IOException {
        if (Files.exists(file(to))) throw new IOException("A profile named " + to + " already exists.");
        Files.move(file(from), file(to));
        if (current().equals(from)) Files.writeString(currentFile, to, StandardCharsets.UTF_8);
    }

    public void delete(String name) throws IOException { Files.deleteIfExists(file(name)); }

    public String export(String name) throws IOException { return Files.readString(file(name), StandardCharsets.UTF_8); }

    /** Imports profile text. It is parsed first, so malformed input never overwrites an existing profile. */
    public void importText(String name, String text) throws IOException {
        Properties p = new Properties();
        p.load(new StringReader(text));
        if (!p.stringPropertyNames().stream().anyMatch(k -> k.startsWith("module.") || k.startsWith("hud."))) {
            throw new IOException("That text is not an Eclipse profile.");
        }
        Files.writeString(file(name), text, StandardCharsets.UTF_8);
    }

    public static void restoreDefaults(ModuleRegistry reg, HudLayout layout) {
        for (Module m : reg.all()) { m.setEnabled(false); m.resetSettings(); m.setKeybind(-1); m.setFavorite(false); }
        layout.resetAll();
    }

    // ---- serialisation ----

    public static String toText(ModuleRegistry reg, HudLayout layout) throws IOException {
        Properties p = new Properties();
        for (Module m : reg.all()) {
            String b = "module." + m.id + ".";
            p.setProperty(b + "enabled", Boolean.toString(m.enabled()));
            p.setProperty(b + "favorite", Boolean.toString(m.favorite()));
            p.setProperty(b + "key", Integer.toString(m.keybind()));
            for (Setting<?> s : m.settings()) p.setProperty(b + "s." + s.key, s.serialize());
        }
        for (HudElement e : layout.all().values()) {
            String b = "hud." + e.moduleId + ".";
            p.setProperty(b + "anchor", e.anchor.name());
            p.setProperty(b + "x", Integer.toString(e.offsetX));
            p.setProperty(b + "y", Integer.toString(e.offsetY));
            p.setProperty(b + "scale", Integer.toString(e.scalePercent));
            p.setProperty(b + "opacity", Integer.toString(e.opacityPercent));
            p.setProperty(b + "visible", Boolean.toString(e.visible));
        }
        Writer w = new StringWriter();
        p.store(w, "Eclipse profile");
        return w.toString();
    }

    public static void apply(String text, ModuleRegistry reg, HudLayout layout) throws IOException {
        Properties p = new Properties();
        p.load(new StringReader(text));
        for (Module m : reg.all()) {
            String b = "module." + m.id + ".";
            for (Setting<?> s : m.settings()) { String v = p.getProperty(b + "s." + s.key); if (v != null) s.deserialize(v); }
            String key = p.getProperty(b + "key");
            if (key != null) try { m.setKeybind(Integer.parseInt(key)); } catch (NumberFormatException ignored) { m.setKeybind(-1); }
            m.setFavorite(Boolean.parseBoolean(p.getProperty(b + "favorite", "false")));
            m.setEnabled(Boolean.parseBoolean(p.getProperty(b + "enabled", "false")));
        }
        for (String k : p.stringPropertyNames()) {
            if (!k.startsWith("hud.") || !k.endsWith(".anchor")) continue;
            String id = k.substring(4, k.length() - ".anchor".length());
            HudElement e = layout.of(id);
            String b = "hud." + id + ".";
            try { e.anchor = HudElement.Anchor.valueOf(p.getProperty(b + "anchor")); } catch (IllegalArgumentException ignored) { /* keep */ }
            e.offsetX = intOr(p.getProperty(b + "x"), e.offsetX);
            e.offsetY = intOr(p.getProperty(b + "y"), e.offsetY);
            e.setScale(intOr(p.getProperty(b + "scale"), 100));
            e.setOpacity(intOr(p.getProperty(b + "opacity"), 100));
            e.visible = Boolean.parseBoolean(p.getProperty(b + "visible", "true"));
        }
    }

    private static int intOr(String s, int d) { try { return s == null ? d : Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return d; } }
}
