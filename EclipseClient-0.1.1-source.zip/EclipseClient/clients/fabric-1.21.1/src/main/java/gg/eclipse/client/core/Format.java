package gg.eclipse.client.core;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public final class Format {
    private Format() {}
    private static final String[] COMPASS = { "N", "NE", "E", "SE", "S", "SW", "W", "NW" };

    /** Minecraft yaw: 0 = south, 90 = west, 180 = north, 270 = east. */
    public static String direction(float yaw) {
        double y = ((yaw % 360) + 360) % 360;
        double compass = (y + 180) % 360;
        return COMPASS[(int) Math.round(compass / 45.0) % 8];
    }

    public static String coords(double x, double y, double z, int decimals) {
        String f = "%." + Math.max(0, decimals) + "f";
        return String.format(java.util.Locale.ROOT, f + ", " + f + ", " + f, x, y, z);
    }

    public static String clock(long epochMillis, ZoneId zone, boolean twentyFourHour) {
        return DateTimeFormatter.ofPattern(twentyFourHour ? "HH:mm" : "h:mm a", java.util.Locale.ENGLISH)
                .withZone(zone).format(Instant.ofEpochMilli(epochMillis));
    }

    public static String memory(long usedBytes, long maxBytes) {
        return (usedBytes >> 20) + " / " + (maxBytes >> 20) + " MB";
    }

    /** Potion durations: 1:05, or "inf" for effects with no end. */
    public static String duration(int ticks) {
        if (ticks < 0 || ticks > 20 * 60 * 60 * 24) return "inf";
        int s = ticks / 20;
        return (s / 60) + ":" + String.format("%02d", s % 60);
    }
}
