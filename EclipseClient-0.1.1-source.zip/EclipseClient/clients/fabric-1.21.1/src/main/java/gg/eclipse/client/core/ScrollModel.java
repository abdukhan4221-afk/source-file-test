package gg.eclipse.client.core;

/** Scroll state for a clipped viewport. All offsets are clamped, so content can never be scrolled out of reach. */
public final class ScrollModel {
    private double offset;
    private int viewportH, contentH;
    public static final int WHEEL_STEP = 24;

    public void layout(int viewportH, int contentH) {
        this.viewportH = Math.max(0, viewportH);
        this.contentH = Math.max(0, contentH);
        offset = clamp(offset);
    }

    public int maxOffset() { return Math.max(0, contentH - viewportH); }
    public int offset() { return (int) Math.round(offset); }
    private double clamp(double v) { return Math.max(0, Math.min(maxOffset(), v)); }

    /** Minecraft reports wheel up as a positive delta, which must move the content down (offset decreases). */
    public void wheel(double delta) { offset = clamp(offset - delta * WHEEL_STEP); }
    public void scrollTo(double o) { offset = clamp(o); }

    /** Make a child rect (content coordinates) fully visible, e.g. after keyboard selection. */
    public void ensureVisible(int y, int h) {
        if (y < offset) offset = clamp(y);
        else if (y + h > offset + viewportH) offset = clamp(y + h - viewportH);
    }

    public boolean scrollable() { return contentH > viewportH; }

    /** Scrollbar thumb {y, height} inside a track of the given height; never smaller than 12px. */
    public int[] thumb(int trackH) {
        if (!scrollable()) return new int[] { 0, trackH };
        int h = Math.max(12, (int) Math.round(trackH * (viewportH / (double) contentH)));
        int y = (int) Math.round((trackH - h) * (offset / maxOffset()));
        return new int[] { y, h };
    }

    /** Converts a drag position on the track back into an offset. */
    public void dragThumb(int trackY, int trackH) {
        int[] t = thumb(trackH);
        int usable = Math.max(1, trackH - t[1]);
        scrollTo(maxOffset() * (Math.max(0, Math.min(usable, trackY - t[1] / 2)) / (double) usable));
    }
}
