package gg.eclipse.client.core;

import java.util.ArrayDeque;
import java.util.function.LongSupplier;

/** Clicks per second over a one-second sliding window. The clock is injectable so the logic is testable. */
public final class CpsCounter {
    private final ArrayDeque<Long> clicks = new ArrayDeque<>();
    private final LongSupplier nowMillis;
    private boolean wasDown;

    public CpsCounter(LongSupplier nowMillis) { this.nowMillis = nowMillis; }

    /** Call every tick with the button state; a click is counted on the rising edge only (holding is not clicking). */
    public void update(boolean down) {
        if (down && !wasDown) clicks.addLast(nowMillis.getAsLong());
        wasDown = down;
    }

    public int cps() {
        long cutoff = nowMillis.getAsLong() - 1000;
        while (!clicks.isEmpty() && clicks.peekFirst() <= cutoff) clicks.removeFirst();
        return clicks.size();
    }
}
