package gg.eclipse.client.mc;

import com.mojang.blaze3d.platform.InputConstants;
import gg.eclipse.client.EclipseClient;
import gg.eclipse.client.core.*;
import gg.eclipse.client.core.Module;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.EntityHitResult;

import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/** The modules that have real behaviour in this build. Nothing is registered that does not do something. */
public final class Modules {
    private Modules() {}

    public static final FrameStats FRAMES = new FrameStats(120);
    private static final CpsCounter LEFT = new CpsCounter(System::currentTimeMillis);
    private static final CpsCounter RIGHT = new CpsCounter(System::currentTimeMillis);

    public static void registerAll(ModuleRegistry r) {
        r.register(new HudModule.TextHud("fps", "FPS Counter", "Frames per second, averaged over the last 120 frames.") {
            @Override protected String compute(Minecraft mc) { return FRAMES.fps() + " FPS"; }
        });
        r.register(new HudModule.TextHud("cps", "CPS Counter", "Left and right clicks per second.") {
            @Override protected String compute(Minecraft mc) {
                LEFT.update(mc.options.keyAttack.isDown());
                RIGHT.update(mc.options.keyUse.isDown());
                return LEFT.cps() + " | " + RIGHT.cps() + " CPS";
            }
        });
        r.register(new HudModule.TextHud("ping", "Ping", "Your latency to the server, as the server reports it.") {
            @Override protected String compute(Minecraft mc) {
                if (mc.isSingleplayer()) return "Ping: n/a (singleplayer)";
                if (mc.player == null || mc.getConnection() == null) return "Ping: -";
                var info = mc.getConnection().getPlayerInfo(mc.player.getUUID());
                return info == null ? "Ping: -" : "Ping: " + info.getLatency() + " ms";
            }
            @Override public String compatibility() { return "Multiplayer only. Singleplayer has no network latency."; }
        });
        r.register(new HudModule.TextHud("coords", "Coordinates", "Your position in the world.") {
            final Setting.IntRange decimals = add(new Setting.IntRange("decimals", "Decimals", 1, 0, 3, 1));
            @Override protected String compute(Minecraft mc) {
                if (mc.player == null) return "-";
                return Format.coords(mc.player.getX(), mc.player.getY(), mc.player.getZ(), decimals.get());
            }
        });
        r.register(new HudModule.TextHud("direction", "Direction HUD", "The compass direction you are facing.") {
            @Override protected String compute(Minecraft mc) { return mc.player == null ? "-" : "Facing " + Format.direction(mc.player.getYRot()); }
        });
        r.register(new HudModule.TextHud("clock", "Clock", "Your computer's local time.") {
            final Setting.Bool h24 = add(new Setting.Bool("h24", "24-hour time", true));
            @Override protected String compute(Minecraft mc) { return Format.clock(System.currentTimeMillis(), ZoneId.systemDefault(), h24.get()); }
        });
        r.register(new HudModule.TextHud("memory", "Memory Monitor", "Java heap in use against the maximum.") {
            int n;
            @Override protected String compute(Minecraft mc) {
                if (n++ % 10 != 0 && !text.isEmpty()) return text; // memory changes slowly; refresh twice a second
                Runtime rt = Runtime.getRuntime();
                return Format.memory(rt.totalMemory() - rt.freeMemory(), rt.maxMemory());
            }
            @Override public String compatibility() { return "Client only."; }
        });
        r.register(new HudModule.TextHud("frametime", "Frame Time Monitor", "Average, best and worst frame time (ms).") {
            @Override protected String compute(Minecraft mc) {
                return String.format(java.util.Locale.ROOT, "%.1f ms (%.1f - %.1f)", FRAMES.avgMs(), FRAMES.minMs(), FRAMES.maxMs());
            }
        });
        r.register(new HudModule.TextHud("target", "Target HUD", "Name and health of the creature you are looking at.") {
            @Override protected String compute(Minecraft mc) {
                if (mc.hitResult instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity le) {
                    return le.getName().getString() + "  " + Math.round(le.getHealth()) + "/" + Math.round(le.getMaxHealth());
                }
                return "No target";
            }
        });
        r.register(new HudModule("keystrokes", "Keystrokes", "Shows movement keys, jump and mouse buttons as you press them.") {
            @Override public int width(Font f) { return 58; }
            @Override public int height(Font f) { return 72; }
            private void key(GuiGraphics g, Font f, int x, int y, int w, int h, String label, boolean down, float a) {
                g.fill(x, y, x + w, y + h, Gfx.alpha(down ? Gfx.BURNT : Gfx.SURFACE, down ? a : 0.78f * a));
                g.drawString(f, label, x + (w - f.width(label)) / 2, y + (h - 8) / 2, Gfx.alpha(down ? Gfx.OBSIDIAN : Gfx.TEXT, a), false);
            }
            @Override public void draw(GuiGraphics g, Font f, int x, int y, float a) {
                var o = Minecraft.getInstance().options;
                key(g, f, x + 20, y, 18, 18, "W", o.keyUp.isDown(), a);
                key(g, f, x, y + 20, 18, 18, "A", o.keyLeft.isDown(), a);
                key(g, f, x + 20, y + 20, 18, 18, "S", o.keyDown.isDown(), a);
                key(g, f, x + 40, y + 20, 18, 18, "D", o.keyRight.isDown(), a);
                key(g, f, x, y + 40, 58, 12, "JUMP", o.keyJump.isDown(), a);
                key(g, f, x, y + 54, 28, 18, "LMB", o.keyAttack.isDown(), a);
                key(g, f, x + 30, y + 54, 28, 18, "RMB", o.keyUse.isDown(), a);
            }
        });
        r.register(new HudModule("armor", "Armor HUD", "Your equipped armor and its durability.") {
            @Override public int width(Font f) { return 18; }
            @Override public int height(Font f) { return 72; }
            @Override public void draw(GuiGraphics g, Font f, int x, int y, float a) {
                var mc = Minecraft.getInstance();
                if (mc.player == null) return;
                var armor = mc.player.getInventory().armor; // 0 = boots ... 3 = helmet
                for (int i = 0; i < 4; i++) {
                    ItemStack s = armor.get(3 - i);
                    if (s.isEmpty()) continue;
                    g.renderItem(s, x + 1, y + i * 18 + 1);
                    g.renderItemDecorations(f, s, x + 1, y + i * 18 + 1);
                }
            }
        });
        r.register(new HudModule("potion", "Potion HUD", "Active potion effects with time remaining.") {
            private final List<String> lines = new ArrayList<>();
            private int n;
            @Override public void onTick() {
                if (n++ % 5 != 0) return;
                lines.clear();
                var mc = Minecraft.getInstance();
                if (mc.player == null) return;
                Collection<MobEffectInstance> fx = mc.player.getActiveEffects();
                for (MobEffectInstance e : fx) {
                    String nm = e.getEffect().value().getDisplayName().getString();
                    lines.add(nm + (e.getAmplifier() > 0 ? " " + (e.getAmplifier() + 1) : "") + "  " + Format.duration(e.isInfiniteDuration() ? -1 : e.getDuration()));
                }
            }
            @Override public int width(Font f) { int w = 80; for (String s : lines) w = Math.max(w, f.width(s) + 8); return w; }
            @Override public int height(Font f) { return Math.max(12, lines.size() * 12); }
            @Override public void draw(GuiGraphics g, Font f, int x, int y, float a) {
                if (lines.isEmpty()) { g.drawString(f, "No effects", x + 2, y + 2, Gfx.alpha(Gfx.TEXT2, a), false); return; }
                for (int i = 0; i < lines.size(); i++) {
                    g.fill(x, y + i * 12, x + width(f), y + i * 12 + 12, Gfx.alpha(Gfx.SURFACE, 0.78f * a));
                    g.drawString(f, lines.get(i), x + 4, y + i * 12 + 2, Gfx.alpha(Gfx.TEXT, a), false);
                }
            }
        });

        r.register(new Module("togglesprint", "Toggle Sprint", Category.MECHANICS, "Keeps you sprinting while you hold forward.") {
            @Override public void onTick() {
                var mc = Minecraft.getInstance();
                if (mc.player != null && mc.screen == null && mc.options.keyUp.isDown() && !mc.player.isUsingItem() && !mc.player.horizontalCollision) {
                    mc.player.setSprinting(true);
                }
            }
            @Override public String compatibility() { return "Client only. The game still stops sprint when hunger is too low."; }
        });
        r.register(new Module("togglesneak", "Toggle Sneak", Category.MECHANICS, "Press the sneak key once to sneak, again to stop.") {
            private boolean toggled, wasDown;
            @Override public void onTick() {
                var mc = Minecraft.getInstance();
                if (mc.player == null) return;
                int code = KeyBindingHelper.getBoundKeyOf(mc.options.keyShift).getValue();
                boolean physical = mc.screen == null && InputConstants.isKeyDown(mc.getWindow().getWindow(), code);
                if (physical && !wasDown) toggled = !toggled;
                wasDown = physical;
                mc.options.keyShift.setDown(toggled || physical);
            }
            @Override protected void onDisable() {
                toggled = false;
                var mc = Minecraft.getInstance();
                if (mc.options != null) mc.options.keyShift.setDown(false);
            }
        });
        r.register(new Module("zoom", "Zoom", Category.MECHANICS, "Hold the zoom key (default C) to narrow your field of view.") {
            final Setting.IntRange fov = add(new Setting.IntRange("fov", "Zoom FOV", 30, 30, 70, 5));
            private Integer original;
            @Override public void onTick() {
                var mc = Minecraft.getInstance();
                boolean held = mc.screen == null && EclipseClient.ZOOM_KEY != null && EclipseClient.ZOOM_KEY.isDown();
                if (held) {
                    if (original == null) original = mc.options.fov().get();
                    mc.options.fov().set(fov.get());
                } else restore();
            }
            private void restore() {
                if (original == null) return;
                Minecraft.getInstance().options.fov().set(original);
                original = null;
            }
            @Override protected void onDisable() { restore(); }
            @Override public String compatibility() { return "Limited to the game's minimum FOV of 30."; }
        });
    }

    /** Sensible first-run positions so enabled HUD modules do not stack on one spot. */
    public static void applyDefaultLayout(HudLayout layout) {
        int y = 4;
        for (String id : new String[] { "fps", "cps", "ping", "coords", "direction", "clock", "memory", "frametime" }) {
            HudElement e = layout.of(id);
            e.anchor = HudElement.Anchor.TOP_LEFT; e.offsetX = 4; e.offsetY = y;
            y += 14;
        }
        place(layout, "keystrokes", HudElement.Anchor.BOTTOM_LEFT, 6, -6);
        place(layout, "armor", HudElement.Anchor.MIDDLE_RIGHT, -6, 0);
        place(layout, "potion", HudElement.Anchor.TOP_RIGHT, -4, 4);
        place(layout, "target", HudElement.Anchor.TOP_CENTER, 0, 30);
    }

    private static void place(HudLayout l, String id, HudElement.Anchor a, int x, int y) {
        HudElement e = l.of(id); e.anchor = a; e.offsetX = x; e.offsetY = y;
    }
}
