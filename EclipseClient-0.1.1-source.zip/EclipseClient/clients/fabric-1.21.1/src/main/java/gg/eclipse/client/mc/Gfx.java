package gg.eclipse.client.mc;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** Drawing helpers. Everything is procedural (fills only): no textures, so there is no atlas to mis-crop. */
public final class Gfx {
    private Gfx() {}

    public static final int OBSIDIAN = 0xFF08090D, BG = 0xFF0B0C11, SURFACE = 0xFF11131A, ELEVATED = 0xFF191B24;
    public static final int BURNT = 0xFFE87532, INFERNO = 0xFFFF9B42, VERMILION = 0xFFE04A32, TITANIUM = 0xFFB9B6AD;
    public static final int TEXT = 0xFFF2F0EA, TEXT2 = 0xFF92929E, SUCCESS = 0xFF35C78A, ERROR = 0xFFE24D55;

    public static int alpha(int argb, float a) {
        int na = Math.max(0, Math.min(255, Math.round(((argb >>> 24) & 0xFF) * a)));
        return (na << 24) | (argb & 0xFFFFFF);
    }

    private static int halfWidth(int r, int dy) { return (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy)); }

    public static void disc(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int hw = halfWidth(r, dy);
            g.fill(cx - hw, cy + dy, cx + hw, cy + dy + 1, color);
        }
    }

    /** Annulus between rInner and rOuter, drawn as scanline spans. */
    public static void ring(GuiGraphics g, int cx, int cy, int rOuter, int rInner, int color) {
        for (int dy = -rOuter; dy <= rOuter; dy++) {
            int ho = halfWidth(rOuter, dy);
            if (Math.abs(dy) >= rInner) {
                g.fill(cx - ho, cy + dy, cx + ho, cy + dy + 1, color);
            } else {
                int hi = halfWidth(rInner, dy);
                g.fill(cx - ho, cy + dy, cx - hi, cy + dy + 1, color);
                g.fill(cx + hi, cy + dy, cx + ho, cy + dy + 1, color);
            }
        }
    }

    /** The Eclipse mark: fading corona, black disc, bright rim, and a diamond-ring flare on the upper-left rim. */
    public static void eclipse(GuiGraphics g, int cx, int cy, int r, float a) {
        int rings = Math.max(6, Math.min(14, r / 5));
        int step = Math.max(1, r / 22);
        for (int i = rings - 1; i >= 0; i--) {
            float t = 1f - i / (float) rings;
            int inner = r + i * step;
            ring(g, cx, cy, inner + step, inner, alpha(0xFFFF9B42, a * 0.42f * t * t));
        }
        disc(g, cx, cy, r, alpha(OBSIDIAN, a));
        ring(g, cx, cy, r + 1, r - 1, alpha(INFERNO, a * 0.95f));
        double ang = Math.toRadians(215);
        int fx = cx + (int) Math.round(Math.cos(ang) * r), fy = cy + (int) Math.round(Math.sin(ang) * r);
        int len = Math.max(8, r * 7 / 10);
        g.fill(fx - len, fy, fx + len, fy + 1, alpha(0xFFFFD29A, a * 0.55f));
        g.fill(fx - 1, fy - 1, fx + 2, fy + 2, alpha(0xFFFFF3E0, a));
    }

    /** Deterministic starfield; twinkles with time but allocates nothing. */
    public static void stars(GuiGraphics g, int w, int h, long timeMs, float a, int count) {
        long seed = 7;
        for (int i = 0; i < count; i++) {
            seed = (seed * 16807L) % 2147483647L;
            int x = (int) (seed % Math.max(1, w));
            seed = (seed * 16807L) % 2147483647L;
            int y = (int) (seed % Math.max(1, h));
            float tw = 0.35f + 0.35f * (float) Math.sin(timeMs / 1400.0 + i);
            g.fill(x, y, x + 1, y + 1, alpha(TEXT, a * tw));
        }
    }

    /** Shortens text to fit, ending in ".." when cut. */
    public static String fit(Font font, String s, int maxW) {
        if (font.width(s) <= maxW) return s;
        String cut = s;
        while (cut.length() > 1 && font.width(cut + "..") > maxW) cut = cut.substring(0, cut.length() - 1);
        return cut + "..";
    }

    public static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
}
