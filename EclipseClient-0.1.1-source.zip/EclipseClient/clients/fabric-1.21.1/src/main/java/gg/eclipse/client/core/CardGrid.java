package gg.eclipse.client.core;

/** Responsive card grid. Guarantees cards fit the viewport width exactly: no cropping, no overflow. */
public final class CardGrid {
    public final int columns, cardW, cardH, gap, rows, contentH;

    public CardGrid(int viewportW, int minCardW, int cardH, int gap, int count) {
        int w = Math.max(1, viewportW);
        this.gap = gap;
        this.cardH = cardH;
        this.columns = Math.max(1, (w + gap) / (Math.max(1, minCardW) + gap));
        this.cardW = Math.max(1, (w - gap * (columns - 1)) / columns);
        this.rows = count == 0 ? 0 : (count + columns - 1) / columns;
        this.contentH = rows == 0 ? 0 : rows * cardH + (rows - 1) * gap;
    }

    /** Card rectangle {x, y, w, h} in content coordinates. */
    public int[] rect(int index) {
        int col = index % columns, row = index / columns;
        return new int[] { col * (cardW + gap), row * (cardH + gap), cardW, cardH };
    }

    /** Index range [first, last] of cards at least partly inside the viewport, to skip off-screen work. */
    public int[] visible(int scrollOffset, int viewportH, int count) {
        if (count == 0) return new int[] { 0, -1 };
        int first = Math.max(0, scrollOffset / (cardH + gap)) * columns;
        int last = Math.min(count - 1, ((scrollOffset + viewportH) / (cardH + gap) + 1) * columns - 1);
        return new int[] { Math.min(first, count - 1), last };
    }
}
