package gg.eclipse.client.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * A client feature. Subclasses add behaviour through {@link #onEnable()}, {@link #onDisable()} and {@link #onTick()};
 * the registry only ticks enabled modules, so a disabled module costs nothing per frame.
 */
public abstract class Module {
    public final String id;
    public final String name;
    public final String description;
    public final Category category;
    private boolean enabled;
    private boolean favorite;
    private int keybind = -1; // GLFW key code, -1 = unbound
    private final List<Setting<?>> settings = new ArrayList<>();

    protected Module(String id, String name, Category category, String description) {
        this.id = id; this.name = name; this.category = category; this.description = description;
    }

    protected <S extends Setting<?>> S add(S s) { settings.add(s); return s; }
    public List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }

    public boolean enabled() { return enabled; }
    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable(); else onDisable();
    }
    public void toggle() { setEnabled(!enabled); }

    public boolean favorite() { return favorite; }
    public void setFavorite(boolean f) { favorite = f; }
    public void toggleFavoriteMark() { favorite = !favorite; }
    public int keybind() { return keybind; }
    public void setKeybind(int code) { keybind = code; }

    /** Compatibility note shown in the details panel, e.g. "Client only" or "Needs a server connection". */
    public String compatibility() { return "Works in singleplayer and multiplayer."; }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick() {}
    public void resetSettings() { settings.forEach(Setting::reset); }
}
