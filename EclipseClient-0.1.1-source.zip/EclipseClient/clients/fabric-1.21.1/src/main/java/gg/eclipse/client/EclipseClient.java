package gg.eclipse.client;

import com.mojang.blaze3d.platform.InputConstants;
import gg.eclipse.client.core.HudLayout;
import gg.eclipse.client.core.Module;
import gg.eclipse.client.core.ModuleRegistry;
import gg.eclipse.client.core.ProfileManager;
import gg.eclipse.client.mc.HudRenderer;
import gg.eclipse.client.mc.Modules;
import gg.eclipse.client.screen.EclipseTitleScreen;
import gg.eclipse.client.screen.ModuleWorkspaceScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.TitleScreen;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public final class EclipseClient implements ClientModInitializer {
    public static final String VERSION = "0.1.0";
    public static final Logger LOG = LoggerFactory.getLogger("eclipse");
    public static final ModuleRegistry MODULES = new ModuleRegistry();
    public static final HudLayout LAYOUT = new HudLayout();
    public static ProfileManager PROFILES;
    public static KeyMapping WORKSPACE_KEY, ZOOM_KEY;
    private static final Map<String, Boolean> KEY_DOWN = new HashMap<>();

    @Override
    public void onInitializeClient() {
        try {
            PROFILES = new ProfileManager(FabricLoader.getInstance().getConfigDir().resolve("eclipse"));
            Modules.registerAll(MODULES);
            Modules.applyDefaultLayout(LAYOUT);
            loadCurrent();
        } catch (Exception e) {
            // A broken config must never stop the game from starting: run with defaults and say why.
            LOG.error("Eclipse could not load its configuration; continuing with defaults.", e);
            if (MODULES.all().isEmpty()) Modules.registerAll(MODULES);
        }
        WORKSPACE_KEY = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.eclipse.workspace", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.eclipse"));
        ZOOM_KEY = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.eclipse.zoom", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.eclipse"));
        HudRenderCallback.EVENT.register((graphics, delta) -> HudRenderer.render(graphics));
        ClientTickEvents.END_CLIENT_TICK.register(EclipseClient::tick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> save());
    }

    private static void loadCurrent() throws IOException {
        String name = PROFILES.current();
        if (PROFILES.list().contains(name)) PROFILES.select(name, MODULES, LAYOUT);
        else PROFILES.save(name, MODULES, LAYOUT); // first run: write the default profile
    }

    public static void save() {
        if (PROFILES == null) return;
        try { PROFILES.save(PROFILES.current(), MODULES, LAYOUT); }
        catch (Exception e) { LOG.error("Could not save the Eclipse profile.", e); }
    }

    public static void restoreDefaults() {
        ProfileManager.restoreDefaults(MODULES, LAYOUT);
        Modules.applyDefaultLayout(LAYOUT);
    }

    private static void tick(Minecraft mc) {
        // Safety net: the Minecraft mixin swaps the title screen at the source; this catches screens built internally.
        if (mc.screen != null && mc.screen.getClass() == TitleScreen.class) mc.setScreen(new EclipseTitleScreen());

        while (WORKSPACE_KEY.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new ModuleWorkspaceScreen(null));
        }
        MODULES.tick();

        if (mc.screen == null) {
            long window = mc.getWindow().getWindow();
            for (Module m : MODULES.all()) {
                if (m.keybind() < 0) continue;
                boolean down = InputConstants.isKeyDown(window, m.keybind());
                boolean was = KEY_DOWN.getOrDefault(m.id, false);
                if (down && !was) m.toggle();
                KEY_DOWN.put(m.id, down);
            }
        }
    }
}
