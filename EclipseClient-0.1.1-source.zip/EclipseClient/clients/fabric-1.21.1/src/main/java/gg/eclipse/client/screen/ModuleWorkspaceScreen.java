package gg.eclipse.client.screen;

import gg.eclipse.client.EclipseClient;
import gg.eclipse.client.core.*;
import gg.eclipse.client.core.Module;
import gg.eclipse.client.mc.Gfx;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

/**
 * Right Shift workspace: top bar, category rail, module library, details panel, bottom bar. Every region comes from
 * {@link WorkspaceLayout}; the library scrolls through {@link ScrollModel} and cards come from {@link CardGrid},
 * so cards cannot be cropped and the wheel cannot strand content. All of that logic is unit-tested.
 */
public final class ModuleWorkspaceScreen extends Screen {
    private interface Drag { void to(double mx, double my); }
    private record Hit(int x, int y, int w, int h, int[] clip, Runnable click, Drag drag) {
        boolean contains(double mx, double my) {
            if (!Gfx.in(mx, my, x, y, w, h)) return false;
            return clip == null || Gfx.in(mx, my, clip[0], clip[1], clip[2], clip[3]);
        }
    }

    private static final String[] NAV = { "All Modules", "HUD", "Visual", "Mechanics", "Server", "Utility", "Performance", "Favorites" };
    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private final ScrollModel libScroll = new ScrollModel(), detScroll = new ScrollModel();
    private WorkspaceLayout lay;
    private int nav = 0, lastDetailsH = 0;
    private String query = "";
    private boolean searchFocus;
    private Module selected, capturing;
    private Hit dragging;
    private int[] searchRect = new int[4], libView = new int[4];

    public ModuleWorkspaceScreen(Screen parent) {
        super(Component.literal("Eclipse Modules"));
        this.parent = parent;
    }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float pt) { }
    @Override public void onClose() { EclipseClient.save(); minecraft.setScreen(parent); }

    private Category navCategory() { return nav >= 1 && nav <= 6 ? Category.values()[nav - 1] : null; }
    private List<Module> filtered() { return EclipseClient.MODULES.search(query, navCategory(), nav == 7); }

    private void add(int x, int y, int w, int h, int[] clip, Runnable click) { hits.add(new Hit(x, y, w, h, clip, click, null)); }

    private void label(GuiGraphics g, String s, int x, int y, int color) { g.drawString(font, s, x, y, color, false); }

    private void button(GuiGraphics g, String text, int rightEdge, int y, int mx, int my, Runnable click) {
        int w = font.width(text) + 10, x = rightEdge - w;
        boolean hot = Gfx.in(mx, my, x, y, w, 12);
        g.fill(x, y, x + w, y + 12, hot ? Gfx.BURNT : Gfx.ELEVATED);
        label(g, text, x + 5, y + 2, hot ? Gfx.OBSIDIAN : Gfx.TEXT);
        add(x, y, w, 12, null, click);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        hits.clear();
        lay = new WorkspaceLayout(width, height);
        g.fill(0, 0, width, height, Gfx.BG);
        top(g, mx, my);
        navRail(g, mx, my);
        library(g, mx, my);
        if (lay.showDetails) details(g, mx, my);
        bottom(g, mx, my);
    }

    private void top(GuiGraphics g, int mx, int my) {
        g.fill(0, 0, width, lay.topH, Gfx.SURFACE);
        g.fill(0, lay.topH - 1, width, lay.topH, Gfx.ELEVATED);
        label(g, "ECLIPSE", 8, 6, Gfx.INFERNO);
        int sw = Math.min(160, Math.max(60, lay.libW - 12)), sx = lay.libX + 6;
        searchRect = new int[] { sx, 3, sw, 14 };
        g.fill(sx, 3, sx + sw, 17, Gfx.ELEVATED);
        if (searchFocus) { g.fill(sx, 16, sx + sw, 17, Gfx.BURNT); }
        String shown = query.isEmpty() && !searchFocus ? "Search modules" : Gfx.fit(font, query + (searchFocus ? "_" : ""), sw - 8);
        label(g, shown, sx + 4, 6, query.isEmpty() && !searchFocus ? Gfx.TEXT2 : Gfx.TEXT);
        add(sx, 3, sw, 14, null, () -> searchFocus = true);
    }

    private void navRail(GuiGraphics g, int mx, int my) {
        g.fill(lay.navX, lay.bodyY, lay.navX + lay.navW, lay.bodyY + lay.bodyH, Gfx.SURFACE);
        for (int i = 0; i < NAV.length; i++) {
            int y = lay.bodyY + 6 + i * 16;
            if (y + 14 > lay.bodyY + lay.bodyH) break;
            boolean sel = i == nav, hot = Gfx.in(mx, my, lay.navX, y, lay.navW, 14);
            if (sel || hot) g.fill(lay.navX, y, lay.navX + lay.navW, y + 14, sel ? Gfx.ELEVATED : Gfx.alpha(Gfx.ELEVATED, 0.5f));
            if (sel) g.fill(lay.navX, y, lay.navX + 2, y + 14, Gfx.BURNT);
            label(g, Gfx.fit(font, NAV[i], lay.navW - 14), lay.navX + 8, y + 3, sel ? Gfx.TEXT : Gfx.TEXT2);
            final int idx = i;
            add(lay.navX, y, lay.navW, 14, null, () -> { nav = idx; libScroll.scrollTo(0); });
        }
    }

    private void library(GuiGraphics g, int mx, int my) {
        int vx = lay.libX + 6, vy = lay.bodyY + 6, vw = lay.libW - 12 - 6, vh = lay.bodyH - 12;
        libView = new int[] { vx, vy, vw, vh };
        List<Module> list = filtered();
        CardGrid grid = new CardGrid(vw, 112, 42, 6, list.size());
        libScroll.layout(vh, grid.contentH);

        if (list.isEmpty()) {
            String msg = nav == 7 ? "No favorites yet. Click the * on a module." : navCategory() != null && navCategory() != Category.HUD && navCategory() != Category.MECHANICS
                ? "No modules in this category in this build." : "No modules match your search.";
            label(g, Gfx.fit(font, msg, vw), vx, vy + 4, Gfx.TEXT2);
            return;
        }
        g.enableScissor(vx, vy, vx + vw, vy + vh);
        int[] range = grid.visible(libScroll.offset(), vh, list.size());
        for (int i = range[0]; i <= range[1]; i++) {
            Module m = list.get(i);
            int[] r = grid.rect(i);
            int x = vx + r[0], y = vy + r[1] - libScroll.offset(), w = r[2], h = r[3];
            boolean sel = m == selected, hot = Gfx.in(mx, my, x, y, w, h) && Gfx.in(mx, my, vx, vy, vw, vh);
            g.fill(x, y, x + w, y + h, sel ? Gfx.ELEVATED : hot ? Gfx.alpha(Gfx.ELEVATED, 0.7f) : Gfx.SURFACE);
            if (sel) g.fill(x, y, x + w, y + 1, Gfx.BURNT);
            // monogram tile instead of a texture: no atlas, so nothing can be cropped
            g.fill(x + 5, y + 5, x + 25, y + 25, m.enabled() ? Gfx.BURNT : Gfx.ELEVATED);
            String mono = m.name.substring(0, 1);
            label(g, mono, x + 15 - font.width(mono) / 2, y + 11, m.enabled() ? Gfx.OBSIDIAN : Gfx.TEXT2);
            label(g, Gfx.fit(font, m.name, w - 52), x + 30, y + 6, Gfx.TEXT);
            label(g, Gfx.fit(font, m.category.title, w - 52), x + 30, y + 17, Gfx.TEXT2);
            label(g, Gfx.fit(font, m.description, w - 12), x + 6, y + h - 11, Gfx.alpha(Gfx.TEXT2, 0.9f));
            label(g, "*", x + w - 10, y + 5, m.favorite() ? Gfx.INFERNO : Gfx.alpha(Gfx.TEXT2, 0.5f));
            toggle(g, x + w - 32, y + 16, m.enabled());
            int[] clip = { vx, vy, vw, vh };
            add(x + w - 14, y + 2, 12, 12, clip, m::toggleFavoriteMark);
            add(x + w - 34, y + 15, 26, 12, clip, m::toggle);
            add(x, y, w, h, clip, () -> selected = m);
        }
        g.disableScissor();
        if (libScroll.scrollable()) {
            int tx = vx + vw + 2;
            g.fill(tx, vy, tx + 3, vy + vh, Gfx.SURFACE);
            int[] t = libScroll.thumb(vh);
            g.fill(tx, vy + t[0], tx + 3, vy + t[0] + t[1], Gfx.alpha(Gfx.TITANIUM, 0.5f));
            hits.add(new Hit(tx - 2, vy, 8, vh, null, () -> { }, (dx, dy) -> libScroll.dragThumb((int) (dy - vy), vh)));
        }
    }

    private void toggle(GuiGraphics g, int x, int y, boolean on) {
        g.fill(x, y, x + 22, y + 10, on ? Gfx.alpha(Gfx.BURNT, 0.45f) : Gfx.ELEVATED);
        g.fill(on ? x + 12 : x + 1, y + 1, on ? x + 21 : x + 10, y + 9, on ? Gfx.INFERNO : Gfx.TITANIUM);
    }

    private void details(GuiGraphics g, int mx, int my) {
        int x = lay.detX, y0 = lay.bodyY, w = lay.detW, h = lay.bodyH;
        g.fill(x, y0, x + w, y0 + h, Gfx.SURFACE);
        g.fill(x, y0, x + 1, y0 + h, Gfx.ELEVATED);
        if (selected == null) { label(g, "Select a module", x + 8, y0 + 8, Gfx.TEXT2); return; }
        detScroll.layout(h - 8, lastDetailsH);
        int[] clip = { x, y0, w, h };
        g.enableScissor(x + 1, y0, x + w, y0 + h);
        int ix = x + 8, iw = w - 16, y = y0 + 8 - detScroll.offset(), top = y;
        Module m = selected;
        label(g, Gfx.fit(font, m.name, iw), ix, y, Gfx.INFERNO); y += 14;
        for (String line : wrap(m.description, iw)) { label(g, line, ix, y, Gfx.TEXT2); y += 10; }
        y += 2;
        for (String line : wrap(m.compatibility(), iw)) { label(g, line, ix, y, Gfx.alpha(Gfx.TITANIUM, 0.8f)); y += 10; }
        y += 6;
        row(g, "Enabled", ix, y, iw); toggle(g, ix + iw - 22, y, m.enabled()); add(ix, y - 2, iw, 14, clip, m::toggle); y += 16;
        row(g, "Favorite", ix, y, iw); toggle(g, ix + iw - 22, y, m.favorite()); add(ix, y - 2, iw, 14, clip, m::toggleFavoriteMark); y += 16;
        String key = capturing == m ? "Press a key" : m.keybind() < 0 ? "None" : keyName(m.keybind());
        row(g, "Keybind", ix, y, iw);
        label(g, key, ix + iw - font.width(key), y, capturing == m ? Gfx.INFERNO : Gfx.TEXT);
        add(ix, y - 2, iw, 14, clip, () -> capturing = m); y += 18;

        for (Setting<?> s : m.settings()) {
            row(g, s.label, ix, y, iw);
            if (s instanceof Setting.Bool b) {
                toggle(g, ix + iw - 22, y, b.get()); add(ix, y - 2, iw, 14, clip, b::toggle); y += 16;
            } else if (s instanceof Setting.Choice c) {
                String v = c.get(); label(g, v, ix + iw - font.width(v), y, Gfx.INFERNO); add(ix, y - 2, iw, 14, clip, c::cycle); y += 16;
            } else if (s instanceof Setting.IntRange r) {
                String v = Integer.toString(r.get()); label(g, v, ix + iw - font.width(v), y, Gfx.INFERNO); y += 12;
                int sy = y, sx = ix;
                g.fill(sx, sy + 2, sx + iw, sy + 4, Gfx.ELEVATED);
                g.fill(sx, sy + 2, sx + (int) Math.round(iw * r.fraction()), sy + 4, Gfx.BURNT);
                g.fill(sx + (int) Math.round(iw * r.fraction()) - 1, sy, sx + (int) Math.round(iw * r.fraction()) + 2, sy + 6, Gfx.INFERNO);
                final int fsx = sx, fiw = iw;
                hits.add(new Hit(sx, sy - 2, iw, 10, clip, () -> { }, (dx, dy) -> r.setFromFraction((dx - fsx) / (double) fiw)));
                y += 12;
            }
        }
        y += 4;
        button(g, "Reset settings", ix + iw, y, mx, my, m::resetSettings);
        y += 18;
        g.disableScissor();
        lastDetailsH = y - top + 8;
    }

    private void row(GuiGraphics g, String text, int x, int y, int w) { label(g, Gfx.fit(font, text, w - 40), x, y, Gfx.TEXT); }

    private void bottom(GuiGraphics g, int mx, int my) {
        int y = height - lay.bottomH;
        g.fill(0, y, width, height, Gfx.SURFACE);
        g.fill(0, y, width, y + 1, Gfx.ELEVATED);
        long on = EclipseClient.MODULES.all().stream().filter(Module::enabled).count();
        String left = on + " of " + EclipseClient.MODULES.all().size() + " enabled";
        label(g, left, 8, y + 3, Gfx.TEXT2);
        int right = width - 6;
        String profile = EclipseClient.PROFILES == null ? "Default" : EclipseClient.PROFILES.current();
        button(g, "Reset", right, y + 1, mx, my, () -> { EclipseClient.restoreDefaults(); selected = null; });
        right -= font.width("Reset") + 14;
        button(g, "Edit HUD", right, y + 1, mx, my, () -> minecraft.setScreen(new HudEditorScreen(this)));
        right -= font.width("Edit HUD") + 14;
        button(g, "New", right, y + 1, mx, my, this::newProfile);
        right -= font.width("New") + 14;
        String pl = "Profile: " + Gfx.fit(font, profile, 90);
        int pw = font.width(pl) + 8;
        if (right - pw > font.width(left) + 20) {
            boolean hot = Gfx.in(mx, my, right - pw, y + 1, pw, 12);
            label(g, pl, right - pw + 4, y + 3, hot ? Gfx.INFERNO : Gfx.TEXT);
            add(right - pw, y + 1, pw, 12, null, this::nextProfile);
        }
    }

    private void nextProfile() {
        try {
            List<String> names = EclipseClient.PROFILES.list();
            if (names.isEmpty()) return;
            EclipseClient.save();
            EclipseClient.PROFILES.select(names.get((Math.max(0, names.indexOf(EclipseClient.PROFILES.current())) + 1) % names.size()), EclipseClient.MODULES, EclipseClient.LAYOUT);
        } catch (Exception e) { EclipseClient.LOG.error("Could not switch profile", e); }
    }

    private void newProfile() {
        try {
            List<String> names = EclipseClient.PROFILES.list();
            int n = 1;
            while (names.contains("Profile " + n)) n++;
            EclipseClient.save();
            EclipseClient.PROFILES.save("Profile " + n, EclipseClient.MODULES, EclipseClient.LAYOUT);
            EclipseClient.PROFILES.select("Profile " + n, EclipseClient.MODULES, EclipseClient.LAYOUT);
        } catch (Exception e) { EclipseClient.LOG.error("Could not create profile", e); }
    }

    private List<String> wrap(String text, int maxW) {
        List<String> out = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String trial = line.isEmpty() ? word : line + " " + word;
            if (font.width(trial) > maxW && !line.isEmpty()) { out.add(line.toString()); line = new StringBuilder(word); }
            else line = new StringBuilder(trial);
        }
        if (!line.isEmpty()) out.add(line.toString());
        return out;
    }

    private static String keyName(int code) {
        String n = com.mojang.blaze3d.platform.InputConstants.Type.KEYSYM.getOrCreate(code).getDisplayName().getString();
        return n;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        searchFocus = false;
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (h.contains(mx, my)) {
                h.click().run();
                if (h.drag() != null) { dragging = h; h.drag().to(mx, my); }
                return true;
            }
        }
        capturing = null;
        return false;
    }

    @Override public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) { dragging.drag().to(mx, my); return true; }
        return false;
    }

    @Override public boolean mouseReleased(double mx, double my, int button) { dragging = null; return false; }

    @Override
    public boolean mouseScrolled(double mx, double my, double sx, double sy) {
        if (lay != null && lay.showDetails && Gfx.in(mx, my, lay.detX, lay.bodyY, lay.detW, lay.bodyH)) { detScroll.wheel(sy); return true; }
        if (Gfx.in(mx, my, lay.libX, lay.bodyY, lay.libW, lay.bodyH)) { libScroll.wheel(sy); return true; }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (capturing != null) {
            if (key == GLFW.GLFW_KEY_ESCAPE) { /* cancel */ }
            else if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) capturing.setKeybind(-1);
            else if (key != GLFW.GLFW_KEY_RIGHT_SHIFT) capturing.setKeybind(key); // Right Shift stays reserved for this screen
            capturing = null;
            return true;
        }
        if (searchFocus) {
            if (key == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) { query = query.substring(0, query.length() - 1); libScroll.scrollTo(0); return true; }
            if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_ENTER) { searchFocus = false; return true; }
            return true; // typing: do not let shift (used for capitals) close the screen
        }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT || key == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (searchFocus && c >= 32 && c != 127 && query.length() < 24) { query += c; libScroll.scrollTo(0); return true; }
        return false;
    }
}
