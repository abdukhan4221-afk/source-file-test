package gg.eclipse.client.screen;

import gg.eclipse.client.EclipseClient;
import gg.eclipse.client.core.HudElement;
import gg.eclipse.client.core.Module;
import gg.eclipse.client.mc.Gfx;
import gg.eclipse.client.mc.HudModule;
import gg.eclipse.client.mc.HudRenderer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Drag HUD elements, snap to a grid, scale and fade them, with a live preview. Positions stay on screen by construction. */
public final class HudEditorScreen extends Screen {
    private final Screen parent;
    private HudModule selected;
    private int grabX, grabY;
    private boolean snap = true;

    public HudEditorScreen(Screen parent) { super(Component.literal("HUD Editor")); this.parent = parent; }

    @Override public boolean isPauseScreen() { return false; }
    @Override public void renderBackground(GuiGraphics g, int mx, int my, float pt) { }
    @Override public void onClose() { EclipseClient.save(); minecraft.setScreen(parent); }

    private int grid() { return snap ? EclipseClient.LAYOUT.gridSize : 1; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, Gfx.alpha(Gfx.OBSIDIAN, 0.55f));
        if (snap) {
            int s = EclipseClient.LAYOUT.gridSize * 4;
            for (int x = 0; x < width; x += s) for (int y = 0; y < height; y += s) g.fill(x, y, x + 1, y + 1, Gfx.alpha(Gfx.TEXT, 0.12f));
        }
        HudRenderer.drawAll(g, minecraft, true);
        for (Module m : EclipseClient.MODULES.all()) {
            if (!(m instanceof HudModule h) || !m.enabled()) continue;
            int[] r = HudRenderer.rectOf(minecraft, h);
            int c = h == selected ? Gfx.INFERNO : Gfx.alpha(Gfx.TITANIUM, 0.5f);
            g.fill(r[0] - 1, r[1] - 1, r[0] + r[2] + 1, r[1], c);
            g.fill(r[0] - 1, r[1] + r[3], r[0] + r[2] + 1, r[1] + r[3] + 1, c);
            g.fill(r[0] - 1, r[1], r[0], r[1] + r[3], c);
            g.fill(r[0] + r[2], r[1], r[0] + r[2] + 1, r[1] + r[3], c);
        }
        String help = selected == null ? "Drag an element to move it. Click one to select it." :
            EclipseClient.LAYOUT.of(selected.id).scalePercent + "% size, " + EclipseClient.LAYOUT.of(selected.id).opacityPercent + "% opacity.  [ ] size   - = opacity   V hide/show   R reset";
        int bw = Math.min(width - 8, font.width(help) + 12);
        g.fill(width / 2 - bw / 2, height - 26, width / 2 + bw / 2, height - 12, Gfx.alpha(Gfx.SURFACE, 0.92f));
        g.drawString(font, Gfx.fit(font, help, bw - 8), width / 2 - bw / 2 + 6, height - 23, Gfx.TEXT, false);
        String foot = "G grid snap: " + (snap ? "on" : "off") + "    Esc done";
        g.drawString(font, foot, width / 2 - font.width(foot) / 2, height - 10, Gfx.TEXT2, false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        selected = null;
        for (Module m : EclipseClient.MODULES.all()) {
            if (!(m instanceof HudModule h) || !m.enabled()) continue;
            int[] r = HudRenderer.rectOf(minecraft, h);
            if (Gfx.in(mx, my, r[0], r[1], r[2], r[3])) { selected = h; grabX = (int) mx - r[0]; grabY = (int) my - r[1]; }
        }
        return selected != null;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (selected == null) return false;
        int w = selected.width(font), h = selected.height(font);
        EclipseClient.LAYOUT.of(selected.id).moveTo((int) mx - grabX, (int) my - grabY, width, height, w, h, grid());
        return true;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_RIGHT_SHIFT) { onClose(); return true; }
        if (key == GLFW.GLFW_KEY_G) { snap = !snap; return true; }
        if (selected == null) return false;
        HudElement e = EclipseClient.LAYOUT.of(selected.id);
        switch (key) {
            case GLFW.GLFW_KEY_RIGHT_BRACKET -> e.setScale(e.scalePercent + 10);
            case GLFW.GLFW_KEY_LEFT_BRACKET -> e.setScale(e.scalePercent - 10);
            case GLFW.GLFW_KEY_EQUAL -> e.setOpacity(e.opacityPercent + 10);
            case GLFW.GLFW_KEY_MINUS -> e.setOpacity(e.opacityPercent - 10);
            case GLFW.GLFW_KEY_V -> e.visible = !e.visible;
            case GLFW.GLFW_KEY_R -> e.reset();
            default -> { return false; }
        }
        return true;
    }
}
