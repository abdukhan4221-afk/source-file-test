package gg.eclipse.client.core;

/** Rolling frame-time statistics over the last N frames (fixed-size ring, no per-frame allocation). */
public final class FrameStats {
    private final long[] nanos;
    private int count, next;
    private long last = -1;

    public FrameStats(int window) { this.nanos = new long[Math.max(2, window)]; }

    /** Record the timestamp of a rendered frame. */
    public void frame(long nowNanos) {
        if (last >= 0) {
            nanos[next] = nowNanos - last;
            next = (next + 1) % nanos.length;
            count = Math.min(count + 1, nanos.length);
        }
        last = nowNanos;
    }

    public int fps() {
        double avg = avgMs();
        return avg <= 0 ? 0 : (int) Math.round(1000.0 / avg);
    }

    public double avgMs() {
        if (count == 0) return 0;
        long sum = 0;
        for (int i = 0; i < count; i++) sum += nanos[i];
        return sum / (double) count / 1_000_000.0;
    }

    public double minMs() { return extreme(false); }
    public double maxMs() { return extreme(true); }

    private double extreme(boolean max) {
        if (count == 0) return 0;
        long v = nanos[0];
        for (int i = 1; i < count; i++) v = max ? Math.max(v, nanos[i]) : Math.min(v, nanos[i]);
        return v / 1_000_000.0;
    }
}
