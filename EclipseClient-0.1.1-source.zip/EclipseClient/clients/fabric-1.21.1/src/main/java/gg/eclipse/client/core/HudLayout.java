package gg.eclipse.client.core;

import java.util.LinkedHashMap;
import java.util.Map;

/** All HUD elements by module id. Created lazily so a module gets sensible defaults the first time it is shown. */
public final class HudLayout {
    private final Map<String, HudElement> elements = new LinkedHashMap<>();
    /** Grid used by the editor when snapping (px in GUI-scaled units). */
    public int gridSize = 4;

    public HudElement of(String moduleId) { return elements.computeIfAbsent(moduleId, HudElement::new); }
    public Map<String, HudElement> all() { return elements; }
    public void resetAll() { elements.values().forEach(HudElement::reset); }
}
