package gg.eclipse.client.mc;

import gg.eclipse.client.core.Category;
import gg.eclipse.client.core.Module;
import gg.eclipse.client.core.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

/** A module that draws on the HUD. The layout (position, scale, opacity) is owned by {@code HudLayout}, not the module. */
public abstract class HudModule extends Module {
    protected HudModule(String id, String name, String description) { super(id, name, Category.HUD, description); }

    public abstract int width(Font font);
    public abstract int height(Font font);
    /** Draw at (x, y) in already-scaled space. {@code alpha} is the element's opacity 0..1. */
    public abstract void draw(GuiGraphics g, Font font, int x, int y, float alpha);

    /** One line of text on a dark chip. The string is rebuilt on tick, never per frame, so drawing allocates nothing. */
    public abstract static class TextHud extends HudModule {
        protected final Setting.Bool background = add(new Setting.Bool("background", "Background", true));
        protected String text = "";

        protected TextHud(String id, String name, String description) { super(id, name, description); }
        protected abstract String compute(Minecraft mc);

        @Override public void onTick() {
            Minecraft mc = Minecraft.getInstance();
            text = compute(mc);
        }
        @Override protected void onEnable() { onTick(); }
        @Override public int width(Font font) { return font.width(text) + 8; }
        @Override public int height(Font font) { return 12; }
        @Override public void draw(GuiGraphics g, Font font, int x, int y, float a) {
            if (background.get()) g.fill(x, y, x + width(font), y + 12, Gfx.alpha(Gfx.SURFACE, 0.78f * a));
            g.fill(x, y, x + 1, y + 12, Gfx.alpha(Gfx.BURNT, a));
            g.drawString(font, text, x + 5, y + 2, Gfx.alpha(Gfx.TEXT, a), false);
        }
    }
}
