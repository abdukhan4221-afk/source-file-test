package gg.eclipse.client.core;

public enum Category {
    HUD("HUD"), VISUAL("Visual"), MECHANICS("Mechanics"), SERVER("Server"), UTILITY("Utility"), PERFORMANCE("Performance");
    public final String title;
    Category(String title) { this.title = title; }
}
