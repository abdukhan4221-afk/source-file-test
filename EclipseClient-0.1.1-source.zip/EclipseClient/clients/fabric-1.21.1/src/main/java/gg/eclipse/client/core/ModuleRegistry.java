package gg.eclipse.client.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public final class ModuleRegistry {
    private final Map<String, Module> byId = new LinkedHashMap<>();

    public void register(Module m) {
        if (byId.putIfAbsent(m.id, m) != null) throw new IllegalArgumentException("Duplicate module id: " + m.id);
    }

    public List<Module> all() { return List.copyOf(byId.values()); }
    public Optional<Module> find(String id) { return Optional.ofNullable(byId.get(id)); }

    /** Filter for the workspace: category (null = all, favourites handled by {@code favoritesOnly}) and free-text query. */
    public List<Module> search(String query, Category category, boolean favoritesOnly) {
        String q = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<Module> out = new ArrayList<>();
        for (Module m : byId.values()) {
            if (category != null && m.category != category) continue;
            if (favoritesOnly && !m.favorite()) continue;
            if (!q.isEmpty() && !(m.name.toLowerCase(Locale.ROOT).contains(q) || m.description.toLowerCase(Locale.ROOT).contains(q))) continue;
            out.add(m);
        }
        return out;
    }

    /** Only enabled modules are ticked: a disabled module must cost nothing. */
    public void tick() {
        for (Module m : byId.values()) if (m.enabled()) m.onTick();
    }

    /** Fires a module whose keybind matches. Returns true if one was toggled. */
    public boolean handleKey(int keyCode) {
        if (keyCode < 0) return false;
        for (Module m : byId.values()) if (m.keybind() == keyCode) { m.toggle(); return true; }
        return false;
    }

    public void disableAll() { byId.values().forEach(m -> m.setEnabled(false)); }
}
