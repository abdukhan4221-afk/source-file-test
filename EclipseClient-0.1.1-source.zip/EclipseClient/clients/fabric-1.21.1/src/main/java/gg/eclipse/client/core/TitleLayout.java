package gg.eclipse.client.core;

/** Geometry for the Eclipse title screen in GUI-scaled pixels. Pure maths so it can be tested at every GUI scale. */
public final class TitleLayout {
    public static final int CARDS = 5; // Singleplayer, Multiplayer, Client Modules, Game Options, Quit Game
    public final int margin, wordmarkY, wordmarkScalePct, infoY;
    public final int cardX, cardW, cardH, cardGap, cardsTop;
    public final int eclipseX, eclipseY, eclipseR;

    public TitleLayout(int w, int h) {
        margin = Math.max(8, w / 16);
        cardH = clampI((h - 72) * 10 / 58, 15, 30);
        cardGap = Math.max(2, cardH / 8);
        cardW = clampI(w * 36 / 100, 110, 210);
        cardX = margin;
        int cardsBlock = CARDS * cardH + (CARDS - 1) * cardGap;
        cardsTop = h - cardsBlock - Math.max(10, h / 14);
        wordmarkScalePct = h >= 300 ? 300 : h >= 200 ? 220 : 160;
        wordmarkY = Math.max(8, h / 16);
        int wordmarkH = 9 * wordmarkScalePct / 100;
        infoY = wordmarkY + wordmarkH + 3;
        eclipseR = Math.max(24, Math.min(h * 36 / 100, w * 20 / 100));
        eclipseX = Math.min(w - eclipseR - eclipseR / 3, Math.max(cardX + cardW + eclipseR + 12, w * 66 / 100));
        eclipseY = h * 47 / 100;
    }

    public int[] card(int i) { return new int[] { cardX, cardsTop + i * (cardH + cardGap), cardW, cardH }; }

    private static int clampI(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
