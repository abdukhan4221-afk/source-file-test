package gg.eclipse.client.mc;

import gg.eclipse.client.EclipseClient;
import gg.eclipse.client.core.HudElement;
import gg.eclipse.client.core.Module;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

public final class HudRenderer {
    private HudRenderer() {}

    /** Called by Fabric's HUD callback every frame. Only enabled HUD modules do any work. */
    public static void render(GuiGraphics g) {
        Modules.FRAMES.frame(System.nanoTime());
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.screen != null) return;
        drawAll(g, mc, false);
    }

    /** {@code editing} also draws hidden elements so they can be found and re-enabled in the editor. */
    public static void drawAll(GuiGraphics g, Minecraft mc, boolean editing) {
        Font font = mc.font;
        int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
        for (Module m : EclipseClient.MODULES.all()) {
            if (!(m instanceof HudModule h) || !m.enabled()) continue;
            HudElement e = EclipseClient.LAYOUT.of(m.id);
            if (!e.visible && !editing) continue;
            int[] r = e.resolve(sw, sh, h.width(font), h.height(font));
            g.pose().pushPose();
            g.pose().translate((float) r[0], (float) r[1], 0f);
            float s = e.scalePercent / 100f;
            g.pose().scale(s, s, 1f);
            h.draw(g, font, 0, 0, e.opacityPercent / 100f);
            g.pose().popPose();
        }
    }

    /** Pixel rect {x, y, w, h} of a module's element, for hit-testing in the editor. */
    public static int[] rectOf(Minecraft mc, HudModule h) {
        return EclipseClient.LAYOUT.of(h.id).resolve(mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight(), h.width(mc.font), h.height(mc.font));
    }
}
