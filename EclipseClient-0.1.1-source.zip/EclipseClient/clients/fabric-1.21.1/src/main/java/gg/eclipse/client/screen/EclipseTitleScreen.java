package gg.eclipse.client.screen;

import gg.eclipse.client.EclipseClient;
import gg.eclipse.client.core.TitleLayout;
import gg.eclipse.client.mc.Gfx;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.OptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.multiplayer.JoinMultiplayerScreen;
import net.minecraft.client.gui.screens.worldselection.SelectWorldScreen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/**
 * Original title screen: fully custom composition, no vanilla widgets, panorama or blur. Each card calls the same
 * native screen vanilla's own button would open. Layout comes from the tested {@link TitleLayout}.
 */
public final class EclipseTitleScreen extends Screen {
    private static final String[][] ITEMS = {
        { "Singleplayer", "Worlds and saved games" }, { "Multiplayer", "Servers and friends" },
        { "Client Modules", "Right Shift anywhere" }, { "Game Options", "Video, controls, sound" }, { "Quit Game", "Close Minecraft" },
    };
    private TitleLayout lay;
    private int focus = -1;

    public EclipseTitleScreen() { super(Component.literal("Eclipse")); }

    @Override protected void init() { lay = new TitleLayout(width, height); }
    @Override public boolean shouldCloseOnEsc() { return false; }
    /** Vanilla would blur whatever is behind the screen; the custom background must stay sharp. */
    @Override public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) { }

    private boolean enabled(int i) { return true; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long now = Util.getMillis();
        g.fill(0, 0, width, height, Gfx.OBSIDIAN);
        Gfx.stars(g, width, height, now, 1f, 110);
        Gfx.eclipse(g, lay.eclipseX, lay.eclipseY, lay.eclipseR, 1f);

        g.pose().pushPose();
        g.pose().translate((float) lay.cardX, (float) lay.wordmarkY, 0f);
        float s = lay.wordmarkScalePct / 100f;
        g.pose().scale(s, s, 1f);
        g.drawString(font, "ECLIPSE", 0, 0, Gfx.TEXT, false);
        g.pose().popPose();
        g.drawString(font, "A NEW ERA OF ECLIPSE", lay.cardX, lay.infoY, Gfx.INFERNO, false);

        for (int i = 0; i < TitleLayout.CARDS; i++) {
            int[] c = lay.card(i);
            boolean hot = enabled(i) && (Gfx.in(mx, my, c[0], c[1], c[2], c[3]) || focus == i);
            g.fill(c[0], c[1], c[0] + c[2], c[1] + c[3], hot ? Gfx.ELEVATED : Gfx.alpha(Gfx.SURFACE, 0.9f));
            g.fill(c[0], c[1], c[0] + (hot ? 2 : 1), c[1] + c[3], hot ? Gfx.BURNT : Gfx.alpha(Gfx.TITANIUM, 0.25f));
            int ty = c[1] + Math.max(2, (c[3] - (c[3] >= 22 ? 18 : 8)) / 2);
            g.drawString(font, ITEMS[i][0], c[0] + 8, ty, enabled(i) ? Gfx.TEXT : Gfx.TEXT2, false);
            if (c[3] >= 22) g.drawString(font, Gfx.fit(font, enabled(i) ? ITEMS[i][1] : "Disabled by your account", c[2] - 12), c[0] + 8, ty + 10, Gfx.TEXT2, false);
        }

        String profile = EclipseClient.PROFILES == null ? "Default" : EclipseClient.PROFILES.current();
        String[] info = {
            "Player  " + minecraft.getUser().getName(),
            "Minecraft  " + SharedConstants.getCurrentVersion().getName(),
            "Eclipse Client  " + EclipseClient.VERSION + "   Profile  " + profile,
        };
        int right = width - 8;
        for (int i = 0; i < info.length; i++) {
            g.drawString(font, info[i], right - font.width(info[i]), height - 10 - (info.length - 1 - i) * 10, Gfx.TEXT2, false);
        }
    }

    private void activate(int i) {
        if (!enabled(i)) return;
        Minecraft mc = minecraft;
        switch (i) {
            case 0 -> mc.setScreen(new SelectWorldScreen(this));
            case 1 -> mc.setScreen(new JoinMultiplayerScreen(this));
            case 2 -> mc.setScreen(new ModuleWorkspaceScreen(this));
            case 3 -> mc.setScreen(new OptionsScreen(this, mc.options));
            default -> mc.stop();
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        for (int i = 0; i < TitleLayout.CARDS; i++) {
            int[] c = lay.card(i);
            if (Gfx.in(mx, my, c[0], c[1], c[2], c[3])) { activate(i); return true; }
        }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) { minecraft.setScreen(new ModuleWorkspaceScreen(this)); return true; }
        if (key == GLFW.GLFW_KEY_DOWN) { focus = (focus + 1) % TitleLayout.CARDS; return true; }
        if (key == GLFW.GLFW_KEY_UP) { focus = (focus <= 0 ? TitleLayout.CARDS : focus) - 1; return true; }
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) && focus >= 0) { activate(focus); return true; }
        return super.keyPressed(key, scan, mods);
    }
}
