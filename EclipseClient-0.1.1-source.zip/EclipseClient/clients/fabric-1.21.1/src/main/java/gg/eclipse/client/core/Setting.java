package gg.eclipse.client.core;

import java.util.List;

/** A persisted module option. Values are stored as strings so any option can round-trip through Properties. */
public abstract class Setting<T> {
    public final String key;
    public final String label;
    protected T value;
    protected final T defaultValue;

    protected Setting(String key, String label, T defaultValue) {
        this.key = key;
        this.label = label;
        this.value = defaultValue;
        this.defaultValue = defaultValue;
    }

    public T get() { return value; }
    public void reset() { value = defaultValue; }
    public abstract String serialize();
    public abstract void deserialize(String s);

    public static final class Bool extends Setting<Boolean> {
        public Bool(String key, String label, boolean def) { super(key, label, def); }
        public void set(boolean v) { value = v; }
        public void toggle() { value = !value; }
        @Override public String serialize() { return Boolean.toString(value); }
        @Override public void deserialize(String s) { value = Boolean.parseBoolean(s); }
    }

    public static final class IntRange extends Setting<Integer> {
        public final int min, max, step;
        public IntRange(String key, String label, int def, int min, int max, int step) {
            super(key, label, clamp(def, min, max));
            this.min = min; this.max = max; this.step = Math.max(1, step);
        }
        private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
        public void set(int v) { value = clamp(v, min, max); }
        public void nudge(int dir) { set(value + dir * step); }
        /** Maps a 0..1 slider position onto the range, honouring step. */
        public void setFromFraction(double f) {
            double raw = min + Math.max(0, Math.min(1, f)) * (max - min);
            set((int) (Math.round((raw - min) / step) * step + min));
        }
        public double fraction() { return max == min ? 0 : (value - min) / (double) (max - min); }
        @Override public String serialize() { return Integer.toString(value); }
        @Override public void deserialize(String s) {
            try { set(Integer.parseInt(s.trim())); } catch (NumberFormatException e) { value = defaultValue; }
        }
    }

    public static final class Choice extends Setting<String> {
        public final List<String> options;
        public Choice(String key, String label, String def, List<String> options) {
            super(key, label, options.contains(def) ? def : options.get(0));
            this.options = List.copyOf(options);
        }
        public void cycle() { value = options.get((options.indexOf(value) + 1) % options.size()); }
        @Override public String serialize() { return value; }
        @Override public void deserialize(String s) { value = options.contains(s) ? s : defaultValue; }
    }
}
