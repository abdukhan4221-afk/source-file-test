package gg.eclipse.client.mixin;

import gg.eclipse.client.mc.Gfx;
import net.minecraft.SharedConstants;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.server.packs.resources.ReloadInstance;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Eclipse loading screen, drawn ON TOP of vanilla's LoadingOverlay.
 *
 * Vanilla's render() still runs completely: it advances the resource-reload progress, decides when loading is
 * finished, fades out, reports errors through its callback and removes the overlay. This mixin only ADDS drawing
 * after it (TAIL) and never cancels anything, so the lifecycle stays native. The percentage shown is the resource
 * reload's own actual progress (reload.getActualProgress()), not a timer. When the reload finishes, vanilla removes the overlay and ours disappears with it.
 */
@Mixin(LoadingOverlay.class)
public abstract class LoadingOverlayMixin {
    @Shadow @Final private ReloadInstance reload;
    @Shadow private long fadeOutStart;

    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void eclipse$render(GuiGraphics g, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        int w = g.guiWidth(), h = g.guiHeight();
        float a = 1f;
        if (fadeOutStart > -1L) {
            float t = (Util.getMillis() - fadeOutStart) / 1000f; // vanilla: first second fades the logo, second fades the screen
            a = t < 1f ? 1f : Math.max(0f, 1f - (t - 1f));
        }
        if (a <= 0f) return;
        var font = net.minecraft.client.Minecraft.getInstance().font;
        long now = Util.getMillis();

        g.fill(0, 0, w, h, Gfx.alpha(Gfx.OBSIDIAN, a));
        Gfx.stars(g, w, h, now, a, 90);
        int r = Math.max(18, Math.min(h * 18 / 100, 56));
        int cx = w / 2, cy = h * 40 / 100;
        Gfx.eclipse(g, cx, cy, r, a);

        String title = "ECLIPSE CLIENT";
        g.drawString(font, title, cx - font.width(title) / 2, cy + r + 18, Gfx.alpha(Gfx.TEXT, a), false);

        int barW = Math.min(200, w * 60 / 100), barX = cx - barW / 2, barY = cy + r + 36;
        float p = Math.max(0f, Math.min(1f, reload.getActualProgress()));
        g.fill(barX, barY, barX + barW, barY + 2, Gfx.alpha(Gfx.ELEVATED, a));
        g.fill(barX, barY, barX + Math.round(barW * p), barY + 2, Gfx.alpha(Gfx.INFERNO, a));
        String status = "Loading game resources  " + Math.round(p * 100f) + "%";
        g.drawString(font, status, cx - font.width(status) / 2, barY + 8, Gfx.alpha(Gfx.TEXT2, a), false);
        String ver = "Minecraft " + SharedConstants.getCurrentVersion().getName() + "   Eclipse Client 0.1.0";
        g.drawString(font, ver, cx - font.width(ver) / 2, h - 14, Gfx.alpha(Gfx.TEXT2, a * 0.8f), false);
    }
}
