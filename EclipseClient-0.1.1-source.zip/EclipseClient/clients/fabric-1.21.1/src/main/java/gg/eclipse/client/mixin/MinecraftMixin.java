package gg.eclipse.client.mixin;

import gg.eclipse.client.screen.EclipseTitleScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Swaps the vanilla title screen for Eclipse's at the moment it is requested, so the vanilla one never flashes. */
@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true, require = 0)
    private Screen eclipse$replaceTitle(Screen screen) {
        return screen != null && screen.getClass() == TitleScreen.class ? new EclipseTitleScreen() : screen;
    }
}
