package gg.eclipse.client.core;

/**
 * Right-Shift workspace regions: top bar, bottom bar, left categories, centre module library, right details.
 * The details panel folds away on very small windows so the module grid is never squeezed below a usable width.
 */
public final class WorkspaceLayout {
    public final int topH = 20, bottomH = 14;
    public final int navX, navW, libX, libW, detX, detW, bodyY, bodyH;
    public final boolean showDetails;

    public WorkspaceLayout(int w, int h) {
        bodyY = topH;
        bodyH = Math.max(0, h - topH - bottomH);
        navX = 0;
        navW = Math.max(64, Math.min(120, w * 17 / 100));
        showDetails = w >= 300;
        detW = showDetails ? Math.max(110, Math.min(190, w * 27 / 100)) : 0;
        detX = w - detW;
        libX = navX + navW;
        libW = Math.max(0, detX - libX);
    }

    public boolean inLibrary(double x, double y) { return x >= libX && x < libX + libW && y >= bodyY && y < bodyY + bodyH; }
}
