package gg.eclipse.client.core;

/**
 * Position and presentation of one HUD element. Placement is stored as an anchor plus an offset so a layout
 * survives resolution and GUI-scale changes; {@link #resolve} turns it into pixels and always keeps it on screen.
 */
public final class HudElement {
    public enum Anchor {
        TOP_LEFT(0, 0), TOP_CENTER(.5, 0), TOP_RIGHT(1, 0),
        MIDDLE_LEFT(0, .5), CENTER(.5, .5), MIDDLE_RIGHT(1, .5),
        BOTTOM_LEFT(0, 1), BOTTOM_CENTER(.5, 1), BOTTOM_RIGHT(1, 1);
        public final double fx, fy;
        Anchor(double fx, double fy) { this.fx = fx; this.fy = fy; }
    }

    public final String moduleId;
    public Anchor anchor = Anchor.TOP_LEFT;
    public int offsetX = 4, offsetY = 4;
    public int scalePercent = 100;   // 50..200
    public int opacityPercent = 100; // 10..100
    public boolean visible = true;

    public HudElement(String moduleId) { this.moduleId = moduleId; }

    public int[] resolve(int screenW, int screenH, int contentW, int contentH) {
        double s = scalePercent / 100.0;
        int w = (int) Math.ceil(contentW * s), h = (int) Math.ceil(contentH * s);
        int x = (int) Math.round(anchor.fx * (screenW - w)) + offsetX;
        int y = (int) Math.round(anchor.fy * (screenH - h)) + offsetY;
        x = Math.max(0, Math.min(Math.max(0, screenW - w), x));
        y = Math.max(0, Math.min(Math.max(0, screenH - h), y));
        return new int[] { x, y, w, h };
    }

    /** Drag target: pick the nearest anchor to the element's centre and store the offset from it. Optional grid snap. */
    public void moveTo(int x, int y, int screenW, int screenH, int contentW, int contentH, int grid) {
        double s = scalePercent / 100.0;
        int w = (int) Math.ceil(contentW * s), h = (int) Math.ceil(contentH * s);
        x = Math.max(0, Math.min(Math.max(0, screenW - w), snap(x, grid)));
        y = Math.max(0, Math.min(Math.max(0, screenH - h), snap(y, grid)));
        double cx = (x + w / 2.0) / Math.max(1, screenW), cy = (y + h / 2.0) / Math.max(1, screenH);
        Anchor best = Anchor.TOP_LEFT;
        double bestD = Double.MAX_VALUE;
        for (Anchor a : Anchor.values()) {
            double d = Math.hypot(a.fx - cx, a.fy - cy);
            if (d < bestD) { bestD = d; best = a; }
        }
        anchor = best;
        offsetX = x - (int) Math.round(best.fx * (screenW - w));
        offsetY = y - (int) Math.round(best.fy * (screenH - h));
    }

    private static int snap(int v, int grid) { return grid <= 1 ? v : Math.round(v / (float) grid) * grid; }

    public void setScale(int pct) { scalePercent = Math.max(50, Math.min(200, pct)); }
    public void setOpacity(int pct) { opacityPercent = Math.max(10, Math.min(100, pct)); }
    public void reset() { anchor = Anchor.TOP_LEFT; offsetX = 4; offsetY = 4; scalePercent = 100; opacityPercent = 100; visible = true; }
}
