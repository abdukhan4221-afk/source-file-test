# Eclipse Client: Inferno

A Minecraft Java launcher (Electron + React + TypeScript) and an in-game client (Fabric 1.21.1, Java 21), sharing one visual identity.

**This is milestone 0.1.0, a verified foundation, not the finished product described in the original brief.** Read
[docs/STATUS.md](docs/STATUS.md) first; it lists exactly what is verified, what is written but unverified, and what does not exist.

## Quick start

```bash
npm install                      # Node 22+
npm run typecheck                # both launcher processes
npm run build                    # shared types + renderer + Electron main
npm test                         # 66 launcher/regression tests (vitest)
npm run test:java                # 140 pure-Java client-core tests (needs a JDK 21 only)
npm start -w @eclipse/launcher   # run the launcher (after build)
node scripts/package-launcher.mjs --linux dir   # unpacked Linux app in ./release
```

Do **not** run `electron-builder` directly inside the workspace: it prunes the hoisted root `node_modules`.
Use `scripts/package-launcher.mjs`, which packages from an isolated staging directory.

Fabric client (needs network access to Maven, not available where this was authored):

```bash
cd clients/fabric-1.21.1
chmod +x gradlew
./gradlew build coreTest      # produces build/dist/eclipseclient.jar
```

No jar is shipped (it cannot be built without Maven/Mojang access). See [docs/BUILDING_THE_JAR.md](docs/BUILDING_THE_JAR.md).

## Layout

| Path | What it is |
|---|---|
| `apps/launcher` | Electron app. `electron/core` is the testable engine; `src` is the React UI |
| `packages/shared-types` | Types and the typed IPC contract |
| `packages/design-system` | Inferno design tokens (CSS) |
| `clients/fabric-1.21.1` | In-game client: `core` (pure Java, tested) and `mc`/`screen`/`mixin` (Minecraft-facing) |
| `clients/forge-1.8.9` | Legacy skeleton, one FPS element. See its `STATUS.md` |
| `scripts` | Smoke test, visual QA, packaging |
| `docs` | Status, architecture, compatibility, reports, screenshots |
