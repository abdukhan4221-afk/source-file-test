// Types shared by the launcher main process, preload bridge and renderer.

export type VersionType = 'release' | 'snapshot' | 'old_beta' | 'old_alpha';

export interface MinecraftVersion {
  id: string;
  type: VersionType;
  url: string;
  releaseTime: string;
}

export type LoaderId =
  | 'vanilla' | 'fabric' | 'forge' | 'neoforge' | 'quilt'
  | 'legacy-fabric' | 'ornithe' | 'babric' | 'liteloader' | 'rift';

export interface LoaderSupport {
  loader: LoaderId;
  /** True only when the launcher has an installer implementation for it. */
  installable: boolean;
  /** Why a combination is unavailable (shown in the UI). */
  reason?: string;
}

export interface Profile {
  id: string;
  name: string;
  minecraftVersion: string;
  loader: LoaderId;
  loaderVersion?: string;
  createdAt: number;
  lastPlayedAt?: number;
  playtimeMs: number;
  pinned: boolean;
  order: number;
  javaPath?: string;
  memoryMb?: number;
  jvmArgs?: string;
  /** Absolute game directory, resolved by the main process. */
  gameDir: string;
}

export interface ProfilesState {
  profiles: Profile[];
  selectedId: string | null;
  defaultId: string | null;
}

export interface LocalAccount {
  kind: 'local';
  id: string;
  username: string;
  guest: boolean;
}

export interface MicrosoftAccount {
  kind: 'microsoft';
  id: string;
  username: string;
  uuid: string;
  skinUrl?: string;
  /** ISO time at which the Minecraft access token expires. */
  expiresAt: string;
}

export type Account = LocalAccount | MicrosoftAccount;

export interface AccountsState {
  accounts: Account[];
  selectedId: string | null;
  defaultId: string | null;
}

export interface DeviceCodeInfo {
  userCode: string;
  verificationUri: string;
  expiresInSec: number;
  intervalSec: number;
}

export type LaunchPhase =
  | 'idle' | 'preparing-profile' | 'checking-install' | 'preparing-libraries'
  | 'resolving-loader' | 'preparing-java' | 'starting' | 'running' | 'stopped' | 'failed';

export interface LaunchState {
  phase: LaunchPhase;
  profileId?: string;
  /** 0..1 when measurable, undefined for indeterminate. */
  progress?: number;
  detail?: string;
  pid?: number;
  error?: string;
  /** The stage that was running when the launch failed, so the UI can mark the right step. */
  failedPhase?: LaunchPhase;
}

export interface ServerEntry {
  id: string;
  name: string;
  address: string;
  description?: string;
  favorite: boolean;
}

export interface ServerStatus {
  online: boolean;
  latencyMs?: number;
  versionName?: string;
  protocol?: number;
  playersOnline?: number;
  playersMax?: number;
  motd?: string;
  error?: string;
}

export interface Settings {
  language: string;
  accent: string;
  reducedMotion: boolean;
  showStartup: boolean;
  background: { preset: string; customPath?: string; blur: number; dim: number };
  widgets: Record<string, boolean>;
  minecraft: {
    memoryMb: number;
    jvmArgs: string;
    javaPath?: string;
    width: number;
    height: number;
    fullscreen: boolean;
    safeMode: boolean;
  };
  msClientId: string;
  updateChannel: 'stable' | 'beta';
  /** Telemetry is not implemented and cannot be enabled. */
  telemetry: false;
}

export const DEFAULT_SETTINGS: Settings = {
  language: 'en',
  accent: '#E87532',
  reducedMotion: false,
  showStartup: true,
  background: { preset: 'totality', blur: 0, dim: 0.1 },
  widgets: { playtime: true, servers: true, news: true, status: true },
  minecraft: { memoryMb: 4096, jvmArgs: '', width: 1280, height: 720, fullscreen: false, safeMode: false },
  msClientId: '',
  updateChannel: 'stable',
  telemetry: false,
};

export type ModrinthKind = 'mod' | 'resourcepack' | 'shader' | 'modpack';

export interface ModrinthHit {
  projectId: string;
  slug: string;
  title: string;
  description: string;
  author: string;
  iconUrl?: string;
  downloads: number;
  kind: ModrinthKind;
}

export interface InstallProgress {
  id: string;
  label: string;
  done: number;
  total: number;
  stage: 'resolving' | 'downloading' | 'verifying' | 'applying' | 'done' | 'failed';
  error?: string;
}

/** Typed IPC surface exposed on window.eclipse by the preload script. */
export interface EclipseBridge {
  profiles: {
    state(): Promise<ProfilesState>;
    create(input: { name: string; minecraftVersion: string; loader: LoaderId }): Promise<Profile>;
    clone(id: string): Promise<Profile>;
    rename(id: string, name: string): Promise<void>;
    remove(id: string): Promise<void>;
    pin(id: string, pinned: boolean): Promise<void>;
    reorder(ids: string[]): Promise<void>;
    select(id: string): Promise<void>;
    setDefault(id: string): Promise<void>;
    openFolder(id: string, sub: 'game' | 'mods' | 'resourcepacks' | 'shaderpacks' | 'config' | 'saves'): Promise<void>;
  };
  versions: {
    list(refresh?: boolean): Promise<{ versions: MinecraftVersion[]; fromCache: boolean; fetchedAt: number }>;
    loaders(mcVersion: string): Promise<LoaderSupport[]>;
  };
  java: {
    detect(): Promise<{ path: string; major: number; vendor?: string }[]>;
    required(mcVersion: string): Promise<number>;
  };
  accounts: {
    state(): Promise<AccountsState>;
    addLocal(username: string, guest: boolean): Promise<Account>;
    remove(id: string): Promise<void>;
    select(id: string): Promise<void>;
    setDefault(id: string): Promise<void>;
    rename(id: string, username: string): Promise<void>;
    microsoftBegin(): Promise<DeviceCodeInfo>;
    microsoftFinish(): Promise<Account>;
  };
  launch: {
    start(profileId: string): Promise<void>;
    stop(): Promise<void>;
    state(): Promise<LaunchState>;
    onState(cb: (s: LaunchState) => void): () => void;
  };
  servers: {
    list(): Promise<ServerEntry[]>;
    save(entry: Omit<ServerEntry, 'id'> & { id?: string }): Promise<ServerEntry>;
    remove(id: string): Promise<void>;
    ping(address: string): Promise<ServerStatus>;
  };
  modrinth: {
    search(q: { query: string; kind: ModrinthKind; mcVersion?: string; loader?: LoaderId }): Promise<ModrinthHit[]>;
    install(projectId: string, kind: ModrinthKind, profileId: string): Promise<void>;
    onProgress(cb: (p: InstallProgress) => void): () => void;
  };
  settings: { get(): Promise<Settings>; set(patch: Partial<Settings>): Promise<Settings> };
  system: {
    openExternal(url: string): Promise<void>;
    appVersion(): Promise<string>;
    exportDiagnostics(): Promise<string>;
  };
}

declare global {
  interface Window {
    eclipse?: EclipseBridge;
  }
}
