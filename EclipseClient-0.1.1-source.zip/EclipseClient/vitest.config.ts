import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  resolve: {
    alias: {
      '@eclipse/shared-types': fileURLToPath(new URL('./packages/shared-types/src/index.ts', import.meta.url)),
    },
  },
  test: {
    include: ['tests/**/*.test.ts', 'apps/**/*.test.ts'],
    environment: 'node',
    testTimeout: 15000,
  },
});
