import { useEffect, useState } from 'react';
import { useApp } from '../lib/state';
import { PageHead } from '../components/ui';
import { EclipseMark } from '../components/Eclipse';

export function About() {
  const { api } = useApp();
  const [v, setV] = useState('');
  useEffect(() => { void api.system.appVersion().then(setV); }, [api]);
  return (
    <div className="page">
      <PageHead title="About" />
      <div className="row" style={{ gap: 24, alignItems: 'flex-start' }}>
        <EclipseMark size={96} />
        <div style={{ maxWidth: '62ch' }}>
          <h2 style={{ fontSize: 24 }}>Eclipse Client {v}</h2>
          <p className="muted">A new era of Eclipse. Inferno theme.</p>
          <h3 style={{ marginTop: 24 }}>What works in this version</h3>
          <p className="muted">Profiles, the official version list, Java detection, vanilla launching, Modrinth installs, modpack import, server status, local accounts and Microsoft sign-in (with your own application ID).</p>
          <h3 style={{ marginTop: 20 }}>What does not exist yet</h3>
          <p className="muted">Loader installers (Fabric, Forge and others), the in-game Eclipse client download, a 3D skin viewer, the store backend and update delivery. Each is shown as unavailable instead of being faked.</p>
          <p className="muted" style={{ marginTop: 24, fontSize: 12 }}>Eclipse Client is not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang Studios.</p>
        </div>
      </div>
    </div>
  );
}
