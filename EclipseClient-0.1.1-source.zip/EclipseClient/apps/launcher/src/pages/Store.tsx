import { Empty, PageHead } from '../components/ui';

export function Store() {
  return (
    <div className="page">
      <PageHead title="Store" sub="Cosmetics and capes for Eclipse Client." />
      <Empty title="The store is not connected">
        <p>A store needs three things this build does not include: a product catalogue service, a payment provider, and a way for the game to show purchases to other players. Until those exist there is nothing to list, and no purchase can be made.</p>
        <p>When a store backend is configured, this page will show its catalogue, what you own, and what you have equipped.</p>
      </Empty>
    </div>
  );
}
