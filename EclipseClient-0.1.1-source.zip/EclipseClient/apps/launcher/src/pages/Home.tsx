import { useEffect, useState } from 'react';
import { Play, Square } from 'lucide-react';
import type { ServerStatus } from '@eclipse/shared-types';
import { formatAgo, formatDuration, useActiveAccount, useApp, useSelectedProfile } from '../lib/state';
import { EclipseHero, Starfield } from '../components/Eclipse';
import { RELEASE_NOTES } from '../lib/notes';

const LOADER_NAMES: Record<string, string> = { vanilla: 'Vanilla', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge', quilt: 'Quilt' };

export function Home({ onLaunch, goto }: { onLaunch: () => void; goto: (p: 'profiles' | 'settings' | 'servers') => void }) {
  const { api, launch, settings, run } = useApp();
  const profile = useSelectedProfile();
  const account = useActiveAccount();
  const [java, setJava] = useState<number | null>(null);
  const [servers, setServers] = useState<{ name: string; address: string; status?: ServerStatus }[]>([]);
  const busy = !['idle', 'stopped', 'failed'].includes(launch.phase);
  const running = launch.phase === 'running' && launch.profileId === profile?.id;

  useEffect(() => {
    if (profile) void api.java.required(profile.minecraftVersion).then(setJava);
  }, [api, profile]);

  useEffect(() => {
    let live = true;
    void api.servers.list().then((list) => {
      const top = list.slice(0, 3).map((s) => ({ name: s.name, address: s.address }));
      setServers(top);
      top.forEach((s, i) => void api.servers.ping(s.address).then((status) => live && setServers((cur) => cur.map((c, j) => (j === i ? { ...c, status } : c)))));
    });
    return () => { live = false; };
  }, [api]);

  const play = async () => {
    if (!profile) return goto('profiles');
    onLaunch();
    await run(() => api.launch.start(profile.id));
  };

  const bg = settings.background;
  return (
    <div className="home">
      <div className={`bg ${bg.preset === 'ember' ? 'ember' : ''}`} style={{ filter: bg.blur ? `blur(${bg.blur}px)` : undefined }}>
        {bg.preset !== 'ember' && <Starfield density={120} reduced={settings.reducedMotion} />}
        {bg.preset === 'totality' && <EclipseHero className="hero-art" />}
        <div className="shade" />
        <div style={{ position: 'absolute', inset: 0, background: `rgba(8,9,13,${bg.dim})` }} />
      </div>

      <div className="home-main">
        <div className="home-kicker">
          <span className={`dot ${running ? 'on' : ''}`} />
          <span>{running ? 'Minecraft is running' : busy ? 'Preparing your game' : profile ? 'Ready to play' : 'No profile yet'}</span>
        </div>
        <h1 className="home-title">{profile ? profile.name : 'Create your first profile'}</h1>
        {profile && (
          <div className="home-meta">
            <span>Minecraft {profile.minecraftVersion}</span>
            <span>{LOADER_NAMES[profile.loader] ?? profile.loader}</span>
            {account && <span>{account.username}{account.kind === 'local' ? ' (local)' : ''}</span>}
          </div>
        )}
        <div className="play-row">
          {running ? (
            <button className="play running" onClick={() => void api.launch.stop()}><Square size={18} /> Stop game</button>
          ) : (
            <button className="play" disabled={busy} onClick={() => void play()}>
              <Play size={20} fill="currentColor" /> {busy ? 'Starting…' : profile ? 'Play' : 'Create profile'}
            </button>
          )}
          {profile && <button className="btn quiet" onClick={() => goto('profiles')}>Change profile</button>}
        </div>
        {!account && <p className="muted" style={{ marginTop: 14 }}>Add an account in <button className="btn quiet" style={{ padding: 0 }} onClick={() => goto('settings')}>Settings</button> to play.</p>}
      </div>

      <div className="home-foot">
        {settings.widgets.playtime && (
          <div>
            <h3>This profile</h3>
            <dl className="facts">
              <dt>Playtime</dt><dd>{profile ? formatDuration(profile.playtimeMs) : '-'}</dd>
              <dt>Last played</dt><dd>{profile ? formatAgo(profile.lastPlayedAt) : '-'}</dd>
              <dt>Java needed</dt><dd>{java ? `Java ${java}` : '-'}</dd>
            </dl>
          </div>
        )}
        {settings.widgets.servers && (
          <div>
            <h3>Servers</h3>
            {servers.length === 0 && <span className="muted">No servers saved. <button className="btn quiet" style={{ padding: 0 }} onClick={() => goto('servers')}>Add one</button></span>}
            {servers.map((s) => (
              <div key={s.address} className="mini-srv">
                <span className={`dot ${s.status ? (s.status.online ? 'on' : 'off') : ''}`} />
                <span className="grow">{s.name}</span>
                <span className="muted">{s.status ? (s.status.online ? `${s.status.playersOnline ?? '?'} online, ${s.status.latencyMs} ms` : 'Offline') : 'Checking'}</span>
              </div>
            ))}
          </div>
        )}
        {settings.widgets.news && (
          <div className="notes">
            <h3>Release notes</h3>
            {RELEASE_NOTES.map((n, i) => <p key={i}><b>{n.version}</b> {n.text}</p>)}
          </div>
        )}
      </div>
    </div>
  );
}
