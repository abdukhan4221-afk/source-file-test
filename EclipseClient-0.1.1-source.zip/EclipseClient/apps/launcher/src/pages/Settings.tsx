import { useEffect, useState } from 'react';
import { DEFAULT_SETTINGS, type DeviceCodeInfo } from '@eclipse/shared-types';
import { useApp } from '../lib/state';
import { PageHead, Setting, Tabs, Toggle } from '../components/ui';

type Tab = 'general' | 'minecraft' | 'appearance' | 'account' | 'updates' | 'diagnostics';
const TABS: { id: Tab; label: string }[] = [
  { id: 'general', label: 'General' }, { id: 'minecraft', label: 'Minecraft' }, { id: 'appearance', label: 'Appearance' },
  { id: 'account', label: 'Accounts' }, { id: 'updates', label: 'Updates' }, { id: 'diagnostics', label: 'Diagnostics' },
];

function Num({ value, onCommit, min, max, label }: { value: number; onCommit: (n: number) => void; min: number; max: number; label: string }) {
  const [v, setV] = useState(String(value));
  useEffect(() => setV(String(value)), [value]);
  return <input className="input" style={{ width: 110 }} type="number" min={min} max={max} aria-label={label} value={v} onChange={(e) => setV(e.target.value)} onBlur={() => { const n = Number(v); if (Number.isFinite(n)) onCommit(Math.min(max, Math.max(min, n))); else setV(String(value)); }} />;
}

function Accounts() {
  const { api, accounts, settings, saveSettings, refresh, run } = useApp();
  const [name, setName] = useState('');
  const [device, setDevice] = useState<DeviceCodeInfo | null>(null);
  const [clientId, setClientId] = useState(settings.msClientId);

  const signIn = async () => {
    if (clientId !== settings.msClientId) await saveSettings({ msClientId: clientId });
    const info = await run(() => api.accounts.microsoftBegin());
    if (!info) return;
    setDevice(info);
    const acc = await run(() => api.accounts.microsoftFinish(), 'Signed in');
    setDevice(null);
    if (acc) await refresh();
  };
  const act = async (fn: () => Promise<unknown>, msg?: string) => { await run(fn, msg); await refresh(); };

  return (
    <div>
      <h3 style={{ marginBottom: 6 }}>Microsoft account</h3>
      <p className="muted" style={{ marginTop: 0, maxWidth: '64ch' }}>Sign in to play online. Eclipse uses a Microsoft public-client application ID that you register yourself in Azure (no secret needed). Sign-in tokens are stored with your operating system&apos;s keystore.</p>
      <div className="row wrap" style={{ marginBottom: 12 }}>
        <input className="input" style={{ maxWidth: 360 }} placeholder="Application (client) ID" value={clientId} onChange={(e) => setClientId(e.target.value)} aria-label="Microsoft application ID" />
        <button className="btn primary" disabled={!clientId.trim() || !!device} onClick={() => void signIn()}>Sign in with Microsoft</button>
      </div>
      {device && (
        <div className="target" style={{ alignItems: 'center' }}>
          <div><span>Enter this code at {device.verificationUri}</span><div className="code">{device.userCode}</div></div>
          <div className="muted">Waiting for you to finish in the browser. The code expires in {Math.round(device.expiresInSec / 60)} minutes.</div>
        </div>
      )}
      <h3 style={{ margin: '28px 0 6px' }}>Local accounts</h3>
      <p className="muted" style={{ marginTop: 0, maxWidth: '64ch' }}>Local accounts only work in singleplayer, LAN and servers that run in offline mode. They cannot join online servers.</p>
      <div className="row wrap" style={{ marginBottom: 20 }}>
        <input className="input" style={{ maxWidth: 220 }} placeholder="Username (3 to 16 characters)" value={name} onChange={(e) => setName(e.target.value)} aria-label="Local username" maxLength={16} />
        <button className="btn" onClick={() => void act(async () => { await api.accounts.addLocal(name, false); setName(''); }, 'Account added')}>Add local account</button>
        <button className="btn quiet" onClick={() => void act(() => api.accounts.addLocal('', true), 'Guest session started')}>Start guest session</button>
      </div>
      <div className="list">
        {accounts.accounts.length === 0 && <div className="muted" style={{ padding: 14 }}>No accounts yet.</div>}
        {accounts.accounts.map((a) => (
          <div key={a.id} className="item">
            <div className="avatar">{a.username[0]?.toUpperCase()}</div>
            <div className="grow">
              <div className="title">{a.username}</div>
              <div className="sub">{a.kind === 'microsoft' ? 'Microsoft account, online play' : a.guest ? 'Guest session, forgotten when the launcher closes' : 'Local account, offline only'}</div>
            </div>
            {accounts.defaultId === a.id && <span className="badge ok">Default</span>}
            {accounts.selectedId === a.id ? <span className="badge ok">In use</span> : <button className="btn" onClick={() => void act(() => api.accounts.select(a.id))}>Use</button>}
            {!(a.kind === 'local' && a.guest) && accounts.defaultId !== a.id && <button className="btn quiet" onClick={() => void act(() => api.accounts.setDefault(a.id))}>Make default</button>}
            {a.kind === 'local' && !a.guest && <button className="btn quiet" onClick={() => { const n = prompt('New username', a.username); if (n) void act(() => api.accounts.rename(a.id, n)); }}>Rename</button>}
            <button className="btn quiet danger" onClick={() => void act(() => api.accounts.remove(a.id), 'Account removed')}>{a.kind === 'microsoft' ? 'Sign out' : 'Remove'}</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export function Settings() {
  const { api, settings: s, saveSettings, notify, run } = useApp();
  const [tab, setTab] = useState<Tab>('general');
  const [java, setJava] = useState<{ path: string; major: number; vendor?: string }[] | null>(null);
  const [report, setReport] = useState('');
  const mc = (patch: Partial<typeof s.minecraft>) => saveSettings({ minecraft: { ...s.minecraft, ...patch } });

  return (
    <div className="page">
      <PageHead title="Settings" />
      <Tabs value={tab} options={TABS} onChange={setTab} />
      <div style={{ maxWidth: 820 }}>
        {tab === 'general' && (
          <>
            <Setting title="Language" desc="Only English is translated so far."><select className="input" value="en" disabled aria-label="Language"><option value="en">English</option></select></Setting>
            <Setting title="Show startup animation" desc="Initialisation always runs; this only controls the pause on the last frame."><Toggle label="Show startup animation" checked={s.showStartup} onChange={(v) => void saveSettings({ showStartup: v })} /></Setting>
            <Setting title="Reduce motion" desc="Stops the starfield, orbit rings and transitions."><Toggle label="Reduce motion" checked={s.reducedMotion} onChange={(v) => void saveSettings({ reducedMotion: v })} /></Setting>
            <Setting title="Telemetry" desc="Eclipse does not collect usage data. There is no switch to turn it on."><span className="badge">Off</span></Setting>
          </>
        )}
        {tab === 'minecraft' && (
          <>
            <Setting title="Memory" desc="Maximum RAM for the game, in MB."><Num label="Memory in MB" value={s.minecraft.memoryMb} min={512} max={65536} onCommit={(n) => void mc({ memoryMb: n })} /></Setting>
            <Setting title="Window size" desc="Width and height when not fullscreen."><div className="row"><Num label="Width" value={s.minecraft.width} min={320} max={7680} onCommit={(n) => void mc({ width: n })} /><span className="muted">x</span><Num label="Height" value={s.minecraft.height} min={240} max={4320} onCommit={(n) => void mc({ height: n })} /></div></Setting>
            <Setting title="Fullscreen"><Toggle label="Fullscreen" checked={s.minecraft.fullscreen} onChange={(v) => void mc({ fullscreen: v })} /></Setting>
            <Setting title="Extra JVM arguments" desc="Added before Minecraft's own arguments."><input className="input" style={{ width: 320 }} defaultValue={s.minecraft.jvmArgs} aria-label="JVM arguments" onBlur={(e) => void mc({ jvmArgs: e.target.value })} /></Setting>
            <Setting title="Java" desc={s.minecraft.javaPath ? s.minecraft.javaPath : 'Automatic: the launcher picks the Java version each Minecraft release needs.'}>
              <div className="row">
                <button className="btn" onClick={async () => setJava((await run(() => api.java.detect())) ?? [])}>Detect installed Java</button>
                {s.minecraft.javaPath && <button className="btn quiet" onClick={() => void saveSettings({ minecraft: { ...s.minecraft, javaPath: undefined } })}>Use automatic</button>}
              </div>
            </Setting>
            {java && (
              <div className="list" style={{ marginTop: 8 }}>
                {java.length === 0 && <div className="muted" style={{ padding: 14 }}>No Java found. Install Java 21 (and Java 8 for older versions).</div>}
                {java.map((j) => <div key={j.path} className="item"><div className="grow"><div className="title">Java {j.major} {j.vendor ?? ''}</div><div className="sub">{j.path}</div></div><button className="btn" onClick={() => void saveSettings({ minecraft: { ...s.minecraft, javaPath: j.path } })}>Use this for all profiles</button></div>)}
              </div>
            )}
          </>
        )}
        {tab === 'appearance' && (
          <>
            <Setting title="Home background">
              <div className="chip-row">{[['totality', 'Totality'], ['ember', 'Ember'], ['void', 'Void']].map(([id, label]) => <button key={id} className="chip" aria-pressed={s.background.preset === id} onClick={() => void saveSettings({ background: { ...s.background, preset: id as string } })}>{label}</button>)}</div>
            </Setting>
            <Setting title="Blur" desc="Blurs the background art only, never the text."><input type="range" min={0} max={20} value={s.background.blur} aria-label="Blur" onChange={(e) => void saveSettings({ background: { ...s.background, blur: Number(e.target.value) } })} /></Setting>
            <Setting title="Dimming"><input type="range" min={0} max={0.8} step={0.05} value={s.background.dim} aria-label="Dimming" onChange={(e) => void saveSettings({ background: { ...s.background, dim: Number(e.target.value) } })} /></Setting>
            <Setting title="Accent color"><input type="color" value={s.accent} aria-label="Accent color" onChange={(e) => void saveSettings({ accent: e.target.value })} /></Setting>
            {([['playtime', 'Playtime widget'], ['servers', 'Servers widget'], ['news', 'Release notes widget']] as const).map(([k, label]) => (
              <Setting key={k} title={label}><Toggle label={label} checked={s.widgets[k] ?? true} onChange={(v) => void saveSettings({ widgets: { ...s.widgets, [k]: v } })} /></Setting>
            ))}
            <div style={{ marginTop: 18 }}><button className="btn" onClick={() => void saveSettings({ background: DEFAULT_SETTINGS.background, accent: DEFAULT_SETTINGS.accent, widgets: DEFAULT_SETTINGS.widgets })}>Restore appearance defaults</button></div>
          </>
        )}
        {tab === 'account' && <Accounts />}
        {tab === 'updates' && (
          <>
            <Setting title="Update channel"><select className="input" value={s.updateChannel} aria-label="Update channel" onChange={(e) => void saveSettings({ updateChannel: e.target.value as 'stable' | 'beta' })}><option value="stable">Stable</option><option value="beta">Beta</option></select></Setting>
            <div className="notice" style={{ marginTop: 18 }}>No update feed is configured, so this build cannot check for or download updates. Your channel choice is saved for when a feed is added.</div>
          </>
        )}
        {tab === 'diagnostics' && (
          <>
            <Setting title="Export a diagnostics report" desc="Versions, platform and non-secret settings. Tokens and your application ID are never included."><button className="btn" onClick={async () => { const f = await run(() => api.system.exportDiagnostics()); if (f) { setReport(f); notify('Report saved', 'success'); } }}>Export report</button></Setting>
            {report && <p className="muted">Saved to {report}</p>}
            <p className="muted" style={{ marginTop: 18 }}>Minecraft output for each profile is written to <code>logs/minecraft-&lt;profile id&gt;.log</code> in the launcher data folder.</p>
          </>
        )}
      </div>
    </div>
  );
}
