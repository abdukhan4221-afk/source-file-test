import { useEffect, useMemo, useState } from 'react';
import { Copy, FolderOpen, Pin, Plus, Star, Trash2 } from 'lucide-react';
import type { LoaderId, LoaderSupport, MinecraftVersion, Profile, VersionType } from '@eclipse/shared-types';
import { formatAgo, formatDuration, useApp } from '../lib/state';
import { Empty, PageHead } from '../components/ui';

const TYPES: { id: VersionType; label: string }[] = [
  { id: 'release', label: 'Releases' }, { id: 'snapshot', label: 'Snapshots' }, { id: 'old_beta', label: 'Old betas' }, { id: 'old_alpha', label: 'Old alphas' },
];

function CreateProfile({ onDone }: { onDone: () => void }) {
  const { api, run, refresh } = useApp();
  const [name, setName] = useState('');
  const [versions, setVersions] = useState<MinecraftVersion[]>([]);
  const [offline, setOffline] = useState(false);
  const [type, setType] = useState<VersionType>('release');
  const [search, setSearch] = useState('');
  const [version, setVersion] = useState('');
  const [loaders, setLoaders] = useState<LoaderSupport[]>([]);
  const [loader, setLoader] = useState<LoaderId>('vanilla');
  const [loading, setLoading] = useState(true);

  const load = async (force: boolean) => {
    setLoading(true);
    const r = await run(() => api.versions.list(force));
    if (r) { setVersions(r.versions); setOffline(r.fromCache && force); if (!version) setVersion(r.versions.find((v) => v.type === 'release')?.id ?? ''); }
    setLoading(false);
  };
  useEffect(() => { void load(false); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);
  useEffect(() => { if (version) void api.versions.loaders(version).then((l) => { setLoaders(l); setLoader('vanilla'); }); }, [api, version]);

  const shown = useMemo(() => versions.filter((v) => v.type === type && v.id.toLowerCase().includes(search.toLowerCase())).slice(0, 200), [versions, type, search]);
  const create = async () => {
    const p = await run(() => api.profiles.create({ name: name || `Minecraft ${version}`, minecraftVersion: version, loader }), 'Profile created');
    if (p) { await refresh(); onDone(); }
  };

  return (
    <div className="split" style={{ marginBottom: 36 }}>
      <div className="field" style={{ gap: 16 }}>
        <div className="field"><label htmlFor="pn">Name</label><input id="pn" className="input" value={name} placeholder={`Minecraft ${version || ''}`} onChange={(e) => setName(e.target.value)} maxLength={48} /></div>
        <div className="field">
          <span className="label">Loader</span>
          <div className="chip-row">
            {loaders.map((l) => <button key={l.loader} className="chip" aria-pressed={loader === l.loader} disabled={!l.installable} title={l.reason} onClick={() => setLoader(l.loader)}>{l.loader}</button>)}
          </div>
          <span className="muted" style={{ fontSize: 12 }}>Loaders without an installer are disabled instead of failing later. Hover a disabled loader to see why.</span>
        </div>
        <div className="row"><button className="btn primary" disabled={!version} onClick={() => void create()}><Plus size={16} />Create profile</button><button className="btn quiet" onClick={onDone}>Cancel</button></div>
      </div>
      <div>
        <div className="row wrap" style={{ marginBottom: 12 }}>
          <div className="chip-row">{TYPES.map((t) => <button key={t.id} className="chip" aria-pressed={type === t.id} onClick={() => setType(t.id)}>{t.label}</button>)}</div>
          <input className="input grow" style={{ maxWidth: 220 }} placeholder="Search versions" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search versions" />
          <button className="btn quiet" onClick={() => void load(true)}>Refresh</button>
        </div>
        {offline && <div className="notice">Could not reach Mojang. Showing the saved version list.</div>}
        <div className="list" style={{ maxHeight: 300, overflowY: 'auto' }}>
          {loading && <div className="muted" style={{ padding: 14 }}>Loading versions</div>}
          {shown.map((v) => (
            <button key={v.id} className="item" style={{ width: '100%', background: version === v.id ? 'rgba(232,117,50,.08)' : 'none', border: 0, borderBottom: '1px solid var(--line)', textAlign: 'left' }} onClick={() => setVersion(v.id)}>
              <span className="grow">{v.id}</span><span className="muted">{v.releaseTime.slice(0, 10)}</span>
            </button>
          ))}
          {!loading && shown.length === 0 && <div className="muted" style={{ padding: 14 }}>No versions match.</div>}
        </div>
      </div>
    </div>
  );
}

function Detail({ p }: { p: Profile }) {
  const { api, run, refresh, profiles } = useApp();
  const [name, setName] = useState(p.name);
  useEffect(() => setName(p.name), [p.id, p.name]);
  const open = (sub: Parameters<typeof api.profiles.openFolder>[1]) => void run(() => api.profiles.openFolder(p.id, sub));
  const act = async (fn: () => Promise<unknown>, msg?: string) => { await run(fn, msg); await refresh(); };
  return (
    <div>
      <div className="row" style={{ marginBottom: 6 }}>
        <input className="input" style={{ fontSize: 20, fontFamily: 'var(--font-display)', maxWidth: 360 }} value={name} onChange={(e) => setName(e.target.value)} onBlur={() => name !== p.name && void act(() => api.profiles.rename(p.id, name))} aria-label="Profile name" />
      </div>
      <p className="muted" style={{ marginTop: 0 }}>Minecraft {p.minecraftVersion}, {p.loader}. Played {formatDuration(p.playtimeMs)}, last {formatAgo(p.lastPlayedAt)}.</p>
      <div className="row wrap" style={{ margin: '18px 0' }}>
        <button className="btn primary" disabled={profiles.selectedId === p.id} onClick={() => void act(() => api.profiles.select(p.id), 'Selected for launch')}>{profiles.selectedId === p.id ? 'Selected for launch' : 'Use for launch'}</button>
        <button className="btn" onClick={() => void act(() => api.profiles.setDefault(p.id), 'Set as default')}><Star size={15} />{profiles.defaultId === p.id ? 'Default' : 'Make default'}</button>
        <button className="btn" onClick={() => void act(() => api.profiles.pin(p.id, !p.pinned))}><Pin size={15} />{p.pinned ? 'Unpin' : 'Pin'}</button>
        <button className="btn" onClick={() => void act(() => api.profiles.clone(p.id), 'Profile cloned')}><Copy size={15} />Clone</button>
        <button className="btn danger" onClick={() => { if (confirm(`Remove "${p.name}"? Its folder, including worlds, is moved to the launcher's trash folder, not deleted.`)) void act(() => api.profiles.remove(p.id), 'Profile removed'); }}><Trash2 size={15} />Remove</button>
      </div>
      <div className="label" style={{ marginBottom: 8 }}>Open folder</div>
      <div className="chip-row">
        {(['game', 'mods', 'resourcepacks', 'shaderpacks', 'config', 'saves'] as const).map((s) => (
          <button key={s} className="btn" onClick={() => open(s)}><FolderOpen size={14} />{s === 'game' ? 'Game directory' : s}</button>
        ))}
      </div>
      <p className="muted" style={{ marginTop: 18, fontSize: 12 }}>{p.gameDir}</p>
    </div>
  );
}

export function Profiles() {
  const { profiles, api, refresh, run } = useApp();
  const [creating, setCreating] = useState(profiles.profiles.length === 0);
  const [openId, setOpenId] = useState<string | null>(profiles.selectedId);
  const current = profiles.profiles.find((p) => p.id === openId) ?? profiles.profiles[0];
  return (
    <div className="page">
      <PageHead title="Profiles" sub="Each profile is a separate game folder with its own version, mods, packs, settings and worlds.">
        {!creating && <button className="btn primary" onClick={() => setCreating(true)}><Plus size={16} />New profile</button>}
      </PageHead>
      {creating && <CreateProfile onDone={() => setCreating(false)} />}
      {profiles.profiles.length === 0 && !creating && <Empty title="No profiles yet">Create one to pick a Minecraft version and start playing.</Empty>}
      {profiles.profiles.length > 0 && (
        <div className="split">
          <div className="list">
            {profiles.profiles.map((p) => (
              <button key={p.id} className="item" onClick={() => setOpenId(p.id)} style={{ width: '100%', background: current?.id === p.id ? 'rgba(232,117,50,.08)' : 'none', border: 0, borderBottom: '1px solid var(--line)', textAlign: 'left' }}>
                <div className="grow"><div className="title">{p.name}</div><div className="sub">{p.minecraftVersion}, {p.loader}</div></div>
                {p.pinned && <Pin size={14} className="muted" />}
                {profiles.selectedId === p.id && <span className="badge ok">Launch</span>}
              </button>
            ))}
          </div>
          {current && <Detail p={current} />}
        </div>
      )}
    </div>
  );
}
