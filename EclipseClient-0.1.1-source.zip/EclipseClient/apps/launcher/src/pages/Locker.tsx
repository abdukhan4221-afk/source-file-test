import { useEffect, useRef, useState } from 'react';
import { Upload } from 'lucide-react';
import { useApp } from '../lib/state';
import { PageHead } from '../components/ui';

const KEY = 'eclipse.locker.skin';

// Front-view rectangles on the 64x64 skin sheet: [sx, sy, w, h, dx, dy]. Second list is the outer (hat/jacket) layer.
const BASE: number[][] = [[8, 8, 8, 8, 4, 0], [20, 20, 8, 12, 4, 8], [44, 20, 4, 12, 0, 8], [4, 20, 4, 12, 4, 20]];
const LEFT_64: number[][] = [[36, 52, 4, 12, 12, 8], [20, 52, 4, 12, 8, 20]];
const OUTER: number[][] = [[40, 8, 8, 8, 4, 0], [20, 36, 8, 12, 4, 8]];

function drawSkin(canvas: HTMLCanvasElement, img: HTMLImageElement) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, 16, 32);
  ctx.imageSmoothingEnabled = false;
  const blit = (r: number[]) => ctx.drawImage(img, r[0]!, r[1]!, r[2]!, r[3]!, r[4]!, r[5]!, r[2]!, r[3]!);
  BASE.forEach(blit);
  if (img.height === 64) LEFT_64.forEach(blit);
  else { // legacy 64x32 skins mirror the right limbs onto the left
    for (const [sx, sy, w, h, dx, dy] of [[44, 20, 4, 12, 12, 8], [4, 20, 4, 12, 8, 20]] as number[][]) {
      ctx.save(); ctx.translate(dx! + w!, dy!); ctx.scale(-1, 1); ctx.drawImage(img, sx!, sy!, w!, h!, 0, 0, w!, h!); ctx.restore();
    }
  }
  if (img.height === 64) OUTER.forEach(blit);
}

export function Locker() {
  const { notify } = useApp();
  const [skin, setSkin] = useState<string | null>(() => { try { return localStorage.getItem(KEY); } catch { return null; } });
  const canvas = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!skin || !canvas.current) return;
    const img = new Image();
    img.onload = () => canvas.current && drawSkin(canvas.current, img);
    img.src = skin;
  }, [skin]);

  const onFile = (file: File | undefined) => {
    if (!file) return;
    if (file.type !== 'image/png') return notify('Skins must be PNG files.', 'error');
    if (file.size > 256 * 1024) return notify('That file is too large for a skin.', 'error');
    const reader = new FileReader();
    reader.onload = () => {
      const url = String(reader.result);
      const img = new Image();
      img.onload = () => {
        if (img.width !== 64 || (img.height !== 64 && img.height !== 32)) return notify(`Skins must be 64x64 or 64x32 pixels. This one is ${img.width}x${img.height}.`, 'error');
        setSkin(url);
        try { localStorage.setItem(KEY, url); } catch { /* storage full or disabled */ }
        notify('Skin loaded for preview', 'success');
      };
      img.onerror = () => notify('That file is not a valid image.', 'error');
      img.src = url;
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="page">
      <PageHead title="Locker" sub="Preview skins on your own machine." />
      <div className="notice">Everything in the Locker is local. Other players cannot see these skins. Changing what other players see needs a real skin service, which this launcher does not run.</div>
      <div className="row" style={{ alignItems: 'flex-start', gap: 48 }}>
        <div>
          {skin ? <canvas ref={canvas} width={16} height={32} className="skin-canvas" style={{ width: 192, height: 384 }} aria-label="Front view of the loaded skin" />
            : <div className="skin-canvas" style={{ width: 192, height: 384, display: 'grid', placeItems: 'center', color: 'var(--text-2)' }}>No skin loaded</div>}
        </div>
        <div style={{ maxWidth: 420 }}>
          <h3 style={{ marginBottom: 8 }}>Import a skin</h3>
          <p className="muted">Choose a PNG file, 64x64 or 64x32 pixels. The preview shows the front of the player. A rotating 3D viewer is not built yet.</p>
          <label className="btn primary" style={{ cursor: 'pointer' }}>
            <Upload size={16} />Choose skin file
            <input type="file" accept="image/png" hidden onChange={(e) => onFile(e.target.files?.[0])} />
          </label>
          {skin && <button className="btn quiet" style={{ marginLeft: 8 }} onClick={() => { setSkin(null); try { localStorage.removeItem(KEY); } catch { /* ignore */ } }}>Remove</button>}
        </div>
      </div>
    </div>
  );
}
