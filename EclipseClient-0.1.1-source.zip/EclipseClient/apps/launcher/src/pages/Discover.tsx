import { useEffect, useState } from 'react';
import { Download } from 'lucide-react';
import type { InstallProgress, ModrinthHit, ModrinthKind } from '@eclipse/shared-types';
import { useApp, useSelectedProfile } from '../lib/state';
import { Empty, PageHead, Tabs } from '../components/ui';

const KINDS: { id: ModrinthKind; label: string }[] = [
  { id: 'mod', label: 'Mods' }, { id: 'resourcepack', label: 'Resource packs' }, { id: 'shader', label: 'Shaders' }, { id: 'modpack', label: 'Modpacks' },
];

export function Discover() {
  const { api, run, refresh } = useApp();
  const profile = useSelectedProfile();
  const [kind, setKind] = useState<ModrinthKind>('mod');
  const [query, setQuery] = useState('');
  const [hits, setHits] = useState<ModrinthHit[] | null>(null);
  const [searching, setSearching] = useState(false);
  const [progress, setProgress] = useState<Record<string, InstallProgress>>({});

  useEffect(() => api.modrinth.onProgress((p) => setProgress((m) => ({ ...m, [p.id]: p }))), [api]);

  const search = async () => {
    setSearching(true);
    const r = await run(() => api.modrinth.search({ query, kind, mcVersion: kind === 'modpack' ? undefined : profile?.minecraftVersion, loader: profile?.loader }));
    setHits(r ?? []);
    setSearching(false);
  };
  useEffect(() => { void search(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [kind, profile?.id]);

  const install = async (h: ModrinthHit) => {
    if (!profile && kind !== 'modpack') return;
    await run(() => api.modrinth.install(h.projectId, kind, profile?.id ?? ''));
    await refresh();
  };

  return (
    <div className="page">
      <PageHead title="Discover" sub="Content from Modrinth. Results are filtered for the profile you have selected.">
        <form className="row" onSubmit={(e) => { e.preventDefault(); void search(); }}>
          <input className="input" style={{ width: 260 }} placeholder={`Search ${KINDS.find((k) => k.id === kind)?.label.toLowerCase()}`} value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search Modrinth" />
          <button className="btn primary" type="submit">Search</button>
        </form>
      </PageHead>
      <Tabs value={kind} options={KINDS} onChange={(k) => { setKind(k); setHits(null); }} />
      {kind === 'modpack' ? (
        <div className="notice">Installing a modpack creates a new profile named after the pack. Your current profile is not touched.</div>
      ) : profile ? (
        <div className="target">
          <div><span>Installs into</span>{profile.name}</div>
          <div><span>Minecraft</span>{profile.minecraftVersion}</div>
          <div><span>Loader</span>{profile.loader}</div>
          <div><span>Game directory</span>{profile.gameDir}</div>
        </div>
      ) : (
        <Empty title="Select a profile first">Content is installed into a specific profile. Create or select one in Profiles.</Empty>
      )}
      {kind === 'mod' && profile?.loader === 'vanilla' && <div className="notice">Mods need a loader such as Fabric. This profile is Vanilla, so results are not filtered by loader and may not run.</div>}
      {searching && <div className="muted">Searching Modrinth</div>}
      {!searching && hits?.length === 0 && <Empty title="Nothing found">Try a different search, or switch profile to change the Minecraft version being filtered.</Empty>}
      <div className="list">
        {hits?.map((h) => {
          const p = progress[h.projectId];
          const busy = p && p.stage !== 'done' && p.stage !== 'failed';
          return (
            <div key={h.projectId} className="item">
              <div className="avatar" style={{ borderRadius: 6, width: 44, height: 44, background: h.iconUrl ? `center/cover url(${h.iconUrl})` : undefined }}>{h.iconUrl ? '' : h.title[0]}</div>
              <div className="grow">
                <div className="title">{h.title} <span className="muted" style={{ fontWeight: 400 }}>by {h.author}</span></div>
                <div className="sub">{h.description}</div>
              </div>
              <div className="muted" style={{ width: 120, textAlign: "right", whiteSpace: "nowrap" }}>{Intl.NumberFormat('en', { notation: 'compact' }).format(h.downloads)} downloads</div>
              <div style={{ width: 160 }}>
                {busy ? <div><div className="progress"><div style={{ width: `${p.total ? (p.done / p.total) * 100 : 5}%` }} /></div><span className="muted" style={{ fontSize: 12 }}>{p.stage}: {p.label}</span></div>
                  : p?.stage === 'done' ? <span className="badge ok">{p.label}</span>
                  : p?.stage === 'failed' ? <span className="badge" style={{ color: 'var(--error)' }} title={p.error}>Failed</span>
                  : <button className="btn" disabled={!profile && kind !== 'modpack'} onClick={() => void install(h)}><Download size={15} />Install</button>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
