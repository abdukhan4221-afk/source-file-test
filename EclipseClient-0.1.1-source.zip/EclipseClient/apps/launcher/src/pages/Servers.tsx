import { useEffect, useState } from 'react';
import { Copy, Star, Trash2 } from 'lucide-react';
import type { ServerEntry, ServerStatus } from '@eclipse/shared-types';
import { useApp } from '../lib/state';
import { Empty, PageHead } from '../components/ui';

export function Servers() {
  const { api, run, notify } = useApp();
  const [list, setList] = useState<ServerEntry[]>([]);
  const [status, setStatus] = useState<Record<string, ServerStatus | 'checking'>>({});
  const [form, setForm] = useState({ name: '', address: '', description: '' });

  const check = (s: ServerEntry) => {
    setStatus((m) => ({ ...m, [s.id]: 'checking' }));
    void api.servers.ping(s.address).then((r) => setStatus((m) => ({ ...m, [s.id]: r })));
  };
  const load = async () => { const l = await api.servers.list(); setList(l); l.forEach(check); };
  useEffect(() => { void load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const add = async () => {
    const r = await run(() => api.servers.save({ ...form, favorite: false }), 'Server saved');
    if (r) { setForm({ name: '', address: '', description: '' }); await load(); }
  };

  return (
    <div className="page">
      <PageHead title="Servers" sub="Status comes straight from each server. If a server does not answer, it is shown as offline." />
      <div className="row wrap" style={{ marginBottom: 28, alignItems: 'flex-end' }}>
        <div className="field"><label htmlFor="sn">Name</label><input id="sn" className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
        <div className="field"><label htmlFor="sa">Address</label><input id="sa" className="input" placeholder="play.example.com:25565" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
        <div className="field grow"><label htmlFor="sd">Description (optional)</label><input id="sd" className="input" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
        <button className="btn primary" onClick={() => void add()}>Add server</button>
      </div>
      {list.length === 0 && <Empty title="No servers saved">Add a server above to see whether it is online and how many players are connected.</Empty>}
      <div className="list">
        {list.map((s) => {
          const st = status[s.id];
          const info = st && st !== 'checking' ? st : undefined;
          return (
            <div key={s.id} className="item">
              <span className={`dot ${info ? (info.online ? 'on' : 'off') : ''}`} />
              <div className="grow">
                <div className="title">{s.name} <span className="muted" style={{ fontWeight: 400 }}>{s.address}</span></div>
                <div className="sub">{st === 'checking' || !st ? 'Checking' : info?.online ? `${info.motd || s.description || ''}`.trim() || 'Online' : info?.error ?? 'Offline'}</div>
              </div>
              {info?.online && <div className="muted" style={{ textAlign: 'right' }}>{info.playersOnline ?? '?'} / {info.playersMax ?? '?'} players<br />{info.latencyMs} ms, {info.versionName}</div>}
              <button className="btn quiet" aria-label="Favorite" onClick={() => void run(() => api.servers.save({ ...s, favorite: !s.favorite })).then(load)}><Star size={16} fill={s.favorite ? 'currentColor' : 'none'} /></button>
              <button className="btn quiet" aria-label="Copy address" onClick={() => { void navigator.clipboard.writeText(s.address); notify('Address copied', 'success'); }}><Copy size={16} /></button>
              <button className="btn quiet" onClick={() => check(s)}>Recheck</button>
              <button className="btn quiet danger" aria-label="Delete server" onClick={() => void run(() => api.servers.remove(s.id)).then(load)}><Trash2 size={16} /></button>
            </div>
          );
        })}
      </div>
    </div>
  );
}
