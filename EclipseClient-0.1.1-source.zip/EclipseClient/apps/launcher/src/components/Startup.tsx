import { useEffect, useState } from 'react';
import type { AccountsState, EclipseBridge, ProfilesState, Settings } from '@eclipse/shared-types';
import { EclipseMark, Starfield } from './Eclipse';

export interface Boot { profiles: ProfilesState; accounts: AccountsState; settings: Settings }

const withTimeout = <T,>(p: Promise<T>, ms: number): Promise<T | undefined> =>
  Promise.race([p, new Promise<undefined>((r) => setTimeout(() => r(undefined), ms))]);

/** Startup runs the app's real initialisation steps; the beam advances as each one finishes. It never waits on the network for more than 3 seconds. */
export function Startup({ api, onReady, onError }: { api: EclipseBridge; onReady: (b: Boot) => void; onError: (e: Error) => void }) {
  const [done, setDone] = useState(0);
  const [label, setLabel] = useState('Starting');
  const TOTAL = 4;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const step = async <T,>(text: string, fn: () => Promise<T>): Promise<T> => {
          if (cancelled) throw new Error('cancelled');
          setLabel(text);
          const r = await fn();
          setDone((d) => d + 1);
          return r;
        };
        const settings = await step('Loading settings', () => api.settings.get());
        const profiles = await step('Reading profiles', () => api.profiles.state());
        const accounts = await step('Checking accounts', () => api.accounts.state());
        await step('Refreshing version list', async () => { await withTimeout(api.versions.list().catch(() => undefined), 3000); });
        if (cancelled) return;
        const wait = settings.showStartup ? 450 : 0; // let the last frame of the beam land
        setTimeout(() => !cancelled && onReady({ profiles, accounts, settings }), wait);
      } catch (e) {
        if (!cancelled) onError(e as Error);
      }
    })();
    return () => { cancelled = true; };
  }, [api, onReady, onError]);

  return (
    <div className="startup" role="status" aria-live="polite">
      <Starfield density={170} />
      <div className="center">
        <div className="orbit o3"><i /></div>
        <div className="orbit o2"><i /></div>
        <div className="orbit o1"><i /></div>
        <div className="mark"><EclipseMark size={168} /></div>
      </div>
      <div className="below">
        <div className="name">Eclipse Client</div>
        <div className="muted">A new era of Eclipse</div>
        <div className="beam"><div style={{ width: `${(done / TOTAL) * 100}%` }} /></div>
        <div className="muted">{label}</div>
      </div>
    </div>
  );
}
