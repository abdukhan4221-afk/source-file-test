import { useEffect, useRef } from 'react';

/**
 * The Eclipse emblem: a black disc, a thin corona ring and a single "diamond ring" flare on its upper-left rim.
 * Pure SVG, no raster art. `size` scales the whole mark.
 */
export function EclipseMark({ size = 40, flare = true }: { size?: number; flare?: boolean }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" role="img" aria-label="Eclipse">
      <defs>
        <radialGradient id="em-corona" cx="50%" cy="50%" r="50%">
          <stop offset="62%" stopColor="#FF9B42" stopOpacity="0" />
          <stop offset="72%" stopColor="#FF9B42" stopOpacity="0.9" />
          <stop offset="84%" stopColor="#E87532" stopOpacity="0.35" />
          <stop offset="100%" stopColor="#E04A32" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="50" cy="50" r="48" fill="url(#em-corona)" />
      <circle cx="50" cy="50" r="31" fill="#08090D" />
      <circle cx="50" cy="50" r="31" fill="none" stroke="#FF9B42" strokeWidth="1.6" opacity="0.95" />
      {flare && (
        <g>
          <path d="M 22 31 L 31 33.5 L 22 36 Z" fill="#FFD9A8" opacity="0.0" />
          <circle cx="29.4" cy="31" r="2.2" fill="#FFF1DC" />
          <path d="M 14 31 H 45" stroke="#FFC98A" strokeWidth="0.9" opacity="0.8" />
        </g>
      )}
    </svg>
  );
}

/** The large hero eclipse used on Home and the startup screen. Corona is layered gradients, rays are hand-placed paths. */
export function EclipseHero({ className }: { className?: string }) {
  const rays = Array.from({ length: 28 }, (_, i) => {
    const a = (i / 28) * Math.PI * 2 + (i % 3) * 0.04;
    const r1 = 312;
    const len = 18 + ((i * 37) % 11) * 7;
    return { x1: 400 + Math.cos(a) * r1, y1: 400 + Math.sin(a) * r1, x2: 400 + Math.cos(a) * (r1 + len), y2: 400 + Math.sin(a) * (r1 + len), o: 0.15 + ((i * 53) % 10) / 40 };
  });
  return (
    <svg className={className} viewBox="0 0 800 800" aria-hidden="true">
      <defs>
        <radialGradient id="eh-glow" cx="50%" cy="50%" r="50%">
          {/* disc edge sits at 76% of this radius, so the corona must peak just outside it */}
          <stop offset="72%" stopColor="#E87532" stopOpacity="0" />
          <stop offset="76.5%" stopColor="#FFB36B" stopOpacity="0.85" />
          <stop offset="80%" stopColor="#FF9B42" stopOpacity="0.38" />
          <stop offset="88%" stopColor="#E87532" stopOpacity="0.12" />
          <stop offset="100%" stopColor="#E04A32" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="eh-rim" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#FFE2B8" />
          <stop offset="0.35" stopColor="#FF9B42" />
          <stop offset="1" stopColor="#E04A32" stopOpacity="0.15" />
        </linearGradient>
      </defs>
      <circle cx="400" cy="400" r="400" fill="url(#eh-glow)" />
      <g stroke="#FF9B42" strokeLinecap="round">
        {rays.map((r, i) => <line key={i} x1={r.x1} y1={r.y1} x2={r.x2} y2={r.y2} strokeWidth="1" opacity={r.o} />)}
      </g>
      <circle cx="400" cy="400" r="304" fill="#08090D" />
      <circle cx="400" cy="400" r="304" fill="none" stroke="url(#eh-rim)" strokeWidth="2.5" />
      {/* diamond ring: one bright point ON the rim (r=304 at 215deg), a thin flare tangent to it, and a soft bloom */}
      <circle cx="151" cy="226" r="26" fill="#FFB36B" opacity="0.18" />
      <circle cx="151" cy="226" r="6" fill="#FFF3E0" />
      <path d="M 70 226 H 232" stroke="#FFD29A" strokeWidth="1.2" opacity="0.65" />
      <path d="M 151 196 V 256" stroke="#FFD29A" strokeWidth="0.9" opacity="0.4" />
    </svg>
  );
}

/** Deterministic starfield on a canvas; stops animating under reduced motion. */
export function Starfield({ density = 140, reduced = false }: { density?: number; reduced?: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    let seed = 7;
    const rnd = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
    const stars = Array.from({ length: density }, () => ({ x: rnd(), y: rnd(), r: rnd() * 1.2 + 0.2, p: rnd() * Math.PI * 2, s: 0.4 + rnd() }));
    let raf = 0;
    const draw = (t: number) => {
      const { clientWidth: w, clientHeight: h } = canvas;
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
      ctx.clearRect(0, 0, w, h);
      for (const s of stars) {
        const a = reduced ? 0.55 : 0.35 + 0.35 * Math.sin(t / 1400 * s.s + s.p);
        ctx.fillStyle = `rgba(242,240,234,${a})`;
        ctx.beginPath();
        ctx.arc(s.x * w, s.y * h, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
      if (!reduced) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [density, reduced]);
  return <canvas ref={ref} className="starfield" aria-hidden="true" />;
}
