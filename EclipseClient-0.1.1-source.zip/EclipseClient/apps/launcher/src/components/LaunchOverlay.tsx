import { Check, X } from 'lucide-react';
import type { LaunchPhase } from '@eclipse/shared-types';
import { useApp } from '../lib/state';
import { EclipseMark } from './Eclipse';

const STAGES: { phase: LaunchPhase; label: string }[] = [
  { phase: 'preparing-profile', label: 'Preparing profile' },
  { phase: 'checking-install', label: 'Checking game installation' },
  { phase: 'preparing-libraries', label: 'Preparing libraries' },
  { phase: 'resolving-loader', label: 'Resolving loader' },
  { phase: 'preparing-java', label: 'Preparing Java' },
  { phase: 'starting', label: 'Starting Minecraft' },
  { phase: 'running', label: 'Game running' },
];

export function LaunchOverlay({ onDismiss }: { onDismiss: () => void }) {
  const { launch, api } = useApp();
  const failIdx = STAGES.findIndex((s) => s.phase === launch.failedPhase);
  const idx = launch.phase === 'failed' ? failIdx : STAGES.findIndex((s) => s.phase === launch.phase);
  const failed = launch.phase === 'failed';
  const running = launch.phase === 'running';
  const measurable = launch.phase === 'preparing-libraries' && launch.progress !== undefined;

  return (
    <div className="overlay" role="dialog" aria-label="Launching Minecraft">
      <div className="panel">
        <EclipseMark size={120} />
        <ol className="stages">
          {STAGES.map((s, i) => {
            const state = failed ? (i < idx ? 'done' : i === idx ? 'failed' : 'pending') : i < idx || running ? 'done' : i === idx ? 'active' : 'pending';
            const done = state === 'done';
            return (
              <li key={s.phase} data-state={state}>
                <span className="ind">{done ? <Check size={15} /> : state === 'failed' ? <X size={15} /> : null}</span>
                <span>{s.label}</span>
                {s.phase === 'preparing-libraries' && state === 'active' && launch.detail && <span className="muted" style={{ marginLeft: 'auto', fontSize: 12, maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis' }}>{launch.detail}</span>}
              </li>
            );
          })}
        </ol>
        {!failed && !running && (
          <div className={measurable ? 'beam' : 'beam indet'} style={{ width: '100%' }}>
            <div style={measurable ? { width: `${Math.round((launch.progress ?? 0) * 100)}%` } : undefined} />
          </div>
        )}
        {measurable && <div className="muted">{Math.round((launch.progress ?? 0) * 100)}%</div>}
        {failed && <div className="error-box"><b>Minecraft could not start.</b><div className="muted">{launch.error}</div></div>}
        <div className="row" style={{ marginTop: 12 }}>
          {!failed && !running && <button className="btn" onClick={() => void api.launch.stop()}>Cancel</button>}
          {(failed || running) && <button className="btn primary" onClick={onDismiss}>{running ? 'Back to launcher' : 'Close'}</button>}
          {running && <button className="btn danger" onClick={() => void api.launch.stop()}>Stop game</button>}
        </div>
      </div>
    </div>
  );
}
