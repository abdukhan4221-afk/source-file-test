import { useCallback, useEffect, useState } from 'react';
import { Compass, Home as HomeIcon, Info, Layers, Server, Settings as SettingsIcon, Shirt, ShoppingBag } from 'lucide-react';
import type { EclipseBridge } from '@eclipse/shared-types';
import { getBridge } from './lib/bridge';
import { AppProvider, useActiveAccount, useApp } from './lib/state';
import { EclipseMark } from './components/Eclipse';
import { Startup, type Boot } from './components/Startup';
import { LaunchOverlay } from './components/LaunchOverlay';
import { Home } from './pages/Home';
import { Profiles } from './pages/Profiles';
import { Servers } from './pages/Servers';
import { Discover } from './pages/Discover';
import { Locker } from './pages/Locker';
import { Store } from './pages/Store';
import { Settings } from './pages/Settings';
import { About } from './pages/About';

export type PageId = 'home' | 'profiles' | 'servers' | 'discover' | 'locker' | 'store' | 'settings' | 'about';
const NAV: { id: PageId; label: string; icon: typeof HomeIcon }[] = [
  { id: 'home', label: 'Home', icon: HomeIcon }, { id: 'profiles', label: 'Profiles', icon: Layers }, { id: 'servers', label: 'Servers', icon: Server },
  { id: 'discover', label: 'Discover', icon: Compass }, { id: 'locker', label: 'Locker', icon: Shirt }, { id: 'store', label: 'Store', icon: ShoppingBag },
  { id: 'settings', label: 'Settings', icon: SettingsIcon }, { id: 'about', label: 'About', icon: Info },
];

function Shell() {
  const { launch, toasts } = useApp();
  const account = useActiveAccount();
  const [page, setPage] = useState<PageId>('home');
  const [overlay, setOverlay] = useState(false);

  useEffect(() => {
    if (launch.phase === 'running' && overlay) {
      const t = setTimeout(() => setOverlay(false), 2500); // game is up; hand the screen back
      return () => clearTimeout(t);
    }
  }, [launch.phase, overlay]);
  useEffect(() => { if (launch.phase === 'failed') setOverlay(true); }, [launch.phase]);

  const showOverlay = overlay && launch.phase !== 'idle' && launch.phase !== 'stopped';

  return (
    <div className="app">
      <nav className="rail" aria-label="Main">
        <div className="brand"><EclipseMark size={44} /></div>
        {NAV.slice(0, 6).map(({ id, label, icon: Icon }) => (
          <button key={id} className="nav-btn" aria-current={page === id ? 'page' : undefined} onClick={() => setPage(id)}><Icon size={22} strokeWidth={1.6} /><span>{label}</span></button>
        ))}
        <div className="spacer" />
        {NAV.slice(6).map(({ id, label, icon: Icon }) => (
          <button key={id} className="nav-btn" aria-current={page === id ? 'page' : undefined} onClick={() => setPage(id)}><Icon size={22} strokeWidth={1.6} /><span>{label}</span></button>
        ))}
      </nav>
      <main className="stage">
        {account && (
          <button className="account-chip" onClick={() => setPage('settings')} aria-label="Accounts">
            <span className="avatar">{account.username[0]?.toUpperCase()}</span>
            <span>{account.username}</span>
            <span className={`badge ${account.kind === 'microsoft' ? 'ok' : ''}`}>{account.kind === 'microsoft' ? 'Microsoft' : 'Local'}</span>
          </button>
        )}
        {page === 'home' && <Home onLaunch={() => setOverlay(true)} goto={setPage} />}
        {page === 'profiles' && <Profiles />}
        {page === 'servers' && <Servers />}
        {page === 'discover' && <Discover />}
        {page === 'locker' && <Locker />}
        {page === 'store' && <Store />}
        {page === 'settings' && <Settings />}
        {page === 'about' && <About />}
      </main>
      {showOverlay && <LaunchOverlay onDismiss={() => setOverlay(false)} />}
      <div className="toasts" aria-live="polite">{toasts.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.text}</div>)}</div>
    </div>
  );
}

export function Root() {
  const [api, setApi] = useState<EclipseBridge | null>(null);
  const [boot, setBoot] = useState<Boot | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [attempt, setAttempt] = useState(0);

  useEffect(() => { setError(null); getBridge().then(setApi, setError); }, [attempt]);
  const onReady = useCallback((b: Boot) => setBoot(b), []);
  const onError = useCallback((e: Error) => setError(e), []);

  if (error) {
    return (
      <div className="startup" role="alert">
        <div style={{ textAlign: 'center', maxWidth: 460 }}>
          <EclipseMark size={96} flare={false} />
          <h2 style={{ margin: '18px 0 8px' }}>Eclipse could not start</h2>
          <p className="muted">{error.message}</p>
          <button className="btn primary" onClick={() => { setBoot(null); setAttempt((n) => n + 1); }}>Try again</button>
        </div>
      </div>
    );
  }
  if (!api) return <div className="startup" />;
  if (!boot) return <Startup key={attempt} api={api} onReady={onReady} onError={onError} />;
  return <AppProvider api={api} initial={boot}><Shell /></AppProvider>;
}
