import React from 'react';
import { createRoot } from 'react-dom/client';
import './styles.css';
import { Root } from './App';

createRoot(document.getElementById('root')!).render(<React.StrictMode><Root /></React.StrictMode>);
