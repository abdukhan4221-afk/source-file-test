import type { EclipseBridge } from '@eclipse/shared-types';

let cached: EclipseBridge | null = null;

/** The real bridge comes from the Electron preload. The mock exists only in QA builds (VITE_MOCK=1). */
export async function getBridge(): Promise<EclipseBridge> {
  if (cached) return cached;
  if (window.eclipse) return (cached = window.eclipse);
  if (import.meta.env.VITE_MOCK) {
    const { createMockBridge } = await import('./mock');
    return (cached = createMockBridge());
  }
  throw new Error('The Eclipse bridge is unavailable. Open this app through Eclipse Client, not a browser.');
}
