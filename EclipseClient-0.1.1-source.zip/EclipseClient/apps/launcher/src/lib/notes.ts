// Shown on Home as release notes. There is no remote news service, so nothing here pretends to be live news.
export const RELEASE_NOTES = [
  { version: '0.1.0', text: 'Profiles, version manager, Java detection, Modrinth installs, server status and local accounts are available.' },
  { version: '0.1.0', text: 'Microsoft sign-in is built in and turns on once you add an application ID in Settings.' },
];
