// QA-only bridge used to render the UI in a plain browser for visual testing. Not included in production builds.
import { DEFAULT_SETTINGS, type EclipseBridge, type LaunchState, type Profile, type Settings } from '@eclipse/shared-types';

export function createMockBridge(): EclipseBridge {
  const now = Date.now();
  let profiles: Profile[] = [
    { id: 'p1', name: 'Survival 1.21', minecraftVersion: '1.21.1', loader: 'vanilla', createdAt: now, lastPlayedAt: now - 3600_000 * 5, playtimeMs: 3600_000 * 42.5, pinned: true, order: 0, gameDir: '/instances/p1' },
    { id: 'p2', name: 'PvP 1.8.9', minecraftVersion: '1.8.9', loader: 'vanilla', createdAt: now, playtimeMs: 3600_000 * 9, pinned: false, order: 1, gameDir: '/instances/p2' },
    { id: 'p3', name: 'Create Modpack', minecraftVersion: '1.20.1', loader: 'fabric', createdAt: now, lastPlayedAt: now - 86400_000 * 3, playtimeMs: 3600_000 * 120, pinned: false, order: 2, gameDir: '/instances/p3' },
  ];
  let selectedId: string | null = 'p1';
  let settings: Settings = { ...DEFAULT_SETTINGS };
  let launch: LaunchState = { phase: 'idle' };
  const launchListeners = new Set<(s: LaunchState) => void>();
  const setLaunch = (s: LaunchState) => { launch = s; launchListeners.forEach((l) => l(s)); };
  let accounts: any[] = [{ kind: 'local', id: 'a1', username: 'Steve_01', guest: false }];

  const versions = [
    ['1.21.1', 'release'], ['1.21', 'release'], ['1.20.6', 'release'], ['1.20.1', 'release'], ['1.8.9', 'release'], ['24w40a', 'snapshot'], ['b1.7.3', 'old_beta'], ['a1.2.6', 'old_alpha'],
  ].map(([id, type]) => ({ id: id as string, type: type as any, url: '', releaseTime: '2024-01-01' }));

  return {
    profiles: {
      state: async () => ({ profiles, selectedId, defaultId: 'p1' }),
      create: async (i) => { const p: Profile = { id: 'n' + profiles.length, name: i.name, minecraftVersion: i.minecraftVersion, loader: i.loader, createdAt: Date.now(), playtimeMs: 0, pinned: false, order: profiles.length, gameDir: '/instances/new' }; profiles = [...profiles, p]; return p; },
      clone: async (id) => { const s = profiles.find((p) => p.id === id)!; const p = { ...s, id: 'c' + profiles.length, name: s.name + ' copy' }; profiles = [...profiles, p]; return p; },
      rename: async (id, name) => { profiles = profiles.map((p) => (p.id === id ? { ...p, name } : p)); },
      remove: async (id) => { profiles = profiles.filter((p) => p.id !== id); },
      pin: async (id, pinned) => { profiles = profiles.map((p) => (p.id === id ? { ...p, pinned } : p)); },
      reorder: async () => {},
      select: async (id) => { selectedId = id; },
      setDefault: async () => {},
      openFolder: async () => {},
    },
    versions: {
      list: async () => ({ versions, fromCache: false, fetchedAt: Date.now() }),
      loaders: async (v) => [
        { loader: 'vanilla', installable: true },
        { loader: 'fabric', installable: false, reason: v === '1.8.9' ? 'fabric does not support 1.8.9.' : 'Supported upstream; the Eclipse installer for it is not implemented yet.' },
        { loader: 'forge', installable: false, reason: 'Supported upstream; the Eclipse installer for it is not implemented yet.' },
      ],
    },
    java: { detect: async () => [{ path: '/usr/lib/jvm/temurin-21/bin/java', major: 21, vendor: 'Temurin' }, { path: '/usr/lib/jvm/temurin-8/bin/java', major: 8, vendor: 'Temurin' }], required: async () => 21 },
    accounts: {
      state: async () => ({ accounts, selectedId: 'a1', defaultId: 'a1' }),
      addLocal: async (u, g) => { const a = { kind: 'local', id: 'a' + accounts.length, username: g ? 'Guest_9f3a' : u, guest: g }; accounts = [...accounts, a]; return a as any; },
      remove: async (id) => { accounts = accounts.filter((a) => a.id !== id); },
      select: async () => {}, setDefault: async () => {}, rename: async () => {},
      microsoftBegin: async () => ({ userCode: 'K7QD-M4XP', verificationUri: 'https://www.microsoft.com/link', expiresInSec: 900, intervalSec: 5 }),
      microsoftFinish: () => new Promise(() => {}),
    },
    launch: {
      start: async (id) => {
        const phases: LaunchState['phase'][] = ['preparing-profile', 'checking-install', 'preparing-libraries', 'resolving-loader', 'preparing-java', 'starting', 'running'];
        for (const [i, phase] of phases.entries()) {
          setLaunch({ phase, profileId: id, progress: phase === 'preparing-libraries' ? 0.62 : undefined, detail: phase === 'preparing-libraries' ? 'lwjgl-glfw-3.3.3.jar' : undefined });
          if (i < phases.length - 1) await new Promise((r) => setTimeout(r, 900));
        }
      },
      stop: async () => setLaunch({ phase: 'stopped' }),
      state: async () => launch,
      onState: (cb) => { launchListeners.add(cb); return () => void launchListeners.delete(cb); },
    },
    servers: {
      list: async () => [
        { id: 's1', name: 'Hypixel', address: 'mc.hypixel.net', description: 'Minigames network', favorite: true },
        { id: 's2', name: 'Friends SMP', address: 'play.friends.example:25570', favorite: false },
      ],
      save: async (e) => ({ id: 's9', ...e }) as any,
      remove: async () => {},
      ping: async (a) => (a.includes('hypixel') ? { online: true, latencyMs: 41, versionName: 'Requires MC 1.8 / 1.21', playersOnline: 31204, playersMax: 200000, motd: 'Hypixel Network' } : { online: false, error: 'getaddrinfo ENOTFOUND play.friends.example' }),
    },
    modrinth: {
      search: async (q) => [
        { projectId: 'AANobbMI', slug: 'sodium', title: 'Sodium', description: 'A modern rendering engine and optimization mod for Minecraft.', author: 'jellysquid3', downloads: 62_000_000, kind: q.kind },
        { projectId: 'gvQqBUqZ', slug: 'lithium', title: 'Lithium', description: 'Game logic optimization mod that improves server and client tick performance.', author: 'jellysquid3', downloads: 48_000_000, kind: q.kind },
        { projectId: 'P7dR8mSH', slug: 'fabric-api', title: 'Fabric API', description: 'Core API library for the Fabric toolchain.', author: 'modmuss50', downloads: 99_000_000, kind: q.kind },
      ],
      install: async () => {}, onProgress: () => () => {},
    },
    settings: { get: async () => settings, set: async (p) => (settings = { ...settings, ...p, background: { ...settings.background, ...(p.background ?? {}) }, widgets: { ...settings.widgets, ...(p.widgets ?? {}) }, minecraft: { ...settings.minecraft, ...(p.minecraft ?? {}) } }) },
    system: { openExternal: async () => {}, appVersion: async () => '0.1.0', exportDiagnostics: async () => '/tmp/diagnostics.txt' },
  };
}
