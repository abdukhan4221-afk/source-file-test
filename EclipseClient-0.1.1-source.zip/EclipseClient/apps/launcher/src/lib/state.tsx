import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { AccountsState, EclipseBridge, LaunchState, ProfilesState, Settings } from '@eclipse/shared-types';
import { DEFAULT_SETTINGS } from '@eclipse/shared-types';
import { getBridge } from './bridge';

export interface Toast { id: number; text: string; kind: 'info' | 'error' | 'success' }

interface AppCtx {
  api: EclipseBridge;
  profiles: ProfilesState;
  accounts: AccountsState;
  settings: Settings;
  launch: LaunchState;
  toasts: Toast[];
  refresh(): Promise<void>;
  saveSettings(p: Partial<Settings>): Promise<void>;
  notify(text: string, kind?: Toast['kind']): void;
  /** Runs an action, turning thrown errors into visible messages instead of silent failures. */
  run<T>(fn: () => Promise<T>, okMessage?: string): Promise<T | undefined>;
}

const Ctx = createContext<AppCtx | null>(null);

export function useApp(): AppCtx {
  const c = useContext(Ctx);
  if (!c) throw new Error('useApp outside provider');
  return c;
}

export function AppProvider({ api, initial, children }: { api: EclipseBridge; initial: { profiles: ProfilesState; accounts: AccountsState; settings: Settings }; children: ReactNode }) {
  const [profiles, setProfiles] = useState(initial.profiles);
  const [accounts, setAccounts] = useState(initial.accounts);
  const [settings, setSettings] = useState<Settings>(initial.settings ?? DEFAULT_SETTINGS);
  const [launch, setLaunch] = useState<LaunchState>({ phase: 'idle' });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const nextId = useRef(1);

  const refresh = useCallback(async () => {
    const [p, a] = await Promise.all([api.profiles.state(), api.accounts.state()]);
    setProfiles(p);
    setAccounts(a);
  }, [api]);

  const notify = useCallback((text: string, kind: Toast['kind'] = 'info') => {
    const id = nextId.current++;
    setToasts((t) => [...t, { id, text, kind }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), kind === 'error' ? 7000 : 3500);
  }, []);

  const run = useCallback(async <T,>(fn: () => Promise<T>, okMessage?: string) => {
    try {
      const r = await fn();
      if (okMessage) notify(okMessage, 'success');
      return r;
    } catch (e) {
      notify((e as Error).message.replace(/^Error invoking remote method '[^']+': (Error: )?/, ''), 'error');
      return undefined;
    }
  }, [notify]);

  const saveSettings = useCallback(async (patch: Partial<Settings>) => {
    const next = await run(() => api.settings.set(patch));
    if (next) setSettings(next);
  }, [api, run]);

  useEffect(() => {
    void api.launch.state().then(setLaunch);
    const off = api.launch.onState((s) => {
      setLaunch(s);
      if (s.phase === 'stopped' || s.phase === 'failed') void refresh(); // playtime + last played changed
    });
    return off;
  }, [api, refresh]);

  useEffect(() => {
    document.documentElement.style.setProperty('--accent', settings.accent);
    document.documentElement.dataset.reduced = settings.reducedMotion ? '1' : '0';
  }, [settings.accent, settings.reducedMotion]);

  const value = useMemo<AppCtx>(() => ({ api, profiles, accounts, settings, launch, toasts, refresh, saveSettings, notify, run }), [api, profiles, accounts, settings, launch, toasts, refresh, saveSettings, notify, run]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSelectedProfile() {
  const { profiles } = useApp();
  return profiles.profiles.find((p) => p.id === profiles.selectedId) ?? null;
}

export function useActiveAccount() {
  const { accounts } = useApp();
  return accounts.accounts.find((a) => a.id === (accounts.selectedId ?? accounts.defaultId)) ?? null;
}

export function formatDuration(ms: number): string {
  const h = ms / 3600_000;
  if (h >= 1) return `${h.toFixed(h >= 10 ? 0 : 1)} h`;
  return `${Math.max(0, Math.round(ms / 60_000))} min`;
}

export function formatAgo(ts?: number): string {
  if (!ts) return 'Never';
  const d = Date.now() - ts;
  if (d < 3600_000) return `${Math.max(1, Math.round(d / 60_000))} min ago`;
  if (d < 86400_000) return `${Math.round(d / 3600_000)} h ago`;
  return `${Math.round(d / 86400_000)} d ago`;
}
