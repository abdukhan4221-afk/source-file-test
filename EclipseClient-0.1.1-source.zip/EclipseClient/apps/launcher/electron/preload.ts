import { contextBridge, ipcRenderer } from 'electron';
import type { EclipseBridge, InstallProgress, LaunchState } from '@eclipse/shared-types';

// The renderer gets a fixed, typed set of calls. It never receives ipcRenderer or Node.
const call = (name: string, ...args: unknown[]) => ipcRenderer.invoke('eclipse:invoke', name, ...args);
const listen = <T>(channel: string, cb: (v: T) => void) => {
  const handler = (_: unknown, v: T) => cb(v);
  ipcRenderer.on(channel, handler);
  return () => void ipcRenderer.removeListener(channel, handler);
};

const bridge: EclipseBridge = {
  profiles: {
    state: () => call('profiles.state'),
    create: (i) => call('profiles.create', i),
    clone: (id) => call('profiles.clone', id),
    rename: (id, n) => call('profiles.rename', id, n),
    remove: (id) => call('profiles.remove', id),
    pin: (id, p) => call('profiles.pin', id, p),
    reorder: (ids) => call('profiles.reorder', ids),
    select: (id) => call('profiles.select', id),
    setDefault: (id) => call('profiles.setDefault', id),
    openFolder: (id, sub) => call('profiles.openFolder', id, sub),
  },
  versions: { list: (r) => call('versions.list', r), loaders: (v) => call('versions.loaders', v) },
  java: { detect: () => call('java.detect'), required: (v) => call('java.required', v) },
  accounts: {
    state: () => call('accounts.state'),
    addLocal: (u, g) => call('accounts.addLocal', u, g),
    remove: (id) => call('accounts.remove', id),
    select: (id) => call('accounts.select', id),
    setDefault: (id) => call('accounts.setDefault', id),
    rename: (id, u) => call('accounts.rename', id, u),
    microsoftBegin: () => call('accounts.microsoftBegin'),
    microsoftFinish: () => call('accounts.microsoftFinish'),
  },
  launch: {
    start: (id) => call('launch.start', id),
    stop: () => call('launch.stop'),
    state: () => call('launch.state'),
    onState: (cb) => listen<LaunchState>('eclipse:launch-state', cb),
  },
  servers: {
    list: () => call('servers.list'),
    save: (e) => call('servers.save', e),
    remove: (id) => call('servers.remove', id),
    ping: (a) => call('servers.ping', a),
  },
  modrinth: {
    search: (q) => call('modrinth.search', q),
    install: (pid, kind, profile) => call('modrinth.install', pid, kind, profile),
    onProgress: (cb) => listen<InstallProgress>('eclipse:install-progress', cb),
  },
  settings: { get: () => call('settings.get'), set: (p) => call('settings.set', p) },
  system: {
    openExternal: (u) => call('system.openExternal', u),
    appVersion: () => call('system.appVersion'),
    exportDiagnostics: () => call('system.exportDiagnostics'),
  },
};

contextBridge.exposeInMainWorld('eclipse', bridge);
