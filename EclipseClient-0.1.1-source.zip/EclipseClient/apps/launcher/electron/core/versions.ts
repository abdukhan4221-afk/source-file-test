import type { MinecraftVersion, VersionType } from '@eclipse/shared-types';
import { readJson, writeJsonAtomic } from './jsonStore';

export const MANIFEST_URL = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';

export type FetchLike = (url: string, init?: { signal?: AbortSignal; headers?: Record<string, string>; method?: string; body?: string }) => Promise<{
  ok: boolean;
  status: number;
  json(): Promise<any>;
  text(): Promise<string>;
  arrayBuffer(): Promise<ArrayBuffer>;
}>;

interface Cache {
  fetchedAt: number;
  versions: MinecraftVersion[];
}

export interface VersionListResult {
  versions: MinecraftVersion[];
  fromCache: boolean;
  fetchedAt: number;
}

/** Mojang manifest with an on-disk cache so the launcher works offline. */
export class VersionService {
  constructor(
    private readonly cacheFile: string,
    private readonly fetchFn: FetchLike,
    private readonly manifestUrl = MANIFEST_URL,
  ) {}

  async list(refresh = false): Promise<VersionListResult> {
    const cached = readJson<Cache | null>(this.cacheFile, null);
    const fresh = cached && Date.now() - cached.fetchedAt < 60 * 60 * 1000;
    if (cached && fresh && !refresh) return { ...cached, fromCache: true };
    try {
      const res = await this.fetchFn(this.manifestUrl);
      if (!res.ok) throw new Error(`Version manifest returned HTTP ${res.status}`);
      const body = await res.json();
      const versions: MinecraftVersion[] = (body.versions as any[]).map((v) => ({
        id: String(v.id),
        type: v.type as VersionType,
        url: String(v.url),
        releaseTime: String(v.releaseTime),
      }));
      const next: Cache = { fetchedAt: Date.now(), versions };
      writeJsonAtomic(this.cacheFile, next);
      return { ...next, fromCache: false };
    } catch (err) {
      if (cached) return { ...cached, fromCache: true };
      throw new Error(`Could not load the Minecraft version list and no offline copy exists. ${(err as Error).message}`);
    }
  }
}

export function filterVersions(
  versions: MinecraftVersion[],
  opts: { types?: VersionType[]; search?: string },
): MinecraftVersion[] {
  const q = opts.search?.trim().toLowerCase();
  return versions.filter((v) => (!opts.types || opts.types.includes(v.type)) && (!q || v.id.toLowerCase().includes(q)));
}
