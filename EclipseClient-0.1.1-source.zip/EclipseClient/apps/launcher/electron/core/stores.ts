import crypto from 'node:crypto';
import path from 'node:path';
import { DEFAULT_SETTINGS, type ServerEntry, type Settings } from '@eclipse/shared-types';
import { readJson, writeJsonAtomic } from './jsonStore';

function clamp(n: unknown, min: number, max: number, fallback: number): number {
  return typeof n === 'number' && Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}

/** Sanitizes a settings patch so a bad renderer message can never corrupt the file. */
export function sanitizeSettings(base: Settings, patch: Partial<Settings>): Settings {
  const merged: Settings = {
    ...base,
    ...patch,
    background: { ...base.background, ...(patch.background ?? {}) },
    widgets: { ...base.widgets, ...(patch.widgets ?? {}) },
    minecraft: { ...base.minecraft, ...(patch.minecraft ?? {}) },
    telemetry: false,
  };
  merged.background.blur = clamp(merged.background.blur, 0, 40, 0);
  merged.background.dim = clamp(merged.background.dim, 0, 0.9, 0.1);
  merged.minecraft.memoryMb = clamp(merged.minecraft.memoryMb, 512, 65536, 4096);
  merged.minecraft.width = clamp(merged.minecraft.width, 320, 7680, 1280);
  merged.minecraft.height = clamp(merged.minecraft.height, 240, 4320, 720);
  if (!/^#[0-9a-fA-F]{6}$/.test(merged.accent)) merged.accent = DEFAULT_SETTINGS.accent;
  merged.msClientId = String(merged.msClientId ?? '').trim();
  return merged;
}

export class SettingsStore {
  private file: string;
  private value: Settings;
  constructor(root: string) {
    this.file = path.join(root, 'settings.json');
    this.value = sanitizeSettings(DEFAULT_SETTINGS, readJson<Partial<Settings>>(this.file, {}));
  }
  get(): Settings { return this.value; }
  set(patch: Partial<Settings>): Settings {
    this.value = sanitizeSettings(this.value, patch);
    writeJsonAtomic(this.file, this.value);
    return this.value;
  }
}

export class ServerStore {
  private file: string;
  private items: ServerEntry[];
  constructor(root: string) {
    this.file = path.join(root, 'servers.json');
    this.items = readJson<ServerEntry[]>(this.file, []);
  }
  list(): ServerEntry[] {
    return [...this.items].sort((a, b) => Number(b.favorite) - Number(a.favorite));
  }
  save(entry: Omit<ServerEntry, 'id'> & { id?: string }): ServerEntry {
    const name = entry.name.trim();
    const address = entry.address.trim();
    if (!name || !address) throw new Error('A server needs a name and an address.');
    if (/\s/.test(address)) throw new Error('Server addresses cannot contain spaces.');
    const existing = entry.id ? this.items.find((s) => s.id === entry.id) : undefined;
    const record: ServerEntry = { id: existing?.id ?? crypto.randomUUID().slice(0, 8), name, address, description: entry.description?.trim() || undefined, favorite: !!entry.favorite };
    if (existing) Object.assign(existing, record);
    else this.items.push(record);
    writeJsonAtomic(this.file, this.items);
    return record;
  }
  remove(id: string): void {
    this.items = this.items.filter((s) => s.id !== id);
    writeJsonAtomic(this.file, this.items);
  }
}
