import { spawn as nodeSpawn, type ChildProcess } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { LaunchController, type LaunchSteps } from './launcher';
import type { ProfileService } from './profiles';
import { AccountService, offlineUuid } from './accounts';
import type { SettingsStore } from './stores';
import { VersionService, type FetchLike } from './versions';
import { buildCommand, currentEnv, mergeVersions, type VersionJson } from './launchPlan';
import { installVersion, type InstallResult } from './installer';
import { chooseJava, detectJava, probeJava, type JavaInstall } from './java';
import { requiredJava } from './compat';
import { MicrosoftAuth } from './msAuth';

export interface LaunchDeps {
  root: string;
  profiles: ProfileService;
  accounts: AccountService;
  settings: SettingsStore;
  versions: VersionService;
  fetchFn: FetchLike;
  launcherVersion: string;
  spawn?: typeof nodeSpawn;
}

export class LaunchService {
  readonly controller = new LaunchController();
  constructor(private readonly d: LaunchDeps) {}

  private versionsDir() { return path.join(this.d.root, 'versions'); }

  private async loadVersionJson(id: string): Promise<VersionJson> {
    const cache = path.join(this.versionsDir(), id, `${id}.json`);
    try {
      const { versions } = await this.d.versions.list();
      const entry = versions.find((v) => v.id === id);
      if (!entry) throw new Error(`Minecraft ${id} is not in the official version list.`);
      const res = await this.d.fetchFn(entry.url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = (await res.json()) as VersionJson;
      fs.mkdirSync(path.dirname(cache), { recursive: true });
      fs.writeFileSync(cache, JSON.stringify(json));
      return json;
    } catch (e) {
      if (fs.existsSync(cache)) return JSON.parse(fs.readFileSync(cache, 'utf8')) as VersionJson; // offline
      throw new Error(`Could not get the Minecraft ${id} files and no local copy exists. ${(e as Error).message}`);
    }
  }

  async start(profileId: string): Promise<void> {
    const d = this.d;
    const env = currentEnv();
    let vjson!: VersionJson;
    let install!: InstallResult;
    let java!: JavaInstall;
    let playerName = '';
    let uuid = '';
    let token = '0';
    let userType: 'msa' | 'legacy' = 'legacy';
    const profile = d.profiles.get(profileId);
    const logFile = path.join(d.root, 'logs', `minecraft-${profile.id}.log`);

    const steps: LaunchSteps = {
      prepareProfile: async () => {
        const acc = d.accounts.selected();
        if (!acc) throw new Error('Add an account before playing. Open Settings > Accounts.');
        playerName = acc.username;
        if (acc.kind === 'local') {
          uuid = offlineUuid(acc.username);
        } else {
          const tokens = d.accounts.tokensFor(acc.id);
          if (!tokens) throw new Error('This Microsoft account has no saved session. Sign in again.');
          let mcToken = tokens.minecraftToken;
          if (new Date(acc.expiresAt).getTime() - Date.now() < 5 * 60_000) {
            const auth = new MicrosoftAuth(d.settings.get().msClientId, d.fetchFn);
            const s = await auth.refresh(tokens.refreshToken);
            d.accounts.upsertMicrosoft({ username: s.username, uuid: s.uuid, skinUrl: s.skinUrl, expiresAt: s.expiresAt }, { refreshToken: s.refreshToken, minecraftToken: s.minecraftToken });
            mcToken = s.minecraftToken;
          }
          token = mcToken;
          uuid = acc.uuid;
          userType = 'msa';
        }
      },
      checkInstall: async () => {
        if (profile.loader !== 'vanilla') {
          throw new Error(`The ${profile.loader} installer is not implemented yet. Switch this profile to Vanilla to play.`);
        }
        vjson = await this.loadVersionJson(profile.minecraftVersion);
        if (vjson.inheritsFrom) vjson = mergeVersions(vjson, await this.loadVersionJson(vjson.inheritsFrom));
      },
      prepareLibraries: async (report, signal) => {
        install = await installVersion(
          vjson,
          { versions: this.versionsDir(), libraries: path.join(d.root, 'libraries'), assets: path.join(d.root, 'assets') },
          env,
          d.fetchFn,
          (p) => report(p.done / p.total, p.label),
          signal,
        );
      },
      resolveLoader: async () => { /* vanilla needs no loader work */ },
      prepareJava: async () => {
        const s = d.settings.get();
        const need = requiredJava(profile.minecraftVersion, vjson.javaVersion?.majorVersion);
        const override = profile.javaPath || s.minecraft.javaPath;
        if (override) {
          const probed = await probeJava(override);
          if (!probed) throw new Error(`The Java path you set does not run: ${override}`);
          java = probed;
          return;
        }
        const found = chooseJava(await detectJava(), need);
        if (!found) throw new Error(`Minecraft ${profile.minecraftVersion} needs Java ${need}. Install it, or choose a Java in Settings > Minecraft.`);
        java = found;
      },
      spawn: (): ChildProcess => {
        const s = d.settings.get();
        const { args } = buildCommand(vjson, {
          versionName: vjson.id, gameDir: profile.gameDir, assetsDir: path.join(d.root, 'assets'), assetsIndexName: install.assetsIndexName,
          nativesDir: install.nativesDir, classpath: install.classpath, playerName, uuid, accessToken: token, userType,
          width: s.minecraft.width, height: s.minecraft.height, fullscreen: s.minecraft.fullscreen,
          memoryMb: profile.memoryMb ?? s.minecraft.memoryMb, extraJvmArgs: [s.minecraft.jvmArgs, profile.jvmArgs ?? ''].join(' '),
          launcherVersion: d.launcherVersion,
        }, env);
        fs.mkdirSync(path.dirname(logFile), { recursive: true });
        const log = fs.createWriteStream(logFile, { flags: 'a' });
        const child = (d.spawn ?? nodeSpawn)(java.path, args, { cwd: profile.gameDir, stdio: ['ignore', 'pipe', 'pipe'] });
        child.stdout?.pipe(log, { end: false });
        child.stderr?.pipe(log, { end: false });
        child.once('exit', () => log.end());
        return child;
      },
      onSessionEnd: (ms) => d.profiles.recordPlay(profileId, ms),
    };
    await this.controller.start(profileId, steps);
  }
}
