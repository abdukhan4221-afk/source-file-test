import type { ChildProcess } from 'node:child_process';
import type { LaunchPhase, LaunchState } from '@eclipse/shared-types';

export interface LaunchSteps {
  prepareProfile(): Promise<void>;
  checkInstall(): Promise<void>;
  /** Report real progress 0..1 while libraries and assets download. */
  prepareLibraries(report: (fraction: number, detail: string) => void, signal: AbortSignal): Promise<void>;
  resolveLoader(): Promise<void>;
  prepareJava(): Promise<void>;
  spawn(): ChildProcess;
  onSessionEnd(sessionMs: number, exitCode: number | null): void;
}

/**
 * Tracks one real Minecraft process. Phases advance only when the corresponding work has actually finished,
 * and `running` is only reported after the OS confirms the process spawned.
 */
export class LaunchController {
  private state: LaunchState = { phase: 'idle' };
  private child: ChildProcess | null = null;
  private abort: AbortController | null = null;
  private listeners = new Set<(s: LaunchState) => void>();

  getState(): LaunchState {
    return this.state;
  }

  onState(cb: (s: LaunchState) => void): () => void {
    this.listeners.add(cb);
    return () => this.listeners.delete(cb);
  }

  private set(phase: LaunchPhase, extra: Partial<LaunchState> = {}): void {
    this.state = { phase, profileId: this.state.profileId, ...extra };
    for (const l of this.listeners) l(this.state);
  }

  isBusy(): boolean {
    return !['idle', 'stopped', 'failed'].includes(this.state.phase);
  }

  async start(profileId: string, steps: LaunchSteps): Promise<void> {
    if (this.isBusy()) throw new Error('Minecraft is already starting or running.');
    this.state = { phase: 'idle', profileId };
    this.abort = new AbortController();
    try {
      this.set('preparing-profile');
      await steps.prepareProfile();
      this.set('checking-install');
      await steps.checkInstall();
      this.set('preparing-libraries', { progress: undefined, detail: 'Checking files' });
      await steps.prepareLibraries((f, d) => this.set('preparing-libraries', { progress: f, detail: d }), this.abort.signal);
      this.set('resolving-loader');
      await steps.resolveLoader();
      this.set('preparing-java');
      await steps.prepareJava();
      this.set('starting');
      const child = steps.spawn();
      this.child = child;
      const startedAt = Date.now();
      await new Promise<void>((resolve, reject) => {
        child.once('spawn', () => {
          this.set('running', { pid: child.pid });
          resolve();
        });
        child.once('error', reject);
      });
      child.once('exit', (code, signal) => {
        this.child = null;
        steps.onSessionEnd(Date.now() - startedAt, code);
        if (code === 0 || signal === 'SIGTERM') this.set('stopped');
        else this.set('failed', { failedPhase: 'running', error: `Minecraft exited with code ${code ?? signal}. Check the game log.` });
      });
    } catch (e) {
      this.child = null;
      const failedPhase = this.state.phase; // each step sets its phase before it runs, so this is the stage that threw
      this.set('failed', { error: (e as Error).message, failedPhase });
    }
  }

  stop(): void {
    this.abort?.abort();
    this.child?.kill('SIGTERM');
    if (!this.child && this.isBusy()) this.set('stopped');
  }
}
