import path from 'node:path';

export class UnsafePathError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'UnsafePathError';
  }
}

/** Resolve `parts` under `root`, throwing if the result would escape it. */
export function resolveInside(root: string, ...parts: string[]): string {
  const base = path.resolve(root);
  const target = path.resolve(base, ...parts);
  const rel = path.relative(base, target);
  if (rel === '') return target;
  if (rel === '..' || rel.startsWith('..' + path.sep) || path.isAbsolute(rel)) {
    throw new UnsafePathError(`Path escapes ${base}: ${parts.join('/')}`);
  }
  return target;
}

/** Validate an archive entry or manifest path before it is joined to a directory. */
export function isSafeRelativePath(p: string): boolean {
  if (!p || p.includes('\0')) return false;
  if (p.startsWith('/') || p.startsWith('\\') || /^[A-Za-z]:/.test(p)) return false;
  return !p.split(/[\\/]+/).some((seg) => seg === '..');
}

/** A bare file name: no separators, no traversal. */
export function isSafeFileName(name: string): boolean {
  return !!name && name === path.basename(name) && !/[\\/\0]/.test(name) && name !== '.' && name !== '..';
}

export function slugify(name: string): string {
  const s = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return s || 'profile';
}
