import path from 'node:path';

export type OsName = 'windows' | 'osx' | 'linux';
export interface Env { os: OsName; arch: string; features: Record<string, boolean> }

export interface Rule {
  action: 'allow' | 'disallow';
  os?: { name?: string; arch?: string; version?: string };
  features?: Record<string, boolean>;
}

export interface Artifact { path: string; url: string; sha1: string; size: number }
export interface Library {
  name: string;
  rules?: Rule[];
  natives?: Record<string, string>;
  downloads?: { artifact?: Artifact; classifiers?: Record<string, Artifact> };
}

export type ArgValue = string | { rules?: Rule[]; value: string | string[] };

export interface VersionJson {
  id: string;
  type?: string;
  mainClass: string;
  inheritsFrom?: string;
  minecraftArguments?: string;
  arguments?: { game?: ArgValue[]; jvm?: ArgValue[] };
  libraries: Library[];
  assetIndex?: { id: string; url: string; sha1: string; size?: number };
  assets?: string;
  downloads?: { client?: { url: string; sha1: string; size: number } };
  javaVersion?: { majorVersion: number };
}

export function currentEnv(): Env {
  const os: OsName = process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux';
  return { os, arch: process.arch === 'ia32' ? 'x86' : process.arch, features: {} };
}

/** Mojang rule semantics: no rules = allow; otherwise the last matching rule decides; no match = disallow. */
export function evalRules(rules: Rule[] | undefined, env: Env): boolean {
  if (!rules || rules.length === 0) return true;
  let allowed = false;
  for (const r of rules) {
    const osOk = !r.os || ((!r.os.name || r.os.name === env.os) && (!r.os.arch || r.os.arch === env.arch));
    const featOk = !r.features || Object.entries(r.features).every(([k, v]) => (env.features[k] ?? false) === v);
    if (osOk && featOk) allowed = r.action === 'allow';
  }
  return allowed;
}

/** Merge a loader/child profile onto its parent (inheritsFrom). Child libraries come first so they win on the classpath. */
export function mergeVersions(child: VersionJson, parent: VersionJson): VersionJson {
  return {
    ...parent,
    ...child,
    libraries: [...child.libraries, ...parent.libraries],
    arguments: {
      game: [...(parent.arguments?.game ?? []), ...(child.arguments?.game ?? [])],
      jvm: [...(parent.arguments?.jvm ?? []), ...(child.arguments?.jvm ?? [])],
    },
    assetIndex: child.assetIndex ?? parent.assetIndex,
    downloads: child.downloads ?? parent.downloads,
    javaVersion: child.javaVersion ?? parent.javaVersion,
    inheritsFrom: undefined,
  };
}

export interface LibraryFile { artifact: Artifact; native: boolean; abs: string }

export function resolveLibraries(v: VersionJson, librariesDir: string, env: Env): LibraryFile[] {
  const out: LibraryFile[] = [];
  const seen = new Set<string>();
  for (const lib of v.libraries) {
    if (!evalRules(lib.rules, env)) continue;
    const art = lib.downloads?.artifact;
    if (art && !seen.has(art.path)) {
      seen.add(art.path);
      out.push({ artifact: art, native: false, abs: path.join(librariesDir, art.path) });
    }
    const classifier = lib.natives?.[env.os]?.replace('${arch}', env.arch === 'x64' ? '64' : '32');
    const nat = classifier ? lib.downloads?.classifiers?.[classifier] : undefined;
    if (nat && !seen.has(nat.path)) {
      seen.add(nat.path);
      out.push({ artifact: nat, native: true, abs: path.join(librariesDir, nat.path) });
    }
  }
  return out;
}

export function splitArgs(s: string): string[] {
  // Shell-like tokenizer: whitespace separates tokens, quotes group text and may appear mid-token (-Dfoo="a b").
  const out: string[] = [];
  let cur = '';
  let quote: '"' | "'" | null = null;
  let has = false;
  for (const ch of s) {
    if (quote) {
      if (ch === quote) quote = null;
      else cur += ch;
    } else if (ch === '"' || ch === "'") {
      quote = ch;
      has = true;
    } else if (/\s/.test(ch)) {
      if (has || cur) out.push(cur);
      cur = '';
      has = false;
    } else {
      cur += ch;
      has = true;
    }
  }
  if (has || cur) out.push(cur);
  return out;
}

function expand(list: ArgValue[] | undefined, env: Env): string[] {
  const out: string[] = [];
  for (const a of list ?? []) {
    if (typeof a === 'string') out.push(a);
    else if (evalRules(a.rules, env)) out.push(...(Array.isArray(a.value) ? a.value : [a.value]));
  }
  return out;
}

export interface LaunchContext {
  versionName: string;
  gameDir: string;
  assetsDir: string;
  assetsIndexName: string;
  nativesDir: string;
  classpath: string[];
  playerName: string;
  uuid: string;
  accessToken: string;
  userType: 'msa' | 'legacy';
  width: number;
  height: number;
  fullscreen: boolean;
  memoryMb: number;
  extraJvmArgs: string;
  launcherVersion: string;
}

export function buildCommand(v: VersionJson, ctx: LaunchContext, env: Env): { args: string[] } {
  const vars: Record<string, string> = {
    auth_player_name: ctx.playerName,
    version_name: ctx.versionName,
    game_directory: ctx.gameDir,
    assets_root: ctx.assetsDir,
    assets_index_name: ctx.assetsIndexName,
    auth_uuid: ctx.uuid,
    auth_access_token: ctx.accessToken,
    user_type: ctx.userType,
    version_type: v.type ?? 'release',
    natives_directory: ctx.nativesDir,
    launcher_name: 'EclipseClient',
    launcher_version: ctx.launcherVersion,
    classpath: ctx.classpath.join(path.delimiter),
    resolution_width: String(ctx.width),
    resolution_height: String(ctx.height),
    clientid: '',
    auth_xuid: '',
    user_properties: '{}',
    game_assets: ctx.assetsDir,
  };
  const sub = (s: string) => s.replace(/\$\{(\w+)\}/g, (_, k: string) => vars[k] ?? '');
  const featureEnv: Env = { ...env, features: { ...env.features, has_custom_resolution: true } };

  const memory = [`-Xmx${ctx.memoryMb}M`, `-Xms${Math.min(512, ctx.memoryMb)}M`];
  let jvm = expand(v.arguments?.jvm, featureEnv).map(sub);
  if (!v.arguments?.jvm) jvm = [`-Djava.library.path=${ctx.nativesDir}`, '-cp', vars.classpath as string];
  let game = v.arguments?.game ? expand(v.arguments.game, featureEnv).map(sub) : splitArgs(v.minecraftArguments ?? '').map(sub);
  if (ctx.fullscreen) game.push('--fullscreen');
  game = game.filter((x) => x !== '');
  return { args: [...memory, ...splitArgs(ctx.extraJvmArgs), ...jvm, v.mainClass, ...game] };
}
