import type { LoaderId, LoaderSupport } from '@eclipse/shared-types';

/** "1.21.1" -> [1, 21, 1]. Returns null for snapshots, betas and alphas. */
export function parseRelease(id: string): [number, number, number] | null {
  const m = /^1\.(\d+)(?:\.(\d+))?$/.exec(id);
  if (!m) return null;
  return [1, Number(m[1]), Number(m[2] ?? 0)];
}

function cmp(a: [number, number, number], b: [number, number, number]): number {
  for (let i = 0; i < 3; i++) {
    const d = (a[i] as number) - (b[i] as number);
    if (d !== 0) return d;
  }
  return 0;
}

/** Java major version Mojang requires. Prefer the version JSON's own `javaVersion` when it is available. */
export function requiredJava(mcVersion: string, jsonMajor?: number): number {
  if (jsonMajor) return jsonMajor;
  const r = parseRelease(mcVersion);
  if (!r) return mcVersion.startsWith('b') || mcVersion.startsWith('a') || mcVersion.startsWith('c') || mcVersion.startsWith('inf') || mcVersion.startsWith('rd') ? 8 : 21;
  if (cmp(r, [1, 17, 0]) < 0) return 8;
  if (cmp(r, [1, 18, 0]) < 0) return 16;
  if (cmp(r, [1, 20, 5]) < 0) return 17;
  return 21;
}

interface LoaderRule {
  loader: LoaderId;
  /** Documented upstream range for release versions. */
  from?: [number, number, number];
  to?: [number, number, number];
  /** Does the launcher currently ship an installer for it? */
  implemented: boolean;
  note?: string;
}

// Ranges reflect what each loader project documents. `implemented` reflects THIS launcher.
const RULES: LoaderRule[] = [
  { loader: 'vanilla', implemented: true },
  { loader: 'fabric', from: [1, 14, 0], implemented: false },
  { loader: 'quilt', from: [1, 14, 0], implemented: false },
  { loader: 'forge', from: [1, 1, 0], implemented: false },
  { loader: 'neoforge', from: [1, 20, 1], implemented: false },
  { loader: 'legacy-fabric', from: [1, 3, 0], to: [1, 13, 2], implemented: false },
  { loader: 'liteloader', from: [1, 5, 2], to: [1, 12, 2], implemented: false },
  { loader: 'rift', from: [1, 13, 2], to: [1, 13, 2], implemented: false },
  { loader: 'ornithe', to: [1, 13, 2], implemented: false, note: 'Ornithe also covers pre-1.0 versions' },
  { loader: 'babric', implemented: false, note: 'Babric targets Beta 1.7.3 only' },
];

export function loadersFor(mcVersion: string): LoaderSupport[] {
  const r = parseRelease(mcVersion);
  return RULES.map((rule): LoaderSupport => {
    if (rule.loader === 'vanilla') return { loader: 'vanilla', installable: true };
    if (rule.loader === 'babric') {
      return mcVersion === 'b1.7.3'
        ? { loader: 'babric', installable: false, reason: 'Installer not implemented yet.' }
        : { loader: 'babric', installable: false, reason: 'Babric supports Beta 1.7.3 only.' };
    }
    if (!r) return { loader: rule.loader, installable: false, reason: 'Loaders are only offered on release versions here.' };
    if ((rule.from && cmp(r, rule.from) < 0) || (rule.to && cmp(r, rule.to) > 0)) {
      return { loader: rule.loader, installable: false, reason: `${rule.loader} does not support ${mcVersion}.` };
    }
    return {
      loader: rule.loader,
      installable: rule.implemented,
      reason: rule.implemented ? undefined : 'Supported upstream; the Eclipse installer for it is not implemented yet.',
    };
  });
}

/** The Eclipse in-game client only exists for versions with a compiled implementation. */
export const ECLIPSE_CLIENT_TARGETS: { mc: string; loader: LoaderId; java: number; status: 'source-complete-unbuilt' | 'skeleton' }[] = [
  { mc: '1.21.1', loader: 'fabric', java: 21, status: 'source-complete-unbuilt' },
  { mc: '1.8.9', loader: 'forge', java: 8, status: 'skeleton' },
];

export function eclipseClientAvailable(mc: string, loader: LoaderId): boolean {
  // Nothing is "available" until a build has been produced and verified; see docs/COMPATIBILITY.md.
  void mc; void loader;
  return false;
}
