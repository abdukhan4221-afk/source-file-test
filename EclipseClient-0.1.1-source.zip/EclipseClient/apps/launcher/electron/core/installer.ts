import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { unzipSync } from 'fflate';
import type { FetchLike } from './versions';
import { type Env, type VersionJson, resolveLibraries } from './launchPlan';
import { resolveInside } from './fsSafe';

export interface Progress { done: number; total: number; label: string }

export class DownloadError extends Error {}

export function sha(algo: 'sha1' | 'sha512', data: Uint8Array): string {
  return crypto.createHash(algo).update(data).digest('hex');
}

/** Download one file, verify its hash, then move it into place. Skips files that already verify. */
export async function downloadVerified(
  fetchFn: FetchLike,
  url: string,
  dest: string,
  expect: { algo: 'sha1' | 'sha512'; hash: string } | null,
  signal?: AbortSignal,
): Promise<'cached' | 'downloaded'> {
  if (expect && fs.existsSync(dest) && sha(expect.algo, fs.readFileSync(dest)) === expect.hash.toLowerCase()) return 'cached';
  if (!/^https?:\/\//.test(url)) throw new DownloadError(`Refusing non-HTTP URL: ${url}`);
  const res = await fetchFn(url, { signal });
  if (!res.ok) throw new DownloadError(`Download failed (${res.status}): ${url}`);
  const data = new Uint8Array(await res.arrayBuffer());
  if (expect && sha(expect.algo, data) !== expect.hash.toLowerCase()) {
    throw new DownloadError(`Checksum mismatch for ${path.basename(dest)}. The file was not saved.`);
  }
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const tmp = `${dest}.part`;
  fs.writeFileSync(tmp, data);
  fs.renameSync(tmp, dest);
  return 'downloaded';
}

async function pool<T>(items: T[], limit: number, worker: (item: T) => Promise<void>, signal?: AbortSignal): Promise<void> {
  let i = 0;
  const run = async () => {
    while (i < items.length) {
      if (signal?.aborted) throw new DownloadError('Cancelled.');
      await worker(items[i++] as T);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
}

export interface InstallDirs { versions: string; libraries: string; assets: string }

export interface InstallResult { classpath: string[]; nativesDir: string; assetsIndexName: string }

/** Downloads client jar, libraries and assets with hash verification and real progress counts. */
export async function installVersion(
  v: VersionJson,
  dirs: InstallDirs,
  env: Env,
  fetchFn: FetchLike,
  onProgress: (p: Progress) => void,
  signal?: AbortSignal,
  assetBase = 'https://resources.download.minecraft.net',
): Promise<InstallResult> {
  const libs = resolveLibraries(v, dirs.libraries, env);
  const client = v.downloads?.client;
  if (!client) throw new DownloadError(`Version ${v.id} has no client download.`);

  // The asset index must be fetched first because its object count decides the total.
  const idx = v.assetIndex;
  let assetObjects: [string, { hash: string; size: number }][] = [];
  if (idx) {
    const indexPath = path.join(dirs.assets, 'indexes', `${idx.id}.json`);
    await downloadVerified(fetchFn, idx.url, indexPath, { algo: 'sha1', hash: idx.sha1 }, signal);
    assetObjects = Object.entries(JSON.parse(fs.readFileSync(indexPath, 'utf8')).objects as Record<string, { hash: string; size: number }>);
  }

  const total = 1 + libs.length + assetObjects.length;
  let done = 0;
  const tick = (label: string) => onProgress({ done: ++done, total, label });

  const clientJar = path.join(dirs.versions, v.id, `${v.id}.jar`);
  await downloadVerified(fetchFn, client.url, clientJar, { algo: 'sha1', hash: client.sha1 }, signal);
  tick('Minecraft client');

  await pool(libs, 8, async (l) => {
    await downloadVerified(fetchFn, l.artifact.url, l.abs, { algo: 'sha1', hash: l.artifact.sha1 }, signal);
    tick(path.basename(l.abs));
  }, signal);

  await pool(assetObjects, 16, async ([name, obj]) => {
    const dest = resolveInside(path.join(dirs.assets, 'objects'), obj.hash.slice(0, 2), obj.hash);
    await downloadVerified(fetchFn, `${assetBase}/${obj.hash.slice(0, 2)}/${obj.hash}`, dest, { algo: 'sha1', hash: obj.hash }, signal);
    tick(name);
  }, signal);

  const nativesDir = path.join(dirs.versions, v.id, 'natives');
  extractNatives(libs.filter((l) => l.native), nativesDir);

  return {
    classpath: [...libs.filter((l) => !l.native).map((l) => l.abs), clientJar],
    nativesDir,
    assetsIndexName: idx?.id ?? v.assets ?? 'legacy',
  };
}

/** Safe natives extraction: flat files only, no traversal, no META-INF. */
export function extractNatives(libs: { abs: string }[], dest: string): void {
  fs.mkdirSync(dest, { recursive: true });
  for (const l of libs) {
    const files = unzipSync(new Uint8Array(fs.readFileSync(l.abs)), { filter: (f) => !f.name.endsWith('/') && !f.name.startsWith('META-INF') });
    for (const [name, bytes] of Object.entries(files)) {
      const target = resolveInside(dest, path.basename(name));
      fs.writeFileSync(target, bytes);
    }
  }
}
