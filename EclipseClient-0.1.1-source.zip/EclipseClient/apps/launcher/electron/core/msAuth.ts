import type { DeviceCodeInfo } from '@eclipse/shared-types';
import type { FetchLike } from './versions';

const TENANT = 'https://login.microsoftonline.com/consumers/oauth2/v2.0';
const SCOPE = 'XboxLive.signin offline_access';

export class MicrosoftAuthError extends Error {
  constructor(message: string, readonly code?: string) {
    super(message);
    this.name = 'MicrosoftAuthError';
  }
}

export interface MsSession {
  username: string;
  uuid: string;
  skinUrl?: string;
  minecraftToken: string;
  expiresAt: string;
  refreshToken: string;
}

const XSTS_ERRORS: Record<number, string> = {
  2148916233: 'This Microsoft account has no Xbox profile. Sign in at xbox.com once to create one.',
  2148916235: 'Xbox Live is not available in this account\'s country or region.',
  2148916236: 'This account needs adult verification on the Xbox site.',
  2148916237: 'This account needs adult verification on the Xbox site.',
  2148916238: 'This is a child account. An adult must add it to a Microsoft family before it can play.',
};

function form(data: Record<string, string>): string {
  return new URLSearchParams(data).toString();
}

async function post(fetchFn: FetchLike, url: string, body: string, contentType: string, extra: Record<string, string> = {}) {
  return fetchFn(url, { method: 'POST', headers: { 'Content-Type': contentType, Accept: 'application/json', ...extra }, body });
}

export class MicrosoftAuth {
  constructor(
    private readonly clientId: string,
    private readonly fetchFn: FetchLike,
    private readonly sleep: (ms: number) => Promise<void> = (ms) => new Promise((r) => setTimeout(r, ms)),
  ) {
    if (!clientId) {
      throw new MicrosoftAuthError('No Microsoft application ID is configured. Add one in Settings > Account.', 'no_client_id');
    }
  }

  async beginDeviceCode(): Promise<DeviceCodeInfo & { deviceCode: string }> {
    const res = await post(this.fetchFn, `${TENANT}/devicecode`, form({ client_id: this.clientId, scope: SCOPE }), 'application/x-www-form-urlencoded');
    const body = await res.json();
    if (!res.ok) throw new MicrosoftAuthError(body.error_description ?? 'Could not start Microsoft sign-in.', body.error);
    return {
      deviceCode: body.device_code,
      userCode: body.user_code,
      verificationUri: body.verification_uri,
      expiresInSec: body.expires_in,
      intervalSec: body.interval ?? 5,
    };
  }

  /** Polls until the user finishes sign-in, then runs the full Xbox + Minecraft exchange. */
  async completeDeviceCode(info: { deviceCode: string; expiresInSec: number; intervalSec: number }): Promise<MsSession> {
    let interval = info.intervalSec * 1000;
    const deadline = Date.now() + info.expiresInSec * 1000;
    while (Date.now() < deadline) {
      await this.sleep(interval);
      const res = await post(
        this.fetchFn,
        `${TENANT}/token`,
        form({ grant_type: 'urn:ietf:params:oauth:grant-type:device_code', client_id: this.clientId, device_code: info.deviceCode }),
        'application/x-www-form-urlencoded',
      );
      const body = await res.json();
      if (res.ok) return this.exchange(body.access_token, body.refresh_token);
      if (body.error === 'authorization_pending') continue;
      if (body.error === 'slow_down') { interval += 5000; continue; }
      if (body.error === 'authorization_declined') throw new MicrosoftAuthError('Sign-in was declined.', body.error);
      if (body.error === 'expired_token') break;
      throw new MicrosoftAuthError(body.error_description ?? 'Microsoft sign-in failed.', body.error);
    }
    throw new MicrosoftAuthError('The sign-in code expired. Start again.', 'expired_token');
  }

  async refresh(refreshToken: string): Promise<MsSession> {
    const res = await post(
      this.fetchFn,
      `${TENANT}/token`,
      form({ grant_type: 'refresh_token', client_id: this.clientId, refresh_token: refreshToken, scope: SCOPE }),
      'application/x-www-form-urlencoded',
    );
    const body = await res.json();
    if (!res.ok) throw new MicrosoftAuthError('Your Microsoft session expired. Sign in again.', body.error);
    return this.exchange(body.access_token, body.refresh_token ?? refreshToken);
  }

  /** XBL -> XSTS -> Minecraft Services -> profile. */
  private async exchange(msAccessToken: string, refreshToken: string): Promise<MsSession> {
    const xbl = await post(
      this.fetchFn,
      'https://user.auth.xboxlive.com/user/authenticate',
      JSON.stringify({
        Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: `d=${msAccessToken}` },
        RelyingParty: 'http://auth.xboxlive.com',
        TokenType: 'JWT',
      }),
      'application/json',
    );
    if (!xbl.ok) throw new MicrosoftAuthError('Xbox Live rejected the sign-in.', 'xbl_failed');
    const xblBody = await xbl.json();

    const xsts = await post(
      this.fetchFn,
      'https://xsts.auth.xboxlive.com/xsts/authorize',
      JSON.stringify({
        Properties: { SandboxId: 'RETAIL', UserTokens: [xblBody.Token] },
        RelyingParty: 'rp://api.minecraftservices.com/',
        TokenType: 'JWT',
      }),
      'application/json',
    );
    const xstsBody = await xsts.json();
    if (!xsts.ok) {
      const msg = XSTS_ERRORS[xstsBody.XErr as number] ?? 'Xbox Live refused to authorize Minecraft for this account.';
      throw new MicrosoftAuthError(msg, String(xstsBody.XErr ?? 'xsts_failed'));
    }
    const uhs: string = xstsBody.DisplayClaims?.xui?.[0]?.uhs ?? xblBody.DisplayClaims?.xui?.[0]?.uhs;

    const mc = await post(
      this.fetchFn,
      'https://api.minecraftservices.com/authentication/login_with_xbox',
      JSON.stringify({ identityToken: `XBL3.0 x=${uhs};${xstsBody.Token}` }),
      'application/json',
    );
    if (!mc.ok) throw new MicrosoftAuthError('Minecraft Services rejected the Xbox token.', 'mc_login_failed');
    const mcBody = await mc.json();
    const token: string = mcBody.access_token;

    // Entitlement is verified by the profile call: accounts that do not own Java Edition get 404 here.
    const profileRes = await this.fetchFn('https://api.minecraftservices.com/minecraft/profile', {
      headers: { Authorization: `Bearer ${token}`, Accept: 'application/json' },
    });
    if (profileRes.status === 404) {
      throw new MicrosoftAuthError('This account does not own Minecraft: Java Edition.', 'no_entitlement');
    }
    if (!profileRes.ok) throw new MicrosoftAuthError('Could not load the Minecraft profile.', 'profile_failed');
    const profile = await profileRes.json();
    const skin = (profile.skins as any[] | undefined)?.find((s) => s.state === 'ACTIVE');
    return {
      username: profile.name,
      uuid: profile.id,
      skinUrl: skin?.url,
      minecraftToken: token,
      expiresAt: new Date(Date.now() + (mcBody.expires_in ?? 86400) * 1000).toISOString(),
      refreshToken,
    };
  }
}
