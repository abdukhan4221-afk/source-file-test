import dns from 'node:dns/promises';
import net from 'node:net';
import type { ServerStatus } from '@eclipse/shared-types';

export function parseAddress(input: string): { host: string; port: number } {
  const s = input.trim();
  const v6 = /^\[([^\]]+)\](?::(\d+))?$/.exec(s);
  if (v6) return { host: v6[1] as string, port: v6[2] ? Number(v6[2]) : 25565 };
  const idx = s.lastIndexOf(':');
  if (idx > 0 && s.indexOf(':') === idx) {
    const port = Number(s.slice(idx + 1));
    if (Number.isInteger(port) && port > 0 && port < 65536) return { host: s.slice(0, idx), port };
  }
  return { host: s, port: 25565 };
}

function varInt(n: number): Buffer {
  const out: number[] = [];
  let v = n >>> 0;
  do {
    let b = v & 0x7f;
    v >>>= 7;
    if (v !== 0) b |= 0x80;
    out.push(b);
  } while (v !== 0);
  return Buffer.from(out);
}

function readVarInt(buf: Buffer, offset = 0): { value: number; size: number } | null {
  let value = 0;
  for (let i = 0; i < 5; i++) {
    const byte = buf[offset + i];
    if (byte === undefined) return null;
    value |= (byte & 0x7f) << (7 * i);
    if ((byte & 0x80) === 0) return { value, size: i + 1 };
  }
  throw new Error('VarInt is too long');
}

function packet(id: number, payload: Buffer): Buffer {
  const body = Buffer.concat([varInt(id), payload]);
  return Buffer.concat([varInt(body.length), body]);
}

function flattenChat(c: unknown): string {
  if (typeof c === 'string') return c;
  if (!c || typeof c !== 'object') return '';
  const o = c as { text?: string; extra?: unknown[] };
  return (o.text ?? '') + (o.extra ?? []).map(flattenChat).join('');
}

async function resolveTarget(host: string, port: number): Promise<{ host: string; port: number }> {
  if (port !== 25565 || net.isIP(host)) return { host, port };
  try {
    const srv = await dns.resolveSrv(`_minecraft._tcp.${host}`);
    const first = srv[0];
    if (first) return { host: first.name, port: first.port };
  } catch { /* no SRV record */ }
  return { host, port };
}

/** Real Server List Ping. Nothing here is invented: every field comes from the server's reply. */
export async function pingServer(address: string, timeoutMs = 5000): Promise<ServerStatus> {
  const { host: origHost, port: origPort } = parseAddress(address);
  const target = await resolveTarget(origHost, origPort);
  return new Promise<ServerStatus>((resolve) => {
    const started = Date.now();
    const sock = net.connect({ host: target.host, port: target.port });
    let buf = Buffer.alloc(0);
    let status: Partial<ServerStatus> | null = null;
    let statusAt = 0;
    const payloadId = BigInt(Date.now());
    let finished = false;

    const finish = (r: ServerStatus) => {
      if (finished) return;
      finished = true;
      sock.destroy();
      resolve(r);
    };
    sock.setTimeout(timeoutMs, () => finish(status ? { online: true, ...status } : { online: false, error: 'Timed out.' }));
    sock.on('error', (e) => finish({ online: false, error: e.message }));
    sock.on('connect', () => {
      const portBuf = Buffer.alloc(2);
      portBuf.writeUInt16BE(origPort);
      const hostBuf = Buffer.from(origHost, 'utf8');
      sock.write(packet(0x00, Buffer.concat([varInt(765), varInt(hostBuf.length), hostBuf, portBuf, varInt(1)])));
      sock.write(packet(0x00, Buffer.alloc(0)));
    });
    sock.on('data', (chunk) => {
      buf = Buffer.concat([buf, chunk]);
      try {
        for (;;) {
          const len = readVarInt(buf);
          if (!len || buf.length < len.size + len.value) return;
          const body = buf.subarray(len.size, len.size + len.value);
          buf = buf.subarray(len.size + len.value);
          const id = readVarInt(body);
          if (!id) return;
          const data = body.subarray(id.size);
          if (id.value === 0x00 && !status) {
            const sl = readVarInt(data);
            if (!sl) return;
            const json = JSON.parse(data.subarray(sl.size, sl.size + sl.value).toString('utf8'));
            statusAt = Date.now();
            status = {
              versionName: json.version?.name,
              protocol: json.version?.protocol,
              playersOnline: json.players?.online,
              playersMax: json.players?.max,
              motd: flattenChat(json.description),
              latencyMs: statusAt - started,
            };
            const ping = Buffer.alloc(8);
            ping.writeBigInt64BE(payloadId);
            sock.write(packet(0x01, ping));
          } else if (id.value === 0x01 && status) {
            finish({ online: true, ...status, latencyMs: Date.now() - statusAt });
          }
        }
      } catch (e) {
        finish({ online: false, error: `Invalid server reply: ${(e as Error).message}` });
      }
    });
    sock.on('close', () => finish(status ? { online: true, ...status } : { online: false, error: 'Connection closed.' }));
  });
}

export const __test = { varInt, readVarInt, packet };
