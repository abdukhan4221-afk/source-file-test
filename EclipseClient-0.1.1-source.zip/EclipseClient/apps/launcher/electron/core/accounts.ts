import crypto from 'node:crypto';
import path from 'node:path';
import type { Account, AccountsState, LocalAccount, MicrosoftAccount } from '@eclipse/shared-types';
import { readJson, writeJsonAtomic } from './jsonStore';

/** OS-backed secret storage (Electron safeStorage in production). Tokens never touch accounts.json. */
export interface SecretStore {
  set(key: string, value: string): void;
  get(key: string): string | null;
  delete(key: string): void;
}

export class AccountError extends Error {}

export function validateMinecraftUsername(name: string): string | null {
  if (name.length < 3 || name.length > 16) return 'Usernames must be 3 to 16 characters.';
  if (!/^[A-Za-z0-9_]+$/.test(name)) return 'Use only letters, numbers and underscores.';
  return null;
}

/** Same algorithm as Java's UUID.nameUUIDFromBytes("OfflinePlayer:<name>"). */
export function offlineUuid(username: string): string {
  const h = crypto.createHash('md5').update(`OfflinePlayer:${username}`).digest();
  h[6] = ((h[6] as number) & 0x0f) | 0x30;
  h[8] = ((h[8] as number) & 0x3f) | 0x80;
  const hex = h.toString('hex');
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

interface Stored {
  accounts: Account[];
  selectedId: string | null;
  defaultId: string | null;
}

export interface MicrosoftTokens {
  refreshToken: string;
  minecraftToken: string;
}

export class AccountService {
  private readonly file: string;
  private data: Stored;
  private guests: LocalAccount[] = [];

  constructor(root: string, private readonly secrets: SecretStore) {
    this.file = path.join(root, 'accounts.json');
    this.data = readJson<Stored>(this.file, { accounts: [], selectedId: null, defaultId: null });
  }

  private save(): void {
    writeJsonAtomic(this.file, this.data); // guests are deliberately excluded
  }

  state(): AccountsState {
    return { accounts: [...this.data.accounts, ...this.guests], selectedId: this.data.selectedId, defaultId: this.data.defaultId };
  }

  get(id: string): Account {
    const a = this.state().accounts.find((x) => x.id === id);
    if (!a) throw new AccountError('Account not found.');
    return a;
  }

  selected(): Account | null {
    const s = this.state();
    return s.accounts.find((a) => a.id === (s.selectedId ?? s.defaultId)) ?? null;
  }

  addLocal(username: string, guest = false): LocalAccount {
    const name = guest ? `Guest_${crypto.randomBytes(2).toString('hex')}` : username.trim();
    const problem = validateMinecraftUsername(name);
    if (problem) throw new AccountError(problem);
    if (this.state().accounts.some((a) => a.username.toLowerCase() === name.toLowerCase())) {
      throw new AccountError('An account with that username already exists.');
    }
    const acc: LocalAccount = { kind: 'local', id: crypto.randomUUID().slice(0, 8), username: name, guest };
    if (guest) {
      this.guests.push(acc); // session only, never persisted
    } else {
      this.data.accounts.push(acc);
    }
    if (!this.data.selectedId) this.data.selectedId = acc.id;
    if (!this.data.defaultId && !guest) this.data.defaultId = acc.id;
    this.save();
    return acc;
  }

  upsertMicrosoft(acc: Omit<MicrosoftAccount, 'kind' | 'id'>, tokens: MicrosoftTokens): MicrosoftAccount {
    const existing = this.data.accounts.find((a): a is MicrosoftAccount => a.kind === 'microsoft' && a.uuid === acc.uuid);
    const record: MicrosoftAccount = { kind: 'microsoft', id: existing?.id ?? crypto.randomUUID().slice(0, 8), ...acc };
    if (existing) Object.assign(existing, record);
    else this.data.accounts.push(record);
    this.secrets.set(`ms:${record.id}`, JSON.stringify(tokens));
    if (!this.data.selectedId) this.data.selectedId = record.id;
    if (!this.data.defaultId) this.data.defaultId = record.id;
    this.save();
    return record;
  }

  tokensFor(id: string): MicrosoftTokens | null {
    const raw = this.secrets.get(`ms:${id}`);
    return raw ? (JSON.parse(raw) as MicrosoftTokens) : null;
  }

  remove(id: string): void {
    this.get(id);
    this.data.accounts = this.data.accounts.filter((a) => a.id !== id);
    this.guests = this.guests.filter((a) => a.id !== id);
    this.secrets.delete(`ms:${id}`);
    const first = this.state().accounts[0]?.id ?? null;
    if (this.data.selectedId === id) this.data.selectedId = first;
    if (this.data.defaultId === id) this.data.defaultId = this.data.accounts[0]?.id ?? null;
    this.save();
  }

  select(id: string): void {
    this.get(id);
    this.data.selectedId = id;
    this.save();
  }

  setDefault(id: string): void {
    const a = this.get(id);
    if (a.kind === 'local' && a.guest) throw new AccountError('Guest sessions cannot be the default account.');
    this.data.defaultId = id;
    this.save();
  }

  rename(id: string, username: string): void {
    const a = this.get(id);
    if (a.kind !== 'local') throw new AccountError('Only local accounts can be renamed. Microsoft names come from Minecraft.');
    const problem = validateMinecraftUsername(username);
    if (problem) throw new AccountError(problem);
    a.username = username;
    this.save();
  }
}
