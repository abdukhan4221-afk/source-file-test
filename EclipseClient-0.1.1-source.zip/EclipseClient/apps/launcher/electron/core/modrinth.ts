import fs from 'node:fs';
import path from 'node:path';
import { unzipSync } from 'fflate';
import type { InstallProgress, LoaderId, ModrinthHit, ModrinthKind } from '@eclipse/shared-types';
import type { FetchLike } from './versions';
import { downloadVerified, sha } from './installer';
import { isSafeFileName, isSafeRelativePath, resolveInside } from './fsSafe';

const API = 'https://api.modrinth.com/v2';
export const USER_AGENT = 'EclipseClient/0.1.0 (open-source launcher)';
const HEADERS = { 'User-Agent': USER_AGENT, Accept: 'application/json' };

/** Hosts a modpack is allowed to download from, per the Modrinth modpack spec. */
export const MRPACK_HOSTS = ['cdn.modrinth.com', 'github.com', 'raw.githubusercontent.com', 'gitlab.com'];

export interface MrVersion {
  id: string;
  project_id: string;
  version_number: string;
  version_type: 'release' | 'beta' | 'alpha';
  date_published: string;
  game_versions: string[];
  loaders: string[];
  files: { url: string; filename: string; primary: boolean; hashes: { sha1: string; sha512: string }; size: number }[];
  dependencies: { project_id?: string; version_id?: string; dependency_type: 'required' | 'optional' | 'incompatible' | 'embedded' }[];
}

const SUBDIR: Record<Exclude<ModrinthKind, 'modpack'>, string> = { mod: 'mods', resourcepack: 'resourcepacks', shader: 'shaderpacks' };

export class ModrinthClient {
  constructor(private readonly fetchFn: FetchLike) {}

  private async get<T>(pathAndQuery: string): Promise<T> {
    const res = await this.fetchFn(`${API}${pathAndQuery}`, { headers: HEADERS });
    if (!res.ok) throw new Error(`Modrinth returned HTTP ${res.status} for ${pathAndQuery.split('?')[0]}`);
    return (await res.json()) as T;
  }

  async search(q: { query: string; kind: ModrinthKind; mcVersion?: string; loader?: LoaderId }): Promise<ModrinthHit[]> {
    const facets: string[][] = [[`project_type:${q.kind}`]];
    if (q.mcVersion) facets.push([`versions:${q.mcVersion}`]);
    if (q.loader && q.loader !== 'vanilla' && (q.kind === 'mod' || q.kind === 'modpack')) facets.push([`categories:${q.loader}`]);
    const body = await this.get<{ hits: any[] }>(`/search?query=${encodeURIComponent(q.query)}&facets=${encodeURIComponent(JSON.stringify(facets))}&limit=24`);
    return body.hits.map((h) => ({
      projectId: h.project_id,
      slug: h.slug,
      title: h.title,
      description: h.description,
      author: h.author,
      iconUrl: h.icon_url || undefined,
      downloads: h.downloads,
      kind: q.kind,
    }));
  }

  versionsFor(projectId: string, mcVersion: string, loader?: LoaderId): Promise<MrVersion[]> {
    const params = [`game_versions=${encodeURIComponent(JSON.stringify([mcVersion]))}`];
    if (loader && loader !== 'vanilla') params.push(`loaders=${encodeURIComponent(JSON.stringify([loader]))}`);
    return this.get<MrVersion[]>(`/project/${projectId}/version?${params.join('&')}`);
  }

  version(id: string): Promise<MrVersion> {
    return this.get<MrVersion>(`/version/${id}`);
  }

  allVersions(projectId: string): Promise<MrVersion[]> {
    return this.get<MrVersion[]>(`/project/${projectId}/version`);
  }
}

/** Newest release, falling back to beta then alpha. */
export function pickVersion(versions: MrVersion[]): MrVersion | undefined {
  const rank = { release: 0, beta: 1, alpha: 2 } as const;
  return [...versions].sort((a, b) => rank[a.version_type] - rank[b.version_type] || b.date_published.localeCompare(a.date_published))[0];
}

export interface PlannedFile { projectId: string; version: MrVersion; file: MrVersion['files'][number] }

/** Resolve a project and every required dependency once, skipping projects that are already installed. */
export async function planInstall(
  client: Pick<ModrinthClient, 'versionsFor' | 'version'>,
  projectId: string,
  mcVersion: string,
  loader: LoaderId | undefined,
  installed: Set<string>,
): Promise<PlannedFile[]> {
  const plan: PlannedFile[] = [];
  const queued = new Set<string>(installed);
  const walk = async (pid: string, pinned?: string): Promise<void> => {
    if (queued.has(pid)) return;
    queued.add(pid);
    const v = pinned ? await client.version(pinned) : pickVersion(await client.versionsFor(pid, mcVersion, loader));
    if (!v) throw new Error(`No version of project ${pid} supports Minecraft ${mcVersion}${loader ? ` on ${loader}` : ''}.`);
    const file = v.files.find((f) => f.primary) ?? v.files[0];
    if (!file) throw new Error(`Version ${v.version_number} has no downloadable file.`);
    plan.push({ projectId: pid, version: v, file });
    for (const dep of v.dependencies) {
      if (dep.dependency_type === 'required' && dep.project_id) await walk(dep.project_id, dep.version_id);
    }
  };
  await walk(projectId);
  return plan;
}

interface InstalledIndex { [projectId: string]: { file: string; versionId: string } }

export class ContentInstaller {
  constructor(private readonly client: ModrinthClient, private readonly fetchFn: FetchLike) {}

  async install(
    projectId: string,
    kind: Exclude<ModrinthKind, 'modpack'>,
    target: { gameDir: string; mcVersion: string; loader: LoaderId },
    onProgress: (p: InstallProgress) => void,
  ): Promise<string[]> {
    const indexFile = path.join(target.gameDir, 'eclipse', 'installed.json');
    let index: InstalledIndex = {};
    try { index = JSON.parse(fs.readFileSync(indexFile, 'utf8')); } catch { /* first install */ }

    const report = (stage: InstallProgress['stage'], done: number, total: number, label: string, error?: string) =>
      onProgress({ id: projectId, label, done, total, stage, error });
    try {
      report('resolving', 0, 1, 'Finding a compatible version');
      const loader = kind === 'mod' ? target.loader : undefined;
      const plan = await planInstall(this.client, projectId, target.mcVersion, loader, new Set(Object.keys(index)));
      if (plan.length === 0) {
        report('done', 1, 1, 'Already installed');
        return [];
      }
      const dir = resolveInside(target.gameDir, SUBDIR[kind]);
      const written: string[] = [];
      for (const [i, p] of plan.entries()) {
        if (!isSafeFileName(p.file.filename)) throw new Error(`Unsafe file name from Modrinth: ${p.file.filename}`);
        report('downloading', i, plan.length, p.file.filename);
        await downloadVerified(this.fetchFn, p.file.url, path.join(dir, p.file.filename), { algo: 'sha512', hash: p.file.hashes.sha512 });
        index[p.projectId] = { file: p.file.filename, versionId: p.version.id };
        written.push(p.file.filename);
      }
      fs.mkdirSync(path.dirname(indexFile), { recursive: true });
      fs.writeFileSync(indexFile, JSON.stringify(index, null, 2));
      report('done', plan.length, plan.length, `Installed ${written.length} file(s)`);
      return written;
    } catch (e) {
      report('failed', 0, 1, 'Install failed', (e as Error).message);
      throw e;
    }
  }
}

// ---------- .mrpack (Modrinth Pack v1) ----------

export interface MrpackIndex {
  formatVersion: number;
  game: string;
  name: string;
  files: { path: string; hashes: { sha1: string; sha512: string }; downloads: string[]; fileSize: number; env?: { client?: string } }[];
  dependencies: Record<string, string>;
}

export interface ParsedMrpack {
  index: MrpackIndex;
  overrides: Map<string, Uint8Array>;
  minecraft: string;
  loader: LoaderId;
  loaderVersion?: string;
}

const LOADER_KEYS: Record<string, LoaderId> = {
  'fabric-loader': 'fabric', 'quilt-loader': 'quilt', forge: 'forge', neoforge: 'neoforge',
};
const MAX_PACK_BYTES = 1024 * 1024 * 1024;

export function parseMrpack(archive: Uint8Array): ParsedMrpack {
  let total = 0;
  const entries = unzipSync(archive, {
    filter: (f) => {
      total += f.originalSize;
      if (total > MAX_PACK_BYTES) throw new Error('Modpack is larger than the 1 GB safety limit.');
      return true;
    },
  });
  const raw = entries['modrinth.index.json'];
  if (!raw) throw new Error('Not a Modrinth modpack: modrinth.index.json is missing.');
  const index = JSON.parse(new TextDecoder().decode(raw)) as MrpackIndex;
  if (index.formatVersion !== 1 || index.game !== 'minecraft') throw new Error('Unsupported modpack format.');
  const minecraft = index.dependencies.minecraft;
  if (!minecraft) throw new Error('Modpack does not declare a Minecraft version.');

  let loader: LoaderId = 'vanilla';
  let loaderVersion: string | undefined;
  for (const [k, id] of Object.entries(LOADER_KEYS)) {
    if (index.dependencies[k]) { loader = id; loaderVersion = index.dependencies[k]; }
  }

  for (const f of index.files) {
    if (!isSafeRelativePath(f.path)) throw new Error(`Modpack contains an unsafe path: ${f.path}`);
    for (const url of f.downloads) {
      const u = new URL(url);
      if (u.protocol !== 'https:' || !MRPACK_HOSTS.includes(u.hostname)) throw new Error(`Modpack download host is not allowed: ${u.hostname}`);
    }
  }

  const overrides = new Map<string, Uint8Array>();
  for (const [name, data] of Object.entries(entries)) {
    for (const prefix of ['overrides/', 'client-overrides/']) {
      if (name.startsWith(prefix) && !name.endsWith('/')) {
        const rel = name.slice(prefix.length);
        if (!isSafeRelativePath(rel)) throw new Error(`Modpack override has an unsafe path: ${name}`);
        overrides.set(rel, data);
      }
    }
  }
  return { index, overrides, minecraft, loader, loaderVersion };
}

/** Applies a parsed pack into an (already created, isolated) game directory. Cleans up on failure. */
export async function applyMrpack(
  pack: ParsedMrpack,
  gameDir: string,
  fetchFn: FetchLike,
  onProgress: (p: InstallProgress) => void,
  id: string,
): Promise<void> {
  const written: string[] = [];
  try {
    const files = pack.index.files.filter((f) => f.env?.client !== 'unsupported');
    for (const [i, f] of files.entries()) {
      onProgress({ id, label: path.basename(f.path), done: i, total: files.length, stage: 'downloading' });
      const dest = resolveInside(gameDir, f.path);
      const url = f.downloads[0];
      if (!url) throw new Error(`No download URL for ${f.path}`);
      await downloadVerified(fetchFn, url, dest, { algo: 'sha512', hash: f.hashes.sha512 });
      written.push(dest);
    }
    onProgress({ id, label: 'Applying overrides', done: files.length, total: files.length, stage: 'applying' });
    for (const [rel, data] of pack.overrides) {
      const dest = resolveInside(gameDir, rel);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, data);
      written.push(dest);
    }
    onProgress({ id, label: pack.index.name, done: files.length, total: files.length, stage: 'done' });
  } catch (e) {
    for (const f of written) fs.rmSync(f, { force: true });
    onProgress({ id, label: 'Import failed', done: 0, total: 1, stage: 'failed', error: (e as Error).message });
    throw e;
  }
}

/**
 * Full modpack flow: download the .mrpack, validate it, create a NEW isolated profile named after the pack,
 * download files, apply overrides. A failed import removes the half-built profile.
 */
export async function installModpack(
  client: Pick<ModrinthClient, 'allVersions'>,
  fetchFn: FetchLike,
  projectId: string,
  title: string,
  createProfile: (name: string, mc: string, loader: LoaderId, loaderVersion?: string) => { id: string; gameDir: string },
  discardProfile: (id: string) => void,
  onProgress: (p: InstallProgress) => void,
): Promise<{ id: string }> {
  onProgress({ id: projectId, label: 'Finding the latest version', done: 0, total: 1, stage: 'resolving' });
  const v = pickVersion(await client.allVersions(projectId));
  const file = v?.files.find((f) => f.filename.endsWith('.mrpack')) ?? v?.files[0];
  if (!v || !file) throw new Error('This modpack has no downloadable version.');
  const res = await fetchFn(file.url);
  if (!res.ok) throw new Error(`Modpack download failed (HTTP ${res.status}).`);
  const bytes = new Uint8Array(await res.arrayBuffer());
  onProgress({ id: projectId, label: 'Verifying modpack', done: 0, total: 1, stage: 'verifying' });
  if (sha('sha512', bytes) !== file.hashes.sha512.toLowerCase()) throw new Error('Modpack checksum mismatch. Nothing was installed.');
  const pack = parseMrpack(bytes);
  const profile = createProfile(pack.index.name || title, pack.minecraft, pack.loader, pack.loaderVersion);
  try {
    await applyMrpack(pack, profile.gameDir, fetchFn, onProgress, projectId);
  } catch (e) {
    discardProfile(profile.id);
    throw e;
  }
  return { id: profile.id };
}
