import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

export interface JavaInstall {
  path: string;
  major: number;
  vendor?: string;
}

/** Parses the stderr banner of `java -version`. Handles "1.8.0_392" (Java 8) and "21.0.1" styles. */
export function parseJavaVersionOutput(out: string): { major: number; vendor?: string } | null {
  const m = /version "(\d+)(?:\.(\d+))?[^"]*"/.exec(out);
  if (!m) return null;
  let major = Number(m[1]);
  if (major === 1 && m[2]) major = Number(m[2]);
  const vendor = /(Temurin|Zulu|Corretto|GraalVM|OpenJDK|Java\(TM\)|Microsoft|Semeru|Liberica)/i.exec(out)?.[1];
  return { major, vendor };
}

export function probeJava(javaPath: string, timeoutMs = 4000): Promise<JavaInstall | null> {
  return new Promise((resolve) => {
    execFile(javaPath, ['-version'], { timeout: timeoutMs, env: { ...process.env, JAVA_TOOL_OPTIONS: '' } }, (err, stdout, stderr) => {
      const text = `${stderr}\n${stdout}`;
      const parsed = parseJavaVersionOutput(text);
      if (!parsed || (err && !parsed)) return resolve(null);
      resolve({ path: javaPath, ...parsed });
    });
  });
}

function candidatePaths(): string[] {
  const exe = process.platform === 'win32' ? 'java.exe' : 'java';
  const out = new Set<string>();
  if (process.env.JAVA_HOME) out.add(path.join(process.env.JAVA_HOME, 'bin', exe));
  out.add(exe); // PATH lookup
  const scanDirs: string[] = [];
  if (process.platform === 'win32') {
    for (const base of [process.env['ProgramFiles'], process.env['ProgramFiles(x86)']]) {
      if (!base) continue;
      for (const vendor of ['Java', 'Eclipse Adoptium', 'Microsoft', 'Zulu', 'Amazon Corretto']) scanDirs.push(path.join(base, vendor));
    }
  } else if (process.platform === 'darwin') {
    scanDirs.push('/Library/Java/JavaVirtualMachines');
  } else {
    scanDirs.push('/usr/lib/jvm', path.join(process.env.HOME ?? '', '.sdkman/candidates/java'));
  }
  for (const dir of scanDirs) {
    let entries: string[] = [];
    try { entries = fs.readdirSync(dir); } catch { continue; }
    for (const e of entries) {
      const home = process.platform === 'darwin' ? path.join(dir, e, 'Contents', 'Home') : path.join(dir, e);
      out.add(path.join(home, 'bin', exe));
    }
  }
  return [...out];
}

export async function detectJava(): Promise<JavaInstall[]> {
  const results = await Promise.all(candidatePaths().map((p) => probeJava(p)));
  const seen = new Set<string>();
  const installs: JavaInstall[] = [];
  for (const r of results) {
    if (!r) continue;
    const key = `${r.major}:${r.vendor ?? ''}:${path.basename(path.dirname(path.dirname(r.path)))}`;
    if (seen.has(key)) continue;
    seen.add(key);
    installs.push(r);
  }
  return installs.sort((a, b) => b.major - a.major);
}

/** Pick an install satisfying the requirement: exact major preferred, otherwise the smallest newer one. */
export function chooseJava(installs: JavaInstall[], requiredMajor: number): JavaInstall | undefined {
  const exact = installs.find((j) => j.major === requiredMajor);
  if (exact) return exact;
  // Newer Java runs most modern versions, but Java 8-era Minecraft/Forge breaks on 9+, so only allow upward for >= 16.
  if (requiredMajor < 16) return undefined;
  return installs.filter((j) => j.major > requiredMajor).sort((a, b) => a.major - b.major)[0];
}
