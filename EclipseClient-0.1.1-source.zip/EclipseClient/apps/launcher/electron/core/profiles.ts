import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { LoaderId, Profile, ProfilesState } from '@eclipse/shared-types';
import { readJson, writeJsonAtomic } from './jsonStore';
import { resolveInside } from './fsSafe';

export type ProfileFolder = 'game' | 'mods' | 'resourcepacks' | 'shaderpacks' | 'config' | 'saves';

const SUBDIRS = ['mods', 'resourcepacks', 'shaderpacks', 'config', 'saves', 'eclipse'];

interface Stored {
  profiles: Omit<Profile, 'gameDir'>[];
  selectedId: string | null;
  defaultId: string | null;
}

export class ProfileError extends Error {}

/**
 * Isolated game instances. Every profile owns `<root>/instances/<id>`; nothing is shared between them.
 * Removing a profile moves its folder to `<root>/trash` so worlds are never destroyed silently.
 */
export class ProfileService {
  private readonly file: string;
  private readonly instances: string;
  private readonly trash: string;
  private data: Stored;

  constructor(private readonly root: string) {
    this.file = path.join(root, 'profiles.json');
    this.instances = path.join(root, 'instances');
    this.trash = path.join(root, 'trash');
    this.data = readJson<Stored>(this.file, { profiles: [], selectedId: null, defaultId: null });
  }

  private save(): void {
    writeJsonAtomic(this.file, this.data);
  }

  private dirOf(id: string): string {
    return resolveInside(this.instances, id);
  }

  private hydrate(p: Omit<Profile, 'gameDir'>): Profile {
    return { ...p, gameDir: this.dirOf(p.id) };
  }

  private find(id: string): Omit<Profile, 'gameDir'> {
    const p = this.data.profiles.find((x) => x.id === id);
    if (!p) throw new ProfileError(`Profile not found: ${id}`);
    return p;
  }

  private static cleanName(name: string): string {
    const n = name.trim().replace(/\s+/g, ' ');
    if (n.length < 1 || n.length > 48) throw new ProfileError('Profile names must be 1 to 48 characters.');
    return n;
  }

  state(): ProfilesState {
    const profiles = [...this.data.profiles]
      .sort((a, b) => Number(b.pinned) - Number(a.pinned) || a.order - b.order)
      .map((p) => this.hydrate(p));
    return { profiles, selectedId: this.data.selectedId, defaultId: this.data.defaultId };
  }

  get(id: string): Profile {
    return this.hydrate(this.find(id));
  }

  create(input: { name: string; minecraftVersion: string; loader: LoaderId; loaderVersion?: string }): Profile {
    const id = crypto.randomUUID().slice(0, 8);
    const profile: Omit<Profile, 'gameDir'> = {
      id,
      name: ProfileService.cleanName(input.name),
      minecraftVersion: input.minecraftVersion,
      loader: input.loader,
      loaderVersion: input.loaderVersion,
      createdAt: Date.now(),
      playtimeMs: 0,
      pinned: false,
      order: this.data.profiles.length,
    };
    const dir = this.dirOf(id);
    fs.mkdirSync(dir, { recursive: true });
    for (const s of SUBDIRS) fs.mkdirSync(path.join(dir, s), { recursive: true });
    this.data.profiles.push(profile);
    if (!this.data.selectedId) this.data.selectedId = id;
    if (!this.data.defaultId) this.data.defaultId = id;
    this.save();
    return this.hydrate(profile);
  }

  clone(id: string): Profile {
    const src = this.find(id);
    const copy = this.create({
      name: `${src.name} copy`.slice(0, 48),
      minecraftVersion: src.minecraftVersion,
      loader: src.loader,
      loaderVersion: src.loaderVersion,
    });
    fs.cpSync(this.dirOf(id), copy.gameDir, { recursive: true });
    const stored = this.find(copy.id);
    stored.javaPath = src.javaPath;
    stored.memoryMb = src.memoryMb;
    stored.jvmArgs = src.jvmArgs;
    this.save();
    return this.hydrate(stored);
  }

  rename(id: string, name: string): void {
    this.find(id).name = ProfileService.cleanName(name);
    this.save();
  }

  update(id: string, patch: Partial<Pick<Profile, 'javaPath' | 'memoryMb' | 'jvmArgs' | 'minecraftVersion' | 'loader' | 'loaderVersion'>>): void {
    Object.assign(this.find(id), patch);
    this.save();
  }

  /** Moves the instance folder to trash instead of deleting it. Returns the trash location. */
  remove(id: string): string {
    this.find(id);
    fs.mkdirSync(this.trash, { recursive: true });
    const dest = path.join(this.trash, `${id}-${Date.now()}`);
    const dir = this.dirOf(id);
    if (fs.existsSync(dir)) fs.renameSync(dir, dest);
    this.data.profiles = this.data.profiles.filter((p) => p.id !== id);
    // Only fix up selection when the removed profile *was* the selection.
    const fallback = this.data.defaultId && this.data.defaultId !== id ? this.data.defaultId : this.data.profiles[0]?.id ?? null;
    if (this.data.selectedId === id) this.data.selectedId = fallback;
    if (this.data.defaultId === id) this.data.defaultId = this.data.profiles[0]?.id ?? null;
    this.save();
    return dest;
  }

  pin(id: string, pinned: boolean): void {
    this.find(id).pinned = pinned;
    this.save();
  }

  reorder(ids: string[]): void {
    const known = new Set(this.data.profiles.map((p) => p.id));
    if (ids.length !== known.size || ids.some((i) => !known.has(i)) || new Set(ids).size !== ids.length) {
      throw new ProfileError('Reorder must list every profile exactly once.');
    }
    ids.forEach((id, i) => (this.find(id).order = i));
    this.save();
  }

  /** Explicit selection only. Browsing content never calls this. */
  select(id: string): void {
    this.find(id);
    this.data.selectedId = id;
    this.save();
  }

  setDefault(id: string): void {
    this.find(id);
    this.data.defaultId = id;
    this.save();
  }

  folder(id: string, sub: ProfileFolder): string {
    this.find(id);
    return sub === 'game' ? this.dirOf(id) : resolveInside(this.dirOf(id), sub);
  }

  recordPlay(id: string, sessionMs: number): void {
    const p = this.find(id);
    p.playtimeMs += Math.max(0, Math.round(sessionMs));
    p.lastPlayedAt = Date.now();
    this.save();
  }

  markLaunched(id: string): void {
    this.find(id).lastPlayedAt = Date.now();
    this.save();
  }
}
