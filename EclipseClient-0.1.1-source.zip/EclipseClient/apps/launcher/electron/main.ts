import { app, BrowserWindow, ipcMain, safeStorage, session, shell } from 'electron';
import fs from 'node:fs';
import path from 'node:path';
import type { ModrinthKind } from '@eclipse/shared-types';
import { AccountService, type SecretStore } from './core/accounts';
import { ProfileService, type ProfileFolder } from './core/profiles';
import { SettingsStore, ServerStore } from './core/stores';
import { VersionService, type FetchLike } from './core/versions';
import { loadersFor, requiredJava } from './core/compat';
import { detectJava } from './core/java';
import { MicrosoftAuth } from './core/msAuth';
import { ContentInstaller, ModrinthClient, installModpack } from './core/modrinth';
import { pingServer } from './core/serverPing';
import { LaunchService } from './core/launchService';

const DEV_URL = process.env.ECLIPSE_DEV_URL;
const fetchFn: FetchLike = (url, init) => fetch(url, init as RequestInit) as unknown as ReturnType<FetchLike>;

/** Tokens are encrypted with the OS keystore (DPAPI / Keychain / libsecret). If it is unavailable we refuse to store them. */
class OsSecretStore implements SecretStore {
  constructor(private readonly file: string) {}
  private read(): Record<string, string> {
    try { return JSON.parse(fs.readFileSync(this.file, 'utf8')); } catch { return {}; }
  }
  private ensure(): void {
    const weak = process.platform === 'linux' && safeStorage.getSelectedStorageBackend?.() === 'basic_text';
    if (!safeStorage.isEncryptionAvailable() || weak) {
      throw new Error('Secure storage is not available on this system, so Microsoft sign-in cannot be saved. Install a keyring (gnome-keyring or KWallet).');
    }
  }
  set(key: string, value: string): void {
    this.ensure();
    const all = this.read();
    all[key] = safeStorage.encryptString(value).toString('base64');
    fs.writeFileSync(this.file, JSON.stringify(all), { mode: 0o600 });
  }
  get(key: string): string | null {
    const v = this.read()[key];
    if (!v) return null;
    this.ensure();
    return safeStorage.decryptString(Buffer.from(v, 'base64'));
  }
  delete(key: string): void {
    const all = this.read();
    delete all[key];
    fs.writeFileSync(this.file, JSON.stringify(all), { mode: 0o600 });
  }
}

let win: BrowserWindow | null = null;

function trustedSender(url: string): boolean {
  return DEV_URL ? url.startsWith(DEV_URL) : url.startsWith('file://');
}

async function boot(): Promise<void> {
  const root = path.join(app.getPath('userData'), 'eclipse');
  fs.mkdirSync(root, { recursive: true });

  const profiles = new ProfileService(root);
  const accounts = new AccountService(root, new OsSecretStore(path.join(root, 'secrets.json')));
  const settings = new SettingsStore(root);
  const servers = new ServerStore(root);
  const versions = new VersionService(path.join(root, 'version-cache.json'), fetchFn);
  const modrinth = new ModrinthClient(fetchFn);
  const content = new ContentInstaller(modrinth, fetchFn);
  const launch = new LaunchService({ root, profiles, accounts, settings, versions, fetchFn, launcherVersion: app.getVersion() });
  let pendingDevice: Awaited<ReturnType<MicrosoftAuth['beginDeviceCode']>> | null = null;

  const emit = (channel: string, payload: unknown) => win?.webContents.send(channel, payload);
  launch.controller.onState((s) => emit('eclipse:launch-state', s));

  const handlers: Record<string, (...a: any[]) => unknown> = {
    'profiles.state': () => profiles.state(),
    'profiles.create': (i) => profiles.create(i),
    'profiles.clone': (id) => profiles.clone(id),
    'profiles.rename': (id, n) => profiles.rename(id, n),
    'profiles.remove': (id) => { profiles.remove(id); },
    'profiles.pin': (id, p) => profiles.pin(id, !!p),
    'profiles.reorder': (ids) => profiles.reorder(ids),
    'profiles.select': (id) => profiles.select(id),
    'profiles.setDefault': (id) => profiles.setDefault(id),
    'profiles.openFolder': async (id, sub: ProfileFolder) => {
      const err = await shell.openPath(profiles.folder(id, sub));
      if (err) throw new Error(err);
    },
    'versions.list': (refresh) => versions.list(!!refresh),
    'versions.loaders': (v) => loadersFor(String(v)),
    'java.detect': () => detectJava(),
    'java.required': (v) => requiredJava(String(v)),
    'accounts.state': () => accounts.state(),
    'accounts.addLocal': (u, g) => accounts.addLocal(String(u ?? ''), !!g),
    'accounts.remove': (id) => accounts.remove(id),
    'accounts.select': (id) => accounts.select(id),
    'accounts.setDefault': (id) => accounts.setDefault(id),
    'accounts.rename': (id, u) => accounts.rename(id, String(u)),
    'accounts.microsoftBegin': async () => {
      const auth = new MicrosoftAuth(settings.get().msClientId, fetchFn);
      pendingDevice = await auth.beginDeviceCode();
      void shell.openExternal(pendingDevice.verificationUri);
      const { deviceCode: _omit, ...info } = pendingDevice;
      return info;
    },
    'accounts.microsoftFinish': async () => {
      if (!pendingDevice) throw new Error('Start Microsoft sign-in first.');
      const auth = new MicrosoftAuth(settings.get().msClientId, fetchFn);
      const s = await auth.completeDeviceCode(pendingDevice);
      pendingDevice = null;
      return accounts.upsertMicrosoft(
        { username: s.username, uuid: s.uuid, skinUrl: s.skinUrl, expiresAt: s.expiresAt },
        { refreshToken: s.refreshToken, minecraftToken: s.minecraftToken },
      );
    },
    'launch.start': (id) => launch.start(String(id)),
    'launch.stop': () => launch.controller.stop(),
    'launch.state': () => launch.controller.getState(),
    'servers.list': () => servers.list(),
    'servers.save': (e) => servers.save(e),
    'servers.remove': (id) => servers.remove(String(id)),
    'servers.ping': (a) => pingServer(String(a)),
    'modrinth.search': (q) => modrinth.search(q),
    'modrinth.install': async (projectId: string, kind: ModrinthKind, profileId: string) => {
      const progress = (p: unknown) => emit('eclipse:install-progress', p);
      if (kind === 'modpack') {
        await installModpack(
          modrinth, fetchFn, projectId, 'Modpack',
          (name, mc, loader, lv) => profiles.create({ name, minecraftVersion: mc, loader, loaderVersion: lv }),
          (id) => { profiles.remove(id); },
          progress,
        );
        return;
      }
      const p = profiles.get(profileId);
      await content.install(projectId, kind, { gameDir: p.gameDir, mcVersion: p.minecraftVersion, loader: p.loader }, progress);
    },
    'settings.get': () => settings.get(),
    'settings.set': (patch) => settings.set(patch),
    'system.openExternal': async (url: string) => {
      const u = new URL(url);
      if (u.protocol !== 'https:') throw new Error('Only https links can be opened.');
      await shell.openExternal(u.toString());
    },
    'system.appVersion': () => app.getVersion(),
    'system.exportDiagnostics': () => {
      const s = settings.get();
      const report = [
        `Eclipse Client ${app.getVersion()}`,
        `Electron ${process.versions.electron} / Node ${process.versions.node} / ${process.platform} ${process.arch}`,
        `Profiles: ${profiles.state().profiles.length}`,
        `Settings: ${JSON.stringify({ ...s, msClientId: s.msClientId ? '(set)' : '(unset)' })}`,
        `Launch state: ${JSON.stringify(launch.controller.getState())}`,
      ].join('\n');
      const file = path.join(root, `diagnostics-${Date.now()}.txt`);
      fs.writeFileSync(file, report);
      return file;
    },
  };

  ipcMain.handle('eclipse:invoke', async (e, name: string, ...args: unknown[]) => {
    if (!trustedSender(e.senderFrame?.url ?? '')) throw new Error('Blocked IPC from an untrusted origin.');
    const fn = Object.prototype.hasOwnProperty.call(handlers, name) ? handlers[name] : undefined;
    if (!fn) throw new Error(`Unknown action: ${name}`);
    return fn(...args);
  });

  if (!DEV_URL) {
    session.defaultSession.webRequest.onHeadersReceived((details, cb) => {
      cb({
        responseHeaders: {
          ...details.responseHeaders,
          'Content-Security-Policy': ["default-src 'self'; img-src 'self' data: https://cdn.modrinth.com; style-src 'self' 'unsafe-inline'; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'"],
        },
      });
    });
  }
}

function createWindow(): void {
  win = new BrowserWindow({
    width: 1280,
    height: 780,
    minWidth: 1000,
    minHeight: 640,
    backgroundColor: '#08090D',
    title: 'Eclipse Client',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
    },
  });
  win.once('ready-to-show', () => win?.show());
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('https://')) void shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!trustedSender(url)) e.preventDefault();
  });
  if (DEV_URL) void win.loadURL(DEV_URL);
  else void win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
}

const lock = app.requestSingleInstanceLock();
if (!lock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (win) { if (win.isMinimized()) win.restore(); win.focus(); }
  });
  app.whenReady().then(async () => {
    try {
      await boot();
      createWindow();
    } catch (e) {
      // Unhandled startup exceptions must never leave an invisible process behind.
      const { dialog } = await import('electron');
      dialog.showErrorBox('Eclipse Client could not start', (e as Error).message);
      app.quit();
    }
  });
  app.on('window-all-closed', () => app.quit());
}
