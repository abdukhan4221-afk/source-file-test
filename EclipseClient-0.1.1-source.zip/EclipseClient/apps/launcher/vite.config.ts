import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

export default defineConfig({
  base: './',
  plugins: [react()],
  resolve: {
    // The renderer consumes the TypeScript source directly; the main process uses the compiled CommonJS build.
    alias: { '@eclipse/shared-types': fileURLToPath(new URL('../../packages/shared-types/src/index.ts', import.meta.url)) },
  },
  build: { outDir: process.env.VITE_MOCK ? 'dist-qa' : 'dist', emptyOutDir: true },
  server: { port: 5173, strictPort: true },
});
