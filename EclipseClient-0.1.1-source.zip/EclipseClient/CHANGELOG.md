# Changelog

## 0.1.0 (foundation)
- Launcher: startup, Home, Profiles, Servers, Discover (Modrinth), Locker (local skin preview), Store (not connected), Settings, About.
- Engine: isolated profiles, version manifest with offline cache, Java detection, vanilla install and launch, local and Microsoft accounts, Modrinth installs with dependency resolution, `.mrpack` import, real server status.
- Fabric 1.21.1 client source: title screen, loading overlay, Right Shift workspace, HUD editor, 15 modules, profiles.
- Found and fixed during verification: JVM-argument quoting bug; failed-stage reporting bug; unfaithful eclipse corona geometry.
