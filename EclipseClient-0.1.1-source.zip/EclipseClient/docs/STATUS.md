# Status of Eclipse Client 0.1.0

Three levels. Nothing is listed as working unless it was actually run.

## Verified (executed in the authoring environment)

| Area | Evidence |
|---|---|
| Launcher engine: profiles, version cache, Java detection/selection, loader matrix, accounts, launch plan, installer, Modrinth, modpack parsing, server ping, launch state machine | 66 vitest tests, several against local HTTP/TCP servers; two logic bugs were found and fixed by them |
| Real Electron app (dev tree **and packaged Linux build**) | 13 checks over the DevTools protocol under Xvfb: context isolation, IPC round trip, https-only external links, account and profile persistence on disk, isolated instance folders, honest failure when Mojang is unreachable, correct failed-stage marker, recovery of the Play button, zero renderer exceptions |
| Launcher UI layout | Automated overflow/clipping checks for 8 pages x 4 resolutions (1920x1080, 1600x900, 1366x768, 1280x720): 0 defects, plus manual review of screenshots (using the QA mock bridge) |
| Fabric client **core** (modules, settings, registry, HUD layout, profiles, CPS, frame stats, scroll model, card grid, title and workspace layout) | 140 pure-Java tests compiled with the JDK compiler. Mutation-checked: breaking scroll direction or grid width makes tests fail |
| Source guards for the spec's failure list | 8 tests, see `KNOWN_FAILURES.md` |

## Written but NOT verified

| Area | Why unverified |
|---|---|
| Fabric client Minecraft layer (title screen, loading overlay mixin, workspace screen, HUD editor, 15 modules, entry point) | Never compiled against real Minecraft/Fabric (no Maven access) and never launched. Type-checked only against **hand-written stubs of the APIs as I remember them**, which proves syntax and internal consistency, not API correctness. Expect compile fixes on first build |
| Mixin shadows `reload` and `fadeOutStart` on `LoadingOverlay` | Names confirmed in public NeoForge and FancyMenu 1.21.1 sources (see below), not by compiling. The mixin config is `"required": false`, so a failure leaves the vanilla loading screen instead of crashing |
| Gradle/Loom/Fabric versions in `gradle.properties` | Copied from Fabric API's own 1.21.1 branch (Loom 1.6.11, loader 0.15.11, API 0.116.18+1.21.1, Gradle 8.7); never resolved from Maven here |
| Microsoft sign-in | Tested only with mocked HTTP. Never run with a real Azure client ID or account |
| Modrinth and Mojang live calls | Sandbox blocks them. Logic is tested against mocks and local servers |
| Actually starting Minecraft | Never executed (needs Mojang downloads) |
| Forge 1.8.9 | Skeleton, unbuilt |

## Does not exist yet

- **Loader installers** (Fabric, Quilt, Forge, NeoForge, others). They are listed as unavailable, never as installable.
- Launcher does not yet install the Eclipse mod into a profile.
- 31 of the 46 target modules (see below), the crosshair/visual/server/utility modules, replay recording and browser, cosmetics preview.
- In-game profile UI is partial: switch, create and save exist; rename, duplicate, delete and import/export exist in `ProfileManager` (tested) but have no buttons yet.
- Launcher: custom background import, widget rearrangement, 3D skin viewer (a front-view local preview exists), store backend, update delivery, Quick Join, safe mode, per-profile Java picker, language packs.
- Windows and macOS installers; any signing.
- Custom in-game typography (Minecraft's own font is used).

## The 15 modules with real code

FPS Counter, CPS Counter, Ping, Coordinates, Direction HUD, Clock, Memory Monitor, Frame Time Monitor, Target HUD, Keystrokes, Armor HUD, Potion HUD, Toggle Sprint, Toggle Sneak, Zoom.

## API cross-check against public 1.21.1 sources (added after the first release)

Done by downloading NeoForge, Fabric API and FancyMenu (all 1.21.1 branches) from GitHub and grepping them. This is
evidence, not proof: it is not a compile.

**Confirmed present with the shape I use:** `LoadingOverlay` as a mixin target with `render(GuiGraphics, int, int, float)`;
its fields `reload` and `fadeOutStart`; `ReloadInstance.getActualProgress()`/`isDone()`; `GuiGraphics.guiWidth()/guiHeight()`,
`fill(int x5)`, `drawString(Font, String, int, int, int, boolean)`, `renderItem(ItemStack, int, int)`, `pose().pushPose()`;
`Window.getGuiScaledWidth()`; `Minecraft.getUser().getName()`, `isSingleplayer()`, `stop()`, `hitResult`, `getFps()`;
`options.hideGui`, `options.keyAttack`, `options.fov()`; `ClientPacketListener.getPlayerInfo(UUID)`;
`InputConstants.isKeyDown`, `Type.KEYSYM.getOrCreate`, `Key.getDisplayName()`; `MobEffectInstance.getEffect().value()`,
`isInfiniteDuration()`; `Inventory.armor`; `LocalPlayer.setSprinting`; `LivingEntity.getMaxHealth()`;
`Screen.mouseScrolled(double x4)`, `renderBackground(GuiGraphics, int, int, float)`, `onClose()`;
Fabric API `HudRenderCallback`, `ClientTickEvents.END_CLIENT_TICK`, `ClientLifecycleEvents.CLIENT_STOPPING`,
`KeyBindingHelper.registerKeyBinding/getBoundKeyOf`.

**Changed because I could not confirm them:** `crosshairPickEntity` (now `hitResult`), `skipMultiplayerWarning` and
`SafetyScreen` (Multiplayer now opens `JoinMultiplayerScreen` directly, so the one-time online-play warning is skipped),
`Minecraft.allowsMultiplayer()` (Multiplayer card is always enabled), `LoadingOverlay.currentProgress` (now `reload`).

**Assumed, not confirmed (check these first if the build fails):** `PlayerInfo.getLatency()`; constructors
`SelectWorldScreen(Screen)`, `JoinMultiplayerScreen(Screen)`, `OptionsScreen(Screen, Options)`; vanilla 4-argument
`KeyMapping(String, Type, int, String)`; `GuiGraphics.enableScissor/disableScissor` and the 4-argument
`renderItemDecorations`; `Options.keyUp/keyDown/keyLeft/keyRight/keyJump/keyShift/keyUse`;
`SharedConstants.getCurrentVersion().getName()`; `InputConstants.Key.getValue()`; `Font.width(String)`.
