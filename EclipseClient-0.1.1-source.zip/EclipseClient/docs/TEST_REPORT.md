# Test report (0.1.0)

Environment: Linux x86_64 sandbox, Node 22.23, OpenJDK 21, Playwright Chromium, Xvfb. **No access to Mojang, Maven, Microsoft or Modrinth.**

| Suite | Command | Result |
|---|---|---|
| Launcher typecheck (main + renderer) | `npm run typecheck` | pass |
| Launcher unit/integration + source guards | `npm test` | **66 / 66** (12 files) |
| Fabric client core (pure Java) | `npm run test:java` | **140 / 140**, `-Xlint:all` clean |
| Real Electron app, dev tree | `scripts/smoke-electron.py` | 13 / 13 |
| Real Electron app, **packaged Linux build** | `ECLIPSE_EXE=release/linux-unpacked/eclipse-client scripts/smoke-electron.py` | **13 / 13** |
| Visual QA, 8 pages x 4 resolutions (QA mock bridge) | `scripts/visual-qa.py` | 0 layout defects |

## What the tests do and do not prove

- Network behaviour (Mojang, Modrinth, Microsoft) is tested against **mocks and local servers**, never the live services.
- The real-app smoke test covers: renderer has no Node access, bridge exposes exactly the typed surface, IPC round trip, https-only external links, invalid-username rejection, account persisted to disk, profile creates an isolated folder tree, Home reflects the selection, Play fails honestly with Mojang unreachable and marks the correct stage, Play recovers, no uncaught exceptions.
- Visual QA used the mock bridge in a plain browser; the real-app screenshots in `docs/screenshots/real-*.png` were captured from the packaged build.
- **Not tested at all:** the Minecraft-facing Java layer at runtime, the loading screen, the title screen, the workspace, the HUD editor, any module in game, the Forge skeleton, Microsoft login with a real account, a real vanilla launch.

## Bugs the testing found (and fixed)

1. `splitArgs` mishandled quotes in the middle of a token (`-Dfoo="a b"`), which corrupts user JVM arguments.
2. Launch failure always highlighted the first stage because the failing stage was not recorded. Now `failedPhase`.
3. Eclipse hero art: corona gradient peaked inside the black disc (invisible) and the diamond-ring flare sat inside the disc.
4. Smoke-test harness leaked Electron processes and tripped the single-instance lock.
5. `electron-builder` prunes the hoisted workspace `node_modules` mid-build; packaging now uses an isolated staging directory.
