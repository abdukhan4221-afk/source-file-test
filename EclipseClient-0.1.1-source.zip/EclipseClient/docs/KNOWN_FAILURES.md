# Known-failure list from the brief: what guards each item

"Guard" = automated test. "Design" = prevented by construction but not provable without running the game.

| # | Failure | Prevention | Verified? |
|---|---|---|---|
| 1 | Loading stuck at 0% | Progress is the reload's own `getActualProgress()` | Source guard only; not run in game |
| 2 | Cancelling the native loading lifecycle | Mixin injects at TAIL, never cancels, never touches `setOverlay` | **Guard** (`tests/regression.test.ts`) |
| 3 | Homepage unintentionally blurred | `renderBackground` overridden to nothing | **Guard** |
| 4 | Tiny duplicated interfaces | No vanilla widgets on the title screen | **Guard** |
| 5 | Wrong texture-atlas coordinates | No textures at all; fills only | **Guard** |
| 6 | Cropped module cards | `CardGrid` fits width exactly | **Unit tests** at 7 widths, mutation-checked |
| 7 | Controls outside their panels | `WorkspaceLayout`, `TitleLayout` | **Unit tests** at 6 GUI sizes |
| 8 | Broken mouse-wheel scrolling | `ScrollModel` clamps; direction and bounds tested | **Unit tests**, mutation-checked |
| 9 | Wrong Minecraft process state | `LaunchController` | **Unit tests**, plus real-app failure path |
| 10 | Fake loading percentages | Launcher: only counted downloads. Game: vanilla value | Launcher tested; game unverified |
| 11 | Inactive buttons | Launcher buttons exercised in smoke test; in-game unverified | Partial |
| 12 | Placeholder feature screens | Store states plainly it is not connected; only 15 real modules registered | **Guard** (module count) |
| 13 | Incorrect version compatibility | `loadersFor`, `requiredJava` | **Unit tests** |
| 14 | Data loss during updates | Atomic JSON writes, corrupt-file quarantine, trash on removal | **Unit tests** |
| 15 | Unhandled startup exceptions | Launcher: error screen + dialog, smoke-tested. Mod: try/catch with defaults | Launcher verified; mod guard only |
