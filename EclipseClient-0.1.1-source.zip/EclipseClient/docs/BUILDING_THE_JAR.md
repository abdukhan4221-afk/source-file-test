# Getting `eclipseclient.jar`

**No jar is shipped.** Building it needs Minecraft and Fabric downloaded from Maven/Mojang, which the authoring
environment could not reach (tested: maven.fabricmc.net, Maven Central, libraries.minecraft.net, piston-meta.mojang.com
and services.gradle.org all failed; only GitHub worked). A file named `eclipseclient.jar` produced without that would be
fake, so none was made. The project is set up so that **one command** produces it on a connected machine.

## Option A: your machine (JDK 21)

```bash
cd clients/fabric-1.21.1
chmod +x gradlew            # zips lose the executable bit
./gradlew build coreTest    # output: build/dist/eclipseclient.jar
```

## Option B: GitHub Actions (no local setup)

Push the repo to GitHub. The `fabric` job in `.github/workflows/ci.yml` builds it and uploads `eclipseclient.jar` as the
`eclipseclient-jar` artifact (Actions tab > the run > Artifacts). It also validates the Gradle wrapper.

## Installing it

1. Install Fabric Loader for **Minecraft 1.21.1** (Java 21).
2. Put `eclipseclient.jar` **and Fabric API** (`fabric-api-0.116.18+1.21.1.jar` or newer for 1.21.1) in `.minecraft/mods`.
3. Start the game. **Right Shift** opens the module workspace; the Eclipse title screen replaces the vanilla one.

## Expect this on the first build

The Minecraft-facing code (`mc`, `screen`, `mixin`) has never been compiled against the real game. Its API usage was
cross-checked against public 1.21.1 sources (see `STATUS.md`), but a first build can still fail on a method or field I
could not confirm. Compile errors name the exact line; the assumptions most worth checking first are listed in
`STATUS.md` under "Assumed, not confirmed".

If the loading-screen mixin ever fails to apply, the game still starts: `eclipse.mixins.json` is `"required": false`,
and the loading screen simply stays vanilla.

## Pinned toolchain (taken from Fabric API's own 1.21.1 branch)

Loom 1.6.11, Fabric Loader 0.15.11, Fabric API 0.116.18+1.21.1, Gradle 8.7, Java 21, Mojang mappings
(`loom.officialMojangMappings()`, which is also what Fabric's official example mod uses).
The bundled `gradle-wrapper.jar` was downloaded from the official `gradle/gradle` repository (tag v8.8.0), SHA-256
`cb0da6751c2b753a16ac168bb354870ebb1e162e9083f116729cec9c781156b8`; compare it with the checksum Gradle publishes
for that release before trusting it. CI does this automatically via `gradle/actions/wrapper-validation`.
