# Compatibility

## Launcher: what can actually be installed and launched

| Loader | Documented upstream range | Installable in this launcher |
|---|---|---|
| Vanilla | all releases, snapshots, betas, alphas | **Yes** (launch itself unverified against live Mojang) |
| Fabric, Quilt | 1.14+ | No (installer not implemented) |
| Forge | 1.1+ | No |
| NeoForge | 1.20.1+ | No |
| Legacy Fabric | 1.3 to 1.13.2 | No |
| LiteLoader | 1.5.2 to 1.12.2 | No |
| Rift | 1.13.2 | No |
| Ornithe | up to 1.13.2 and pre-1.0 | No |
| Babric | Beta 1.7.3 | No |

Unavailable combinations are disabled in the UI with the reason shown, never offered and then failed.

## Java requirement used

| Minecraft | Java |
|---|---|
| up to 1.16.5 | 8 (newer Java is refused, as it breaks Java 8-era games) |
| 1.17 to 1.17.1 | 16 |
| 1.18 to 1.20.4 | 17 |
| 1.20.5 and newer | 21 |

The version JSON's own `javaVersion` wins when present.

## Eclipse in-game client

| Target | Status |
|---|---|
| Fabric 1.21.1, Java 21 | Source complete for 15 modules; **never built or run** |
| Forge 1.8.9, Java 8 | Skeleton (FPS only); never built |

The launcher shows the Eclipse client as available on **no** version until a build has been produced and verified.
