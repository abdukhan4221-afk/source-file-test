# Build report (0.1.0)

| Deliverable | Status |
|---|---|
| Launcher renderer (`vite build`) | Built. 197 kB JS (62 kB gzip), fonts bundled |
| Launcher main + preload (`tsc`) | Built |
| Linux launcher, **unpacked** (`release/linux-unpacked`, 264 MB) | Built and smoke-tested. **Not an installer** (no AppImage/deb produced) |
| Windows installer (NSIS) | **Not built.** Config exists in `package.json`; needs a Windows (or Wine) build host |
| macOS installer (DMG) | **Not built.** Needs macOS |
| Fabric 1.21.1 `eclipseclient.jar` | **Not built.** Maven/Fabric/Mojang unreachable here (tested). Gradle wrapper now included; see `BUILDING_THE_JAR.md` for the one-command build and the CI job that produces and uploads it |
| Forge 1.8.9 JAR | **Not built** (skeleton) |
| Code signing, update feed | None |

No placeholder or fake binaries were created. The Linux build is unsigned and the launcher cannot update itself.

First steps on a connected machine: build the Fabric client; fix any API mismatches; confirm the `LoadingOverlay` shadow-field names; launch Minecraft with the mod and look at the title screen, loading screen and workspace at the four target resolutions.
