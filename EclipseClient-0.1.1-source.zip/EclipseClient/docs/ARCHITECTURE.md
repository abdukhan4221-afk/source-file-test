# Architecture

```
Renderer (React, sandboxed, no Node)
   |  window.eclipse  (typed bridge from packages/shared-types)
Preload (contextBridge; only invoke + two event channels)
   |  ipcRenderer.invoke('eclipse:invoke', name, ...args)
Main process: whitelist of handlers; sender origin checked; every input re-validated
   |
electron/core: ProfileService, AccountService, VersionService, LaunchService,
               ContentInstaller / mrpack, MicrosoftAuth, serverPing, installer, launchPlan
```

Decisions worth knowing:

- **Engine independent of Electron.** Everything in `electron/core` takes its dependencies (fetch, clock, secret store, spawn) as parameters, so it is tested in plain Node with local servers and fakes.
- **Profiles are folders.** Each owns `instances/<id>`; removal moves the folder to `trash/` so worlds are never deleted silently. Selection only changes on an explicit call.
- **Secrets.** Microsoft tokens go to the OS keystore through `safeStorage`. If it is unavailable (or Linux falls back to basic text) the launcher refuses to store them. They are never written to `accounts.json`. No client secret exists anywhere.
- **Downloads** are hash-verified and written via a `.part` file; archives are extracted with path validation; modpack hosts are allow-listed.
- **Launch honesty.** `LaunchController` moves through real stages, reports measured progress only where the installer can count files, reports `running` only after the OS confirms the process spawned, and records which stage failed.
- **Renderer consumes shared types as TypeScript source;** the main process uses the compiled CommonJS build.
- **Fabric client split.** `core` is pure Java (no Minecraft imports) so layout, scrolling, grids, profiles and counters are unit-tested. `mc`, `screen`, `mixin` are the thin, unverified Minecraft layer. Screens draw with fills only (no textures) and use no vanilla widgets, so there is no atlas to mis-crop and no widget to duplicate.
- **Loading screen.** A TAIL injection that draws *after* vanilla's `render()`; it never cancels, so reload progress, completion, error reporting and overlay removal stay native. The percentage is vanilla's own progress value.
- **Plain CSS instead of Tailwind/Framer Motion.** The brief called these recommended, not required. A token file plus one stylesheet kept the design coherent and the bundle small (197 kB JS).
